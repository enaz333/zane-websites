# Build Recipes and MVP Translation

Evidence: authored implementation suggestions composed from the linked official docs. These are not tested templates or additional product promises. Verify the relevant source before giving precise controls or behavior. Snapshot: November 5, 2026.

Search terms: how do I build this; prototype; fake it; MVP; simplify; beginner; weekend; tap to reveal; poster; scavenger hunt; simulated AI; branching story.

## Translate the team's idea without changing it

Restate the user's desired moment in one sentence. Keep their audience, purpose and concept. Translate only implementation: experience context → anchor → content → trigger → ordered actions → visible result. If device/context changes the choice, ask one targeted question. Otherwise state an assumption and offer a tiny first build.

Default target: one anchor, one hero object, one trigger and one visible response. This is a scope heuristic, not a technical restriction. Offer a second action or UI element when it actually makes the intended moment understandable. Do not force every project into the same template.

## Recipe: tap an object to reveal something

Sources: https://scenery.app/docs/editor/triggers.md and https://scenery.app/docs/editor/actions/scene-content.md

- Moment: the user taps a visible object and another piece of content appears.
- Context/anchor: choose for the team's real setting using 02; do not choose an irreversible context casually.
- Content: one visible tap target and one reveal object.
- Trigger: object event **On Tap Gesture** on the intended target.
- Action: **Add to Scene** targeting the reveal object.
- Setup gotcha: newly placed content has a default **Add to Scene** action on **On Experience Start**. Remove the reveal object's default startup action if it should appear only later.
- First test: before adding final assets, use simple content and confirm one tap reveals it.
- Repeated taps/reset: check Can repeat and the documented lifecycle. Do not assume adding the same object repeatedly is a reset mechanism.

## Recipe: augment one poster or postcard

Sources: https://scenery.app/docs/editor/tracking-contexts.md and https://scenery.app/docs/editor/anchors.md

- Moment: the user points at a printed image and sees attached content.
- Context choice: **Image-Tracking** is for the whole experience revolving around one image. An **Image** anchor can instead attach individual objects to images inside a World- or Geo-Tracking context.
- Start with one marker and one asset. Set the reference image and measured physical image width; the documented image-anchor width is in centimetres.
- Test the actual print, flat and without glare, on the intended viewer before adding interactions.
- Gotcha: image recognition/anchoring does not itself implement a collection game or scoring system. Add only the needed documented events/actions.
- Compatibility: consult 06 before promising image-tracking playback on a headset or browser.

## Recipe: stage a smart assistant or live-data response

Sources: https://scenery.app/docs/editor/triggers.md ; https://scenery.app/docs/editor/actions/scene-content.md ; https://scenery.app/docs/editor/actions/audio-haptics.md ; https://scenery.app/docs/editor/actions/video.md

- Moment: the user acts and receives a convincing response.
- Weekend simplification: prepare one or two responses as text, images, audio or video; use a documented tap event to reveal/play the chosen response.
- Say explicitly that this is a staged response, not live AI, sensing or a backend connection. Preserve the team's idea while simulating its expensive implementation.
- Use a short delay only if the intended pacing needs it; do not replace reliable media/event timing with a fragile long Wait chain.
- If genuine live integration is essential and the team requests it, check Secrets in 10 and the exact HTTP/audio APIs in 15. Explain setup, access and time cost before suggesting code.

## Recipe: a small walk-through or collection moment

Sources: https://scenery.app/docs/editor/triggers.md ; https://scenery.app/docs/editor/actions/scene-content.md ; https://scenery.app/docs/editor/actions/experience.md

- Start with one placed object. Use one documented interaction: tap, **Distance Field**, or **On Camera Collision**, whichever matches the team's intent and target.
- Respond with a visible reveal, removal or documented scene transition. Test this one encounter before duplicating it.
- Do not promise persistent scores, multi-user synchronization, unique-marker collection state or outdoor localization merely because a single encounter works. Retrieve the required state, compatibility and API documentation before expanding.
- If many stops are the blocker, prototype one representative stop and explain the rest in the demo. Ask a mentor to help prioritize cuts if scope is still disputed.

## Recipe: button or on-screen label

Sources: https://scenery.app/docs/editor/user-interface.md ; https://scenery.app/docs/editor/user-interface/interaction.md ; https://scenery.app/docs/editor/anchors.md

- Prefer the documented **User Interface** panel and views for a real button/label when supported by the target and task. Retrieve panels, views, interaction and text docs in 04.
- For a screen-fixed panel, check **Screen Space** requirements; it is not a generic anchor for every object.
- A static image/mock screen is a useful staged visual when a functional UI is unnecessary. Do not invent invisible tap-target behavior or claim a mock screen is a real form.
- For dynamic state, retrieve Text & Variables and the exact actions or scripts needed. Do not assume every input has a no-code binding to arbitrary variables.

## Response shape for build requests

“The fastest believable version is [one sentence].” Then 3–5 practical steps, one important gotcha, and a success test. Add a single optional upgrade only after the core path works. Ask a mentor for concept direction, not permission to perform ordinary technical help.


## Non-coder scripting fallback

Authored support guidance, not an official product specification. Assume the participant has never written code. Prefer a documented no-code recipe whenever it achieves the goal. Use scripting sparingly when no adequate no-code option exists, as a targeted alternative after relevant no-code troubleshooting, or by explicit request. An available API is not by itself a reason to use code.

When code is needed, offer to write it; when implementation is already requested, provide the complete script directly. Retrieve Getting Started/Console/Events in 08 and the exact API in 12–15. Check access and target support before proposing the script.

Walk through required scene objects and names, selected scene/object, attached event, Run Script action, action order, complete code, every placeholder, where to paste, how to finish the edit, preview and target-device test, expected result, and locating/copying an error. Use verified UI labels; ask for a relevant screenshot if the final edit/apply control is uncertain. Explain any essential term in plain language.

Never assume the participant can assemble snippets, apply a diff, locate an ID unaided or debug JavaScript. On failure, request the exact redacted error and provide a complete corrected replacement plus instructions, preserving their working customizations. State that generated code is untested unless it was actually executed. Keep a longer walkthrough staged and readable; concise answers must not omit required implementation details.
