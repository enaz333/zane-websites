# Scripting and Advanced Logic

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: JavaScript; script; console; error; undefined; null; event timing; advanced logic; examples; migration.

## Contents

- Scripting
- Getting Started
- The Console
- Events
- Vectors & Transforms
- Gestures & Interactions
- User Interface
- Materials
- Mesh Instancing
- Gaussian Splats
- Paths & Splines
- Location
- Tracking
- Compute Kernels
- Feature detection
- Examples
- Migration Guide

---

Source page: Scripting

Source URL: https://scenery.app/docs/scripting.md

# Scripting&#x20;

Documentation source: [Scripting](https://scenery.app/docs/scripting.md).

::: warning Beta
The Scripting API is in **beta** – APIs may change between releases. Scripting is part of the **Pro** plan and up; on a free account, Run Script and the scripting triggers are marked Pro and open the plan offer.
:::

Add dynamic behaviour to your experiences with **JavaScript**. Scripts get typed access to the scene graph, entities, materials, audio, networking, animations, and GPU compute – running live in the editor preview and on device.

## Start here

Documentation source: [Scripting](https://scenery.app/docs/scripting.md).

* **[Getting Started](https://scenery.app/docs/scripting/guide/getting-started)** – your first script, the global objects, and the script lifecycle.
* **[Events](https://scenery.app/docs/scripting/guide/events)** – run scripts in response to scene and object events.
* **[Materials](https://scenery.app/docs/scripting/guide/materials)**, **[User interface](https://scenery.app/docs/scripting/guide/user-interface)**, **[Feature detection](https://scenery.app/docs/scripting/guide/feature-detection)**, **[Compute kernels](https://scenery.app/docs/scripting/guide/compute)** – focused guides.
* **[Examples](https://scenery.app/docs/scripting/guide/examples)** – complete, copy-pasteable scripts.

## API reference

Documentation source: [Scripting](https://scenery.app/docs/scripting.md).

The [API reference](https://scenery.app/docs/scripting/api/) documents every type – the scene, entities, math and geometry, networking, audio, animation, and compute APIs.

---

Source page: Getting Started

Source URL: https://scenery.app/docs/scripting/guide/getting-started.md

# Getting Started

Documentation source: [Getting Started](https://scenery.app/docs/scripting/guide/getting-started.md).

Scenery is a visual editor for spatial experiences. You design scenes, place objects, configure materials, and wire up behaviors – all without code.

Scripts handle what the visual editor doesn't: state, logic, external data, real-time connections, procedural behavior.

## How scripts work

Documentation source: [Getting Started](https://scenery.app/docs/scripting/guide/getting-started.md).

Scripts attach to events. When something happens – a tap, an object appearing, a frame rendering – Scenery can run your code.

To add a script:

1. Create an event (on an object or the scene)
2. Add a "Run Script" action
3. Write your code

When the event fires, your script runs with event data in `scriptContext.sourceEvent`:

```javascript
// Tap event – scale up the tapped object
scriptContext.sourceEvent.objectEntity.animateTo(
    { scale: Vector3(1.2, 1.2, 1.2) },
    0.2
);
```

Different events provide different data – position, deltaTime, distance, etc.

::: tip
Use `console.log(scriptContext.sourceEvent)` to inspect what data is available for any event.
:::

::: warning Action order matters
Actions run sequentially by default. If your script uses `scene.findEntity` to find an object, that object must already be in the scene – so place the "Add to Scene" action **before** "Run Script":

**Add to Scene** (MyBox) → **Run Script** (finds MyBox)

If the script runs first, the object won't exist yet and `findEntity` returns `null`. Alternatively, attach your script to the object's **On Will Appear** or **On Did Appear** event – then the object is guaranteed to be available.
:::

## Example: Continuous rotation

Documentation source: [Getting Started](https://scenery.app/docs/scripting/guide/getting-started.md).

Attach to "On Render":

```javascript
// Replace with your object's ID or use { name: "..." }
var cube = scene.findEntity("YOUR_OBJECT_ID");
cube.representation.rotation = cube.representation.rotation.multiply(
    Rotation(0, scriptContext.sourceEvent.deltaTime, 0)
);
```

## Finding objects

Documentation source: [Getting Started](https://scenery.app/docs/scripting/guide/getting-started.md).

```javascript
// By name (set in Identity panel)
var box = scene.findEntity({ name: "MyBox" });

// By ID
var box = scene.findEntity("ABC123");

// Access the representation (visual content).
// position is an offset from where the object was placed in the editor: this lifts it 1 m.
// worldPosition is where it is in the scene.
box.representation.position = Vector3(0, 1, 0);
box.representation.opacity = 0.5;
```

To get an ID: right-click an object or representation in the editor → **Copy Development ID**.

::: warning Entity vs Representation
An **entity** is the top-level object (the anchor container you see in the scene list). A **representation** is the visual content inside it (model, shape, image, audio, etc.). Use `entity` for finding and referencing objects, use `entity.representation` for visual changes (position, rotation, scale, opacity).

`scene.findEntity` finds top-level objects only – not nested representations. If your object contains multiple representations (e.g. a model and an audio source), find the parent entity first, then navigate:

```javascript
var entity = scene.findEntity({ name: "MyObject" });
var audio = entity.findRepresentation({ name: "BGMusic" });
audio.isEnabled = true;
```

See [Examples → Entity hierarchy](https://scenery.app/docs/scripting/guide/examples#entity-hierarchy-and-lookup) for the full pattern.
:::

## Rotations

Documentation source: [Getting Started](https://scenery.app/docs/scripting/guide/getting-started.md).

All rotation values are in **radians**. Use `Math.toRadians()` and `Math.toDegrees()` to convert:

```javascript
Rotation(0, Math.PI / 2, 0);          // 90° around Y axis
Rotation(Math.toRadians(45), 0, 0);   // 45° around X axis

var degrees = Math.toDegrees(Math.PI); // 180
```

Other math helpers: `Math.lerp(a, b, t)`, `Math.clamp(value, min, max)`, `Math.map(value, inMin, inMax, outMin, outMax)`, `Math.smoothstep(edge0, edge1, x)`.

For working with directions, distances, dot/cross products, smooth motion, and converting between world and local space, see [Vectors & Transforms](https://scenery.app/docs/scripting/guide/vectors-transforms).

## Error handling

Documentation source: [Getting Started](https://scenery.app/docs/scripting/guide/getting-started.md).

Script errors are logged to the debug console but don't crash the scene – other scripts and actions continue to run. Use `try/catch` for operations that may fail:

```javascript
try {
    var response = await http.get("https://api.example.com/data");
} catch (error) {
    console.error("Request failed: " + error);
}
```

::: tip Using await
You can use `await` directly at the top level of your script – the runtime wraps async code for you, so there's no need for an `(async function(){…})()` wrapper or a helper function.

```javascript
var box = await scene.createEntity(createBox(0.3, 0.3, 0.3));
```

:::

## Configuring entities – use the descriptor builder

Documentation source: [Getting Started](https://scenery.app/docs/scripting/guide/getting-started.md).

`scene.createEntity(...)` takes **one** descriptor argument. Configure anchor, name, traits, and other settings via the descriptor's chainable builder methods, not as a second options argument.

```javascript
// ✅ Correct – chain builder methods on the descriptor
const box = createBox(0.3, 0.3, 0.3)
    .anchor(Anchor.position(0, 0, -1))
    .name("hero-box");
const entity = await scene.createEntity(box);

// ❌ Wrong – second argument throws at call time
await scene.createEntity(box, { anchor: Anchor.position(0, 0, -1) });
```

Same rule for `scene.runAction(action)` – single argument. Configure inside the action data, not via a second arg.

The same builder also adjusts objects you already authored in the editor: `scene.getObjectDescriptor({ name: "..." })` returns an authored object's descriptor, so you can change its traits, material, or model – or add an interaction – *before* it's shown, then write it back with `scene.setObjectDescriptor(...)`. Where `findEntity` gives you the live object, `getObjectDescriptor` gives you its recipe. See [Examples → Adjust an authored object](https://scenery.app/docs/scripting/guide/examples#adjust-an-authored-object-before-it-appears).

## Debugging

Documentation source: [Getting Started](https://scenery.app/docs/scripting/guide/getting-started.md).

Tap the terminal button in the bottom-right corner to open the **debug console**. It shows `console.log` output and errors from your scripts. You can also type and run scripts directly in the console input field.

```javascript
console.log("score:", experience.getVariable("score"));
console.error("something went wrong");
```

## Next steps

Documentation source: [Getting Started](https://scenery.app/docs/scripting/guide/getting-started.md).

* [Events](https://scenery.app/docs/scripting/guide/events) – Triggers, event data, the render loop
* [API Reference](https://scenery.app/docs/scripting/api/) – Full documentation

::: tip Using AI to write scripts
Want ChatGPT, Claude, or another LLM to help write scripts?

* Pasting context in by hand – feed it [`llms-full.txt`](https://scenery.app/docs/llms-full.txt), the complete guide and API reference in a single file.
* Using a tool that fetches pages itself – give it [`llms.txt`](https://scenery.app/docs/llms.txt), an index it reads first so it can pull only the pages it needs.
* Only need one part – scripting ships separate bundles, [`scripting/llms.txt`](https://scenery.app/docs/scripting/llms.txt) maps the API reference for [engine types](https://scenery.app/docs/scripting/api/llms-full.txt) and [runtime types](https://scenery.app/docs/scripting/api/runtime/llms-full.txt), and the [guide](https://scenery.app/docs/scripting/guide/llms-full.txt).
  :::

---

Source page: The Console

Source URL: https://scenery.app/docs/scripting/guide/console.md

# The Console

Documentation source: [The Console](https://scenery.app/docs/scripting/guide/console.md).

Everything a script logs with `console.log`, `console.warn` or `console.error` appears in the console, along with the engine's own notes about what the experience is doing. You can also type JavaScript into it and run it against the experience as it plays, which is the quickest way to try an idea before writing it into an action.

The console is available while **editing** – in the editor's preview – and while **playing** a published experience. The playing case is the one worth knowing about, because it is how you debug on the device the experience will actually run on.

## Opening it

Documentation source: [The Console](https://scenery.app/docs/scripting/guide/console.md).

| Where | How |
|---|---|
| Mac | Pause the experience and choose **Show Console**, or press **⌘⌥C** at any time |
| iPad | Pause the experience and choose **Show Console** |
| iPhone | Pause the experience and choose **Show Console** – it opens as a sheet you can drag to full height |
| Apple Vision Pro | Tap the console button beside the pause button on your hand, or choose **Show Console** from the pause menu |

On Mac the console starts as a panel over the bottom of the experience, and the **Open in Separate Window** button moves it into a window of its own, which you can put on a second display while the experience keeps running. **Put Back in the Experience** returns it.

On Apple Vision Pro it is always a window, placed within reach and angled towards you. Closing the window closes the console, and the window closes with the experience.

::: tip Who sees it
The console appears for the experience's **owner and their team**. Nobody else sees it, and a viewer who is not signed in to an account with access never knows it exists.
:::

## Reading the log

Documentation source: [The Console](https://scenery.app/docs/scripting/guide/console.md).

Each line carries the time it was logged. Lines from your scripts and lines from the engine are shown together, so you can see a `console.log` next to the state change that caused it.

* **Search** – the magnifier opens a field that narrows the log to matching lines.
* **Filter** – choose what to show: script output, engine output, errors and warnings only, or diagnostics. The button is tinted while any filter is away from its default, so a quiet console is never a mystery.
* **Copy** – puts the whole log on the clipboard, formatted as it reads, which is what to attach to a bug report.
* **Clear** – empties it. A cleared console says so, so a clear that worked does not look like one that did nothing.

The console holds the most recent lines and drops the oldest as it fills, so a script that logs every frame will not grow it without limit.

## Running script

Documentation source: [The Console](https://scenery.app/docs/scripting/guide/console.md).

Type into the field at the bottom and press **Return** to run. **Shift-Return** adds a line, so a multi-line snippet can be pasted or typed in one go.

* **↑ / ↓** step back and forth through what you have run before, as long as the field holds a single line. Once it holds more, the arrows move the cursor instead.
* **Paste** – the button inside the field puts the clipboard's text in without replacing what you have already typed. It is greyed when the clipboard holds no text.
* Nothing runs on its own. Pasting fills the field; running is always a separate, deliberate press.

Script you run here is evaluated against the live experience, in the same context as its own scripts – so an object your script created is reachable by the next thing you type.

```javascript
// Try it: a box a metre in front of you.
var box = await scene.createEntity(
    createBox(0.2, 0.2, 0.2).anchor(Anchor.currentPOV(0, 0, -1))
);
```

`await` works directly, with no wrapper – see [Getting Started](https://scenery.app/docs/scripting/guide/getting-started).

::: tip While paused
A paused experience completes no actions and never returns from `wait()`, so the input is disabled while playback is paused and the console says so. Resume, and it comes back.
:::

## What it is not

Documentation source: [The Console](https://scenery.app/docs/scripting/guide/console.md).

The console reads and writes the experience you are running, on your device. It does not reach other viewers, it is not a remote log, and nothing you type is saved into the experience. Close it and the session is gone.

For logging that your scripts control, see [Events](https://scenery.app/docs/scripting/guide/events); for the API the input accepts, the whole [reference](https://scenery.app/docs/scripting/api/) applies.

---

Source page: Events

Source URL: https://scenery.app/docs/scripting/guide/events.md

# Events

Documentation source: [Events](https://scenery.app/docs/scripting/guide/events.md).

Events trigger scripts. Scenery has two kinds: **object events** that fire for a specific object, and **scene events** that fire globally.

## Object events

Documentation source: [Events](https://scenery.app/docs/scripting/guide/events.md).

Attach to individual objects. The triggering object is available in `scriptContext.sourceEvent`.

| Event | Fires when |
|-------|------------|
| On Will Appear | Object is about to be added to scene |
| On Did Appear | Object has appeared |
| On Removal | Object is removed from scene |
| On Tap Gesture | Object is tapped |
| On Gesture | Object is dragged, rotated, or resized (needs a gesture enabled) |
| On Camera Collision | Camera enters/exits object bounds |
| On Object Collision | Physics collision with another object |
| Distance Field | Camera or target crosses distance threshold |
| Look Direction | User looks at/away from object (or object looks at target) |
| Media Playback | Video/audio begins, reaches timestamp, or ends |

```javascript
// On Tap Gesture – scale up the tapped object
scriptContext.sourceEvent.objectEntity.animateTo(
    { scale: Vector3(1.2, 1.2, 1.2) },
    0.2
);
```

## Scene events

Documentation source: [Events](https://scenery.app/docs/scripting/guide/events.md).

Fire regardless of which object is involved.

| Event | Fires when |
|-------|------------|
| On Experience Start | Experience begins |
| On Experience Load | Experience finishes loading |
| On Screen Tap | User taps anywhere on screen |
| On Render | Every frame |
| On Schedule | After a delay or at specific time |
| On Variable Change | A variable is modified |
| On Audio Analysis | Audio levels update (ambient or microphone) |

```javascript
// On Render – rotate every frame
var cube = scene.findEntity("YOUR_OBJECT_ID");
cube.representation.rotation = cube.representation.rotation.multiply(
    Rotation(0, scriptContext.sourceEvent.deltaTime, 0)
);
```

Two scene events exist only in code: `snapshot` fires after the viewer takes a photo, and `recording` after a video recording ends. Both fire on iPhone and iPad; visionOS has no capture button.

```javascript
scene.on('snapshot', function() {
    console.log('Photo taken');
});
```

## Subscribing in code

Documentation source: [Events](https://scenery.app/docs/scripting/guide/events.md).

You can also subscribe to events programmatically:

```javascript
var cube = scene.findEntity("YOUR_OBJECT_ID");

// Object event
cube.on('tap', function(e) {
    e.objectEntity.animateTo({ scale: Vector3(1.2, 1.2, 1.2) }, 0.2);
});

// Scene event
scene.on('render', function(e) {
    cube.representation.rotation = cube.representation.rotation.multiply(
        Rotation(0, e.deltaTime, 0)
    );
});

// One-time listener
scene.once('start', function() {
    console.log('Experience started');
});
```

### Throttling

Documentation source: [Events](https://scenery.app/docs/scripting/guide/events.md).

For expensive operations, throttle the render loop:

```javascript
scene.on('render', { throttle: 0.1 }, function(e) {
    // Runs every 100ms instead of every frame
});
```

### Unsubscribing

Documentation source: [Events](https://scenery.app/docs/scripting/guide/events.md).

```javascript
var eventId = cube.on('tap', function() {});
// Later...
cube.off(eventId);
```

::: tip objectEntity vs representationEntity
Tap and collision events give you both `objectEntity` (the top-level container) and `representationEntity` (the specific visual that was interacted with). Use `objectEntity` when you need to find sibling representations like audio sources.
:::

## Gesture and screen events

Documentation source: [Events](https://scenery.app/docs/scripting/guide/events.md).

Beyond taps, you can react to live manipulation, multi-tap gestures, and raw screen gestures.

### Manipulating an object

Documentation source: [Events](https://scenery.app/docs/scripting/guide/events.md).

If an object has a gesture enabled (Drag, Rotate or Resize), `on('gesture')` fires continuously while the user manipulates it, so you can react to the movement itself. Read `e.phase` (`'began'` / `'changed'` / `'ended'`) and, by gesture kind, `e.translation` / `e.rotation` / `e.scale` (world-space):

```javascript
box.on('gesture', function(e) {
    if (e.phase === 'ended') {
        console.log('let go');
    }
});
```

`doubleTap` and `longPress` are discrete object gestures – these are available in code (not as editor triggers):

```javascript
box.on('doubleTap', function() { /* ... */ });
box.on('longPress', { minimumDuration: 0.5 }, function() { /* ... */ });
```

### Screen gestures

Documentation source: [Events](https://scenery.app/docs/scripting/guide/events.md).

`pan`, `pinch` and `rotate` fire on any such gesture anywhere on screen, independent of scene objects – the raw input for mechanics like flick-to-launch. Read `e.position` (normalized) and, by kind, `translation` / `scale` / `rotation` plus `velocity`:

```javascript
// Flick up in the bottom of the screen to launch the ball
scene.on('pan', { area: [0, 0.6, 1, 0.4], phase: 'ended' }, function(e) {
    // e.velocity is in screen points/sec – scale it to a world-space push (tune to taste)
    var power = Math.max(0, -e.velocity.y) * 0.002;
    ball.applyImpulse(new Vector3(0, power, -power * 2), { space: 'world' });
});
```

Outside AR (the desktop preview, the Mac app), a one-finger pan **also orbits the camera** by default. So if your handler reacts to a pan, that one gesture does two things at once – your mechanic runs *and* the camera swings. `consume` prevents that: return `true` from its predicate and the gesture is handled by your script alone, so the camera ignores it. The predicate runs as the gesture begins, so you can claim only the pans that start on your object and leave the rest for the camera:

```javascript
// Claim the pan only when it starts on the ball; every other pan still orbits the camera
scene.on('pan', { consume: function(e) { return e.hits(ball); } }, function(e) { /* ... */ });
```

Omit `consume` for the smart default – a gesture is claimed automatically when it begins on a scene object. See [scene.on](https://scenery.app/docs/scripting/api/scene) for the full payload and `consume` options.

::: tip Screen gestures are for touch screens
`pan`, `pinch` and `rotate` fire on iPhone, iPad and Mac. On Apple Vision Pro input is spatial (you look and pinch), so screen gestures aren't delivered – drive interaction from UI panels and buttons there instead. Gate a portable script with `environment.features.has('screenGestures')` and provide a fallback.
:::

## Event data

Documentation source: [Events](https://scenery.app/docs/scripting/guide/events.md).

How you access event data depends on how your script runs:

**Run Script action** – use `scriptContext.sourceEvent`:

```javascript
var entity = scriptContext.sourceEvent.objectEntity;
var dt = scriptContext.sourceEvent.deltaTime;
```

**Event subscriptions** – data is passed to your callback:

```javascript
scene.on('render', function(e) {
    var dt = e.deltaTime;
});

cube.on('tap', function(e) {
    var tapped = e.objectEntity;
});
```

**Properties by event type:**

| Event | Properties |
|-------|------------|
| `render` | `deltaTime`, `time` |
| `tap` | `objectEntity`, `representationEntity`, `screenPosition` |
| `gesture` | `objectEntity`, `representationEntity`, `phase`, `translation`/`rotation`/`scale` |
| `doubleTap`, `longPress` | `objectEntity`, `representationEntity` |
| `pan`, `pinch`, `rotate` | `position`, `beganPosition`, `phase`, `translation`/`scale`/`rotation`, `velocity` |
| `screenTap` | `position` |
| `distance` | `objectEntity`, `distance`, `crossed` |
| `lookAt` | `objectEntity`, `isLooking` |
| `cameraCollision` | `objectEntity`, `representationEntity` |
| `physicsCollision` | `objectEntity`, `representationEntity`, `position`, `impulse` |
| `variableChange` | `variableId`, `value` |
| `mediaPlayback` | `objectEntity`, `status`, `time`, `duration` |
| `audioAnalysis` | `kind`, `loudness`, `bass`, `lowMid`, `mid`, `upperMid`, `presence`, `brilliance`, `air`, `treble` |
| `add`, `appear`, `remove` | `objectEntity`, `representationEntity` |
| UI Interaction (editor trigger, via `scriptContext.sourceEvent`) | `uiNodeId`, `uiInteractionKind`, `uiValue` |

::: tip
Use `console.log(scriptContext.sourceEvent)` or `console.log(e)` to inspect all available properties.
:::

---

Source page: Vectors & Transforms

Source URL: https://scenery.app/docs/scripting/guide/vectors-transforms.md

# Vectors & Transforms

Documentation source: [Vectors & Transforms](https://scenery.app/docs/scripting/guide/vectors-transforms.md).

Positions, directions, and rotations are the raw material of anything spatial – aiming an object at the viewer, checking how far away something is, moving smoothly, turning a hand position into an object's own space. This page is a tour of the `Vector3`, `Rotation`, and `Transform` helpers, focused less on the maths and more on what each one is *for*.

## Points and directions

Documentation source: [Vectors & Transforms](https://scenery.app/docs/scripting/guide/vectors-transforms.md).

A `Vector3` is just three numbers, but it plays two roles:

* a **point** – a position in space (an object's `position`, a hand joint, a raycast hit)
* a **direction** – which way something points, usually with a length of 1

The direction from one point to another is their difference:

```javascript
var toTarget = target.subtract(myPosition);   // points from me toward the target
var distance = toTarget.length();              // how far away the target is
var heading  = toTarget.normalize();           // same direction, length 1
```

`a.distanceTo(b)` is a shortcut for `b.subtract(a).length()` when you only need the distance.

**What `normalize()` is for:** it scales a vector to length 1 while keeping its direction, so you're left with pure "which way" and no "how far". You want it whenever direction is what matters but magnitude shouldn't leak in – moving at a constant speed, aiming, or feeding a direction into a dot product (below), which only reads as an angle when its inputs are unit length.

::: tip
Normalize a direction before you use it to move or aim. A raw direction whose length happens to be, say, 3 would move an object 3× too fast – speed would depend on how far the target is, which is almost never what you want.
:::

Move an object a fixed speed toward a target each frame:

```javascript
// Attach to: On Render
var dt   = scriptContext.sourceEvent.deltaTime;             // seconds since last frame
var step = target.subtract(obj.position).normalize().multiply(2.0 * dt);   // 2 m/s
obj.position = obj.position.add(step);
```

## Dot product – how aligned are two directions?

Documentation source: [Vectors & Transforms](https://scenery.app/docs/scripting/guide/vectors-transforms.md).

`a.dot(b)` measures how much two directions point the same way. For unit vectors it is the cosine of the angle between them: `1` means the same direction, `0` perpendicular, `-1` opposite.

That makes it the go-to test for "is this in front of me?" and "is the viewer looking at it?":

```javascript
// Attach to: On Render
var cam     = scene.cameraTransform;
var forward = cam.transformVector(Vector3(0, 0, -1));               // where the camera looks
var toObj   = obj.representation.worldPosition.subtract(cam.position).normalize();

if (forward.dot(toObj) > 0.97) {   // 0.97 ≈ within ~14° of dead-on; a smaller number = wider cone
    // the viewer is looking almost straight at the object
}
```

Need the actual angle instead of a threshold? `a.angleTo(b)` returns it in radians.

## Cross product – give me a perpendicular

Documentation source: [Vectors & Transforms](https://scenery.app/docs/scripting/guide/vectors-transforms.md).

`a.cross(b)` returns a vector at right angles to both `a` and `b`. You reach for it when you need an axis you don't already have:

* a **surface normal** – the direction a surface faces – from two of its edges: `edge1.cross(edge2)`. Normals are what lighting uses to shade a surface, so this comes up when you build or deform a mesh.
* a **"right" direction** from a forward and an up vector: `forward.cross(up)` – useful for placing something beside the viewer or moving sideways.

This one is more advanced – if you're mostly moving and aiming objects, you may not need it yet.

## Smooth motion – lerp and slerp

Documentation source: [Vectors & Transforms](https://scenery.app/docs/scripting/guide/vectors-transforms.md).

Snapping straight to a target reads as robotic; easing toward it feels alive. `lerp` blends between two values by a fraction `t` (0 = start, 1 = end):

```javascript
// Attach to: On Render — smooth follow
obj.position = obj.position.lerp(target, 0.1);   // moves 10% of the remaining distance each frame
```

* `Vector3.lerp` for positions, `Math.lerp(a, b, t)` for plain numbers.
* Rotations use `rotation.slerp(other, t)` – the shortest smooth turn between two orientations.

## Rotations

Documentation source: [Vectors & Transforms](https://scenery.app/docs/scripting/guide/vectors-transforms.md).

A `Rotation` orients something. Build one from angles (in **radians**), then combine, undo, or blend:

```javascript
var quarterTurn = Rotation(0, Math.toRadians(90), 0);   // 90° around the up (Y) axis
var combined    = rotA.multiply(rotB);                  // apply B, then A
var undo        = rot.inverse();                        // the opposite rotation
var eased       = current.slerp(target, 0.2);           // smooth turn toward another orientation
```

Use `Math.toRadians()` / `Math.toDegrees()` to convert. To turn an object to *face* a point (a "look-at"), see the billboard example in [Examples](https://scenery.app/docs/scripting/guide/examples).

## Coordinate spaces

Documentation source: [Vectors & Transforms](https://scenery.app/docs/scripting/guide/vectors-transforms.md).

The same point can be described from different frames of reference, and mixing them up is a common source of "why is it in the wrong place" bugs:

* **World space** – the one frame shared by everything, so any two things can be compared in it. The values you *read* are almost always world-space: hand joints (`scene.tracking.hands`), raycast hits, an object's `worldPosition`, the camera's position.
* **Local space** – each object has its *own*, relative to its transform. A mesh's vertices, and an object's `position`, live in that object's local frame. (The camera has its own local frame too – "camera space".)

So "local" isn't one place – it's per-object. Moving a point from one frame into another is exactly what a **Transform** does.

## Transforms

Documentation source: [Vectors & Transforms](https://scenery.app/docs/scripting/guide/vectors-transforms.md).

A `Transform` bundles **position, rotation, and scale** – it is how one object sits in space, i.e. where its local frame lands in the world. Every entity has one:

* `entity.transform` – relative to its parent (its **local** transform)
* `entity.worldTransform` – its final place in the scene, with all parents applied

Use it to move points and directions between the world and an object's local space:

```javascript
var inv   = Transform.inverse(entity.worldTransform);
var local = Transform.transformPoint(inv, worldPoint);          // world → this entity's local frame
var world = entity.worldTransform.transformPoint(localPoint);   // local → world
```

* **`transformPoint`** moves a position (translation included).
* **`transformVector`** moves a direction (translation *ignored*, so it stays a direction) – this is why the dot-product example built the camera's forward with `transformVector`.
* **`multiply`** chains two transforms; **`inverse`** reverses one.

A hand joint feeding a mesh you built is the classic case: the joint is world-space, the mesh's vertices are the entity's local space – convert the joint into the entity's local frame first.

In practice you rarely convert by hand, because entities hand you both frames directly: a representation's `position` is its **local** position, its `worldPosition` is the **world** one, and you can read *or set* either. Manual `transformPoint` conversion is for a loose point that isn't already an entity property – a hand joint, a raycast hit, a mesh vertex.

::: tip
An object at the scene's origin has local space equal to world space, so no conversion is needed. It starts to matter once the object – or the experience origin it sits under – is moved or rotated.
:::

---

Source page: Gestures & Interactions

Source URL: https://scenery.app/docs/scripting/guide/gestures.md

# Gestures & Interactions

Documentation source: [Gestures & Interactions](https://scenery.app/docs/scripting/guide/gestures.md).

Gestures come in two layers:

* **Object gestures** – drag, rotate, or resize a *specific* object. Enable them on the
  object, then optionally react in a script.
* **Screen gestures** – raw `pan` / `pinch` / `rotate` anywhere on screen, independent of
  any object. The building block for custom mechanics like flick-to-launch.

Screen gestures fire on iPhone, iPad and Mac – not Apple Vision Pro, where input is spatial.
Gate a portable script with `environment.features.has('screenGestures')` and fall back to UI
controls. See [Feature Detection](https://scenery.app/docs/scripting/guide/feature-detection).

## Object gestures

Documentation source: [Gestures & Interactions](https://scenery.app/docs/scripting/guide/gestures.md).

Enable a gesture on the descriptor (or in the editor), and the user can manipulate the object
directly:

```javascript
var crate = await scene.createEntity(
    createBox(0.2, 0.2, 0.2)
        .name('crate')
        .gestures({ drag: true, rotate: true })
);
```

React to the live manipulation with `on('gesture')` – it fires continuously while the user
moves the object. Read `e.phase` (`'began'` / `'changed'` / `'ended'`) and, by kind,
`e.translation` / `e.rotation` / `e.scale`:

```javascript
crate.on('gesture', function(e) {
    if (e.phase === 'ended') {
        console.log('moved by', e.translation.toString());
    }
});
```

`doubleTap` and `longPress` are discrete object gestures, available in code:

```javascript
crate.on('doubleTap', function() { /* ... */ });
crate.on('longPress', { minimumDuration: 0.5 }, function() { /* ... */ });
```

### Release behaviour

Documentation source: [Gestures & Interactions](https://scenery.app/docs/scripting/guide/gestures.md).

When a dragged object is let go, `releaseBehavior` decides what happens next:

```javascript
createSphere(0.04)
    .physics({ mode: 'dynamic', mass: 0.2 })
    .gestures({ drag: true, releaseBehavior: 'momentum' });
```

| `releaseBehavior` | On release |
| --- | --- |
| `'stay'` (default) | Stays where it was let go, then falls under gravity if it has a dynamic body. |
| `'reset'` | Animates back to where the gesture started. |
| `'momentum'` | Keeps the motion the gesture gave it – a flick throws it, a slow release lets it drift. Tune with `momentumScale` / `angularMomentumScale`. |

`'momentum'` gives you a throw with no manual velocity maths – the engine measures the release
motion for you. Reach for the scripted approach below only when you need finer control.

## Screen gestures

Documentation source: [Gestures & Interactions](https://scenery.app/docs/scripting/guide/gestures.md).

`scene.on('pan' | 'pinch' | 'rotate')` fires for any such gesture anywhere on screen. Read
`e.position` (normalized), `e.phase`, and by kind `translation` / `scale` / `rotation` plus
`velocity`:

```javascript
// Flick strength from a swipe in the bottom of the screen.
scene.on('pan', { area: [0, 0.6, 1, 0.4], phase: 'ended' }, function(e) {
    console.log('flick speed', e.velocity.length());
});
```

Outside AR (the desktop preview, the Mac app), a one-finger pan **also orbits the camera** by
default – so a pan your script reacts to would move your object *and* swing the camera at once.
`consume` claims the gesture for your script alone: return `true` from its predicate (evaluated
as the gesture begins) and the camera ignores that gesture. Omit `consume` for the smart default,
which claims a gesture automatically when it begins on a scene object:

```javascript
// Claim the pan only when it starts on the ball; every other pan still orbits the camera.
scene.on('pan', { consume: function(e) { return e.hits(ball); } }, function(e) { /* ... */ });
```

See [scene.on](https://scenery.app/docs/scripting/api/scene) for the full payload and `consume` options.

## Composing a custom mechanic

Documentation source: [Gestures & Interactions](https://scenery.app/docs/scripting/guide/gestures.md).

Specific mechanics – pickup-and-throw, drag-to-aim, swipe-to-navigate – aren't engine
features; you compose them in a script from the primitives above plus physics. A flick-to-launch,
in miniature:

```javascript
var ball = scene.findEntity({ name: 'ball' });

// Claim a pan that starts on the ball; on release, convert its screen velocity to an impulse.
scene.on('pan', { consume: function(e) { return e.hits(ball); } }, function(e) {
    if (e.phase !== 'ended') { return; }
    var launchScale = 0.002;  // screen points/sec -> world impulse; tune for the feel you want
    var lift = 0.4;           // upward component so the throw arcs
    ball.applyImpulse(new Vector3(e.velocity.x * launchScale, lift, -e.velocity.y * launchScale));
});
```

For a full worked example (velocity smoothing over the tail of the drag, scoring, reset), the
same idea scales up – measure the release velocity, apply it as an impulse, and let physics
carry the object.

---

Source page: User Interface

Source URL: https://scenery.app/docs/scripting/guide/user-interface.md

# User Interface

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

Build 2D panels – labels, sliders, buttons, stacks – from a script, place them in the scene or
pin them to the screen, and drive them from your logic. For text that tracks a variable live,
see [Live labels](#live-labels) below.

Panels built in the editor's [UI editor](https://scenery.app/docs/editor/user-interface/) are the same kind of object: a
script can find their views by name and change them exactly as described here. For the layout
model, the panel settings and how panels render on each device, see the editor's
[User Interface](https://scenery.app/docs/editor/user-interface/) section.

## Build and place a panel

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

Compose a view tree with the `UI.*` builders, wrap it with `createPanel(...)`, and instantiate
it with `scene.createEntity`:

```javascript
var panel = createPanel(
    UI.vStack({
        spacing: 12,
        children: [
            UI.label({ text: 'Volume' }),
            UI.slider({ name: 'vol', value: 0.5, range: [0, 1], sizing: { width: 'fill' } })
        ]
    }),
    { panelSize: [320, 160], material: 'system' }
).name('controls');

var entity = await scene.createEntity(
    panel.anchor(Anchor.screenSpace({ alignment: 'bottom', insets: 24 }))
);
```

`Anchor.screenSpace(...)` pins the panel to a screen edge or corner; anchor it in the world
instead (e.g. `Anchor.position(...)`) for a panel that lives in the scene.

### Panel options

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

`createPanel(content, options)` takes:

| Option | Values | Default |
|---|---|---|
| `panelSize` | `'auto'` (hug the content), `'fill'` (whole screen, screen-space only), or a size in points: `[width, height]` or `{ width, height }` | `'auto'` |
| `material` | `'system'`, `'transparent'`, a hex colour string or `{ r, g, b }` for a solid colour, or `{ prominence: 'standard' \| 'expressive' }` for the system material with a prominence | `'system'` |
| `cornerRadius` | points | `8` |
| `isScrollable` | `true` to scroll content taller than the panel; needs a fixed `panelSize` | `false` |

In the world, about 1360 points make one metre, so `[400, 240]` is roughly 29 × 18 cm.

### Builders

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

| Builder | Options (besides the common ones below) |
|---|---|
| `UI.label` | `text` (or pass the text as a string), `lineLimit` (default `1`; `null` wraps freely), `textTransform` (`'uppercase'`, `'lowercase'`, `'capitalize'`) |
| `UI.button` | `title`, `icon` |
| `UI.slider` | `value` (default `0.5`), `range: [min, max]` or `min` / `max` (default `0`–`1`), `numberType` (`'float'` or `'integer'`), `step` (`0` = continuous) |
| `UI.stepper` | `value` (default `0`), `range` or `min` / `max` (default `0`–`100`), `step` (default `1`), `label` |
| `UI.textField` | `text`, `placeholder` |
| `UI.segmentedControl` | `segments` (array of titles), `selectedIndex` (default `0`) |
| `UI.progressView` | `progress` from `0` to `1`; omit it for a spinner |
| `UI.divider` | `thickness` (default `0.5`) |
| `UI.shape` | `shape` (default a rounded rectangle with radius 8) |
| `UI.spacer` | `minLength` |
| `UI.vStack`, `UI.hStack` | `children`, `alignment` (`'leading'`, `'center'`, `'trailing'`, `'top'`, `'bottom'`, `'fill'`; default `'center'`), `distribution` (`'fill'` or `'fillEqually'`), `spacing` (default `8`) |
| `UI.zStack` | `children`, `alignment` (`'center'`, `'top'`, `'bottom'`, `'leading'`, `'trailing'`, `'topLeading'`, `'topTrailing'`, `'bottomLeading'`, `'bottomTrailing'`) |

Every builder also takes:

* `name` – for lookup with `findView`
* `sizing` – `'auto'`, `'fill'`, a number in points, `[width, height]`, or
  `{ width, height, maxWidth, maxHeight }` to set each axis
* `padding` – a number, `{ horizontal, vertical }`, or `{ top, leading, bottom, trailing }`.
  Sliders, progress views, dividers and spacers can't apply padding; wrap them in a stack
* `offset`, `style`, `accessibility`, `isHidden`, `isEnabled`

In `style`, `font` has a shorthand: a number for the size, or `{ size, weight, family }`. The
other style properties (colours, shape, border, shadow, opacity) are passed through in the
format the scene stores them in. For styled panels, design the panel in the editor and change
it from a script with `findView`.

Labels built in a script default to a single line (`lineLimit: 1`), while labels added in the
editor wrap. Pass `lineLimit: null` for wrapping text.

::: warning UI.toggle
`UI.toggle` is not usable in this runtime version: the panel it is part of fails to load.
Build toggles in the editor and reach them from a script with `findView`.
:::

## Find and update views

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

Name a view, then reach it later through the object's representation to read or change it:

```javascript
var view = entity.representation.findView({ name: 'vol' });
view.setProperty('value', 0.8);
// or, with the accessor shorthand:
view.value = 0.8;
```

`findView` also accepts a view ID as a string or `{ id }`. The editor copies a view's ID with
**Copy Development ID**.

These keys can be read and written:

| View | Keys |
|---|---|
| any view | `isHidden`, `isEnabled`, `opacity` |
| label | `text` |
| button | `title` |
| toggle (Switch style) | `isOn` |
| slider | `value`, `minimumValue`, `maximumValue` |
| text field | `text`, `placeholder` |
| segmented control | `selectedIndex` |
| progress view | `progress` |

Stepper, image, shape, divider, spacer, web view and the stacks have only the keys every view
has. Setting a key a view doesn't have does nothing and logs a warning to the script console.

A few details:

* `isEnabled = false` stops a view taking touches but doesn't dim it. Set `opacity` as well if
  it should look disabled.
* Setting a label's `text` shows the text as given, without markdown. If the label's authored
  text contains a `${variable}`, the next change to that variable draws the authored text
  again. To update a label continuously, give it a `${variable}` and change the variable.

## React to input

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

Subscribe to a view's events:

```javascript
entity.representation.findView({ name: 'vol' }).on('valueChanged', function(e) {
    console.log('slider is now', e.uiValue);
});

entity.representation.findView({ name: 'save' }).on('tap', function() {
    scene.setVariable('saved', true);
});
```

| Event | Views | `e.uiValue` |
|---|---|---|
| `tap` | button | – |
| `valueChanged` | slider, segmented control | the number, or the selected index |
| `toggled` | toggle (Switch style) | `true` or `false` |
| `textChanged` | text field | the text |

Every listener receives `{ uiNodeId, uiInteractionKind, uiValue }`.

Taps on labels, images and shapes, and stepper changes, reach a script through an editor event
instead: add a **UI Interaction** event on the object with a **Run Script** action, and read
`scriptContext.sourceEvent.uiValue`. See [Interaction](https://scenery.app/docs/editor/user-interface/interaction).

## Bind a control to a variable

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

`bind` connects a view's value to a variable:

```javascript
entity.representation.findView({ name: 'vol' }).bind('value', 'volume');
```

For **input controls** the binding works both ways: the control writes the variable as the user
changes it, and the view updates if the variable changes elsewhere. That covers a slider's
`value`, a toggle's `isOn`, a text field's `text` and a segmented control's `selectedIndex`.

For **display views** it works one way, from the variable to the view: a label's `text`, a
button's `title` and a progress view's `progress`. A label or button binding needs a text
variable.

Bindings last as long as the panel. Call `unbind(property)` to remove one sooner. Pass
`{ scope: 'experience' }` as the third argument to bind to an experience variable instead of a
scene variable.

Pair a bound control with a live label (below) to show its value.

## Live labels

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

Label text supports inline variable references that resolve **live** – the label re-renders
automatically whenever the referenced variable changes. No `scene.on('variableChange', …)`
wiring needed.

```javascript
UI.label({ text: 'vol = ${vol}' })
```

`${vol}` is read from the current scene's variables. If `vol` is unset, the label renders
`vol = UNDEFINED`.

### Scopes

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

| Form | Reads from |
|------|-----------|
| `${name}` | Scene variable (default) – set with `scene.setVariable(name, value)` |
| `${g:name}` | Experience variable, kept across scenes – set with `experience.setVariable(name, value)` |

### Filters

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

Pipe the value through a formatter with `|filter` or `|filter(arg)`:

| Filter | Use | Example output (input `0.6789`) |
|--------|-----|--------------------------------|
| `\|fixed(N)` | Trim a float to N decimals (default 2) | `0.68` |
| `\|percent(N)` | Multiply ×100, append `%` (default 0 decimals) | `68%` |
| `\|time` | Seconds → `m:ss` (or `h:mm:ss` ≥ 1h) | (for `185`) `3:05` |
| `\|int` | Truncate toward zero | `0` |
| `\|signed(N)` | Always-signed, N decimals (default 0) | `+1` |

Filters are numeric – applied to a non-numeric variable, they pass the raw value through
unchanged. An unknown filter name does the same.

### Markdown

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

Label text also supports inline markdown: `**bold**`, `*italic*` and `` `code` ``. It is applied
after variables are filled in, so `**${score}**` shows the score in bold. Headings, lists, links
and strikethrough are not drawn. See [Text & Variables](https://scenery.app/docs/editor/user-interface/text).

### Example: bound slider with live readout

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

The slider drives the variable; the label reads from it – no subscription code, the label
re-renders on every change automatically:

```javascript
// Attach to: On Experience Start
scene.setVariable('vol', 0.5);

var panel = createPanel(
    UI.vStack({
        spacing: 12,
        padding: 16,
        children: [
            UI.label({ text: 'Volume: ${vol|fixed(2)}' }),
            UI.slider({ name: 'volume', value: 0.5 })
        ]
    }),
    { panelSize: [400, 160] }
);

var entity = await scene.createEntity(panel);
entity.representation.findView({ name: 'volume' }).bind('value', 'vol');
```

A single label can mix any number of references and plain text; each reference subscribes
independently, so any one variable changing re-renders with the current values of all of them:

```javascript
UI.label({ text: 'Score: ${g:score|int} ,  Timer: ${countdown|time}' })
```

### Sizing panels with dynamic labels

Documentation source: [User Interface](https://scenery.app/docs/scripting/guide/user-interface.md).

An auto-sized panel re-measures itself when its content changes, so a label that starts empty
and later fills in with a wider value makes the panel grow to fit. You can seed a readout with a
placeholder and replace it once real data arrives without the text being cut off.

A **fixed size** is still worth choosing when you want the panel to stay put:

```javascript
createPanel(content, { panelSize: [340, 200] });
```

A live readout whose value changes width – a counter gaining digits, a place name, a temperature
– will otherwise resize its panel each time, which can read as restless if the panel sits in a
fixed spot next to other content. Fixed sizing also gives labels room to grow within a stable
outline, and is required if you want the panel to be scrollable (`isScrollable: true`).

---

Source page: Materials

Source URL: https://scenery.app/docs/scripting/guide/materials.md

# Materials

Documentation source: [Materials](https://scenery.app/docs/scripting/guide/materials.md).

A `Material` is what a surface looks like – color, texture, reflectivity, shader. Use the `Material` builder to construct one inline, reference an existing library material by id, or clone a library material and tweak it.

## Kinds

Documentation source: [Materials](https://scenery.app/docs/scripting/guide/materials.md).

Six factories. Pick the one that matches the look you need.

| Factory | Use for |
|---------|---------|
| `Material.unlit({...})` | Flat-shaded surfaces – UI, billboards, vertex-colored point clouds. Renders the same regardless of scene lighting. |
| `Material.pbr({...})` | Realistic surfaces – metal, plastic, fabric. Responds to scene lighting. |
| `Material.occlusion({...})` | Invisible itself but hides geometry behind it – holdouts, portals. |
| `Material.customShader({...})` | Author-supplied Metal shader functions from a compiled `.metal` library. |
| `Material.materialX({...})` | ShaderGraph material authored in Reality Composer Pro / `.usda`. |
| `Material.video({...})` | Video texture playback. |

## Inline construction

Documentation source: [Materials](https://scenery.app/docs/scripting/guide/materials.md).

Factory + options object reads naturally:

```javascript
// Unlit – single flat color
const red = Material.unlit({ color: '#FF0000' });

// PBR – color + metalness + roughness, no textures
const gold = Material.pbr({
    color: '#FFD700',
    metalness: 1.0,
    roughness: 0.2
});

// PBR – textured
const brick = Material.pbr({
    color: '#FFFFFF',          // tints the texture
    map: 'brick-albedo.png',
    normalMap: 'brick-normal.png',
    roughnessMap: 'brick-rough.png'
});
```

Same chained, if you prefer:

```javascript
const gold = new Material('pbr')
    .color('#FFD700')
    .metalness(1.0)
    .roughness(0.2);
```

## Input shapes

Documentation source: [Materials](https://scenery.app/docs/scripting/guide/materials.md).

**Colors** – `color`, `emissive`, `sheenColor`, `specularColor`:

* `'#RRGGBB'` or `'#RRGGBBAA'`
* `{ r, g, b, a }` with values in 0..1
* `{ colorSpace: 'p3', hex: 'FF6600' }`

**Textures** – `map`, `emissiveMap`, `normalMap`, etc.:

* URL string: `'https://.../texture.png'`
* Asset id string: `'libraryTextureId'`
* With a scale: `{ texture: 'urlOrId', scale: 0.5 }`

**Scalars** – `roughness`, `metalness`, `clearcoat`, `opacity`, `emissiveIntensity`: plain numbers.

## Library reference

Documentation source: [Materials](https://scenery.app/docs/scripting/guide/materials.md).

Materials authored in the experience editor are referenced by id directly – no inline construction needed:

```javascript
// Apply a library material to a mesh
await scene.createEntity(createMesh({
    ...,
    materials: ['myLibraryMaterialId']
}));
```

Or fetch one with `scene.getMaterial(id)` to inspect:

```javascript
const mat = scene.getMaterial('myLibraryMaterialId');
console.log(mat); // → Material(pbr 'My Material' id=..., color=#FFAA00, roughness=0.3)
```

## Clone → tweak → apply

Documentation source: [Materials](https://scenery.app/docs/scripting/guide/materials.md).

To override a library material for a single entity (without mutating the library entry), clone it first:

```javascript
const base = scene.getMaterial('redMatId');
const brighter = base.clone()
    .emissive('#FF0000')
    .emissiveIntensity(2);

await entity.representation.setMaterial(brighter);
```

`.clone()` deep-copies the material with a fresh `id`. The original library material is untouched.

## ShaderGraph (MaterialX) parameters

Documentation source: [Materials](https://scenery.app/docs/scripting/guide/materials.md).

ShaderGraph materials authored in Reality Composer Pro expose promoted inputs. Set constant values via `setParameter(name, value, typeHint?)`:

```javascript
const mat = scene.getMaterial('myShaderGraphMatId').clone()
    .setParameter('intensity', 0.6)
    .setParameter('tintColor', '#FF00FF', { type: 'color' })
    .setParameter('offset', [0.1, 0.2, 0], { type: 'vector3' });
```

The same `setParameter` works on `customShader` materials too – the Material auto-routes to the right options blob based on its kind.

**Type hints** override inferred types:
`{ type: "float" | "int" | "vector2" | "vector3" | "vector4" | "color" | "boolean" | "string" }`

For runtime variable bindings (slider drives a parameter), use `entity.representation.bindMaterialParameter(parameterName, variableId)` – different path, lives on the entity, ties into the variable system.

## Runtime swap

Documentation source: [Materials](https://scenery.app/docs/scripting/guide/materials.md).

Replace an entity's material at runtime:

```javascript
// Cycle materials every 2 seconds
const palette = [
    Material.unlit({ color: '#4287F5' }),
    Material.pbr({ color: '#42F578', metalness: 0.5, roughness: 0.3 }),
    Material.unlit({ color: '#F54242' })
];
let i = 0;
scene.on('schedule', { interval: 2 }, async function() {
    i = (i + 1) % palette.length;
    await entity.representation.setMaterial(palette[i]);
});
```

`setMaterial` accepts a `Material` instance, a library ref-id string, or `{ id, target? }`. `setMaterials([...])` for multiple at once.

## Introspection

Documentation source: [Materials](https://scenery.app/docs/scripting/guide/materials.md).

```javascript
console.log(material);                       // → Material(pbr id=..., color=#FF6600, roughness=0.3)
console.log(JSON.stringify(material, null, 2)); // → full material JSON

material.kind;          // → 'pbr'
material.id;            // → 'AB12CD34'
material.baseColor;     // → { color: { colorSpace: 'p3', hex: 'FF6600' } }
material.materialXOptions?.parameters; // → { intensity: { ... } } for materialX
```

For setter names that conflict with property names (`roughness`, `opacity`, `clearcoat`, `emissiveIntensity`), read via `material.data.<field>` – e.g. `material.data.roughness?.scale`.

## Target

Documentation source: [Materials](https://scenery.app/docs/scripting/guide/materials.md).

By default a material applies to all models on an entity. Override for multi-model entities:

```javascript
Material.pbr({ color: '#FF0000' })
    .target({ type: 'firstModel' });

Material.pbr({ color: '#0000FF' })
    .target({ type: 'selectedModels', models: ['windshield'], materialSlots: [0] });
```

---

Source page: Mesh Instancing

Source URL: https://scenery.app/docs/scripting/guide/instancing.md

# Mesh Instancing

Documentation source: [Mesh Instancing](https://scenery.app/docs/scripting/guide/instancing.md).

Instancing renders many copies of one object in a single draw – thousands of them stay cheap,
because the GPU draws the shared mesh once and stamps it at each transform. Use it for fields,
crowds, particles, and any procedural scatter.

## Scatter copies

Documentation source: [Mesh Instancing](https://scenery.app/docs/scripting/guide/instancing.md).

Give one object the set of transforms to render it at with `setInstances(Instances.transforms([...]))`.
Each transform is a `Vector3` position (or a full transform):

```javascript
var base = await scene.createEntity(
    createBox(0.03, 0.03, 0.03).anchor(Anchor.position(0, 0, -1.5))
);

var spots = [];
var count = 1000;
var goldenAngle = Math.PI * (3 - Math.sqrt(5));
for (var i = 0; i < count; i++) {
    var r = 0.4 * Math.sqrt(i / count);
    var a = i * goldenAngle;
    spots.push(new Vector3(r * Math.cos(a), 0, r * Math.sin(a)));
}
base.setInstances(Instances.transforms(spots));
```

Call `setInstances` again with a new set to re-scatter – for example, from an
`On Render` handler or a slider's `valueChanged`.

## Moving instances from a kernel

Documentation source: [Mesh Instancing](https://scenery.app/docs/scripting/guide/instancing.md).

Rebuilding the transform list in JavaScript every frame gets expensive once there are thousands of
copies. `entity.instances` hands the transform buffer to a [compute kernel](https://scenery.app/docs/scripting/guide/compute)
instead, so the work happens on the GPU. It is `null` until `setInstances(...)` has run.

```javascript
// Attach to: On Experience Start
var instances = base.instances;
var threads = 64;
var groups = Math.ceil(instances.count / threads);

// A `.write` buffer arrives uninitialised, so keep the authored placement to compute from.
var authored = Buffer.float32(instances.count * 16, 0);
var snapshot = await Kernel.fromSource({
    source: `
        #include <metal_stdlib>
        using namespace metal;
        struct Uniforms { float count; };

        kernel void instanceSnapshot(constant Uniforms& U   [[buffer(0)]],
                                     device const float4x4* src [[buffer(1)]],
                                     device float4x4* dst       [[buffer(2)]],
                                     uint i [[thread_position_in_grid]]) {
            if (i >= (uint)U.count) { return; }
            dst[i] = src[i];
        }
    `,
    functionName: 'instanceSnapshot'
});

snapshot.run({
    uniforms: new Float32Array([instances.count]),
    inputBuffers:  { src: instances.read },
    outputBuffers: { dst: authored },
    threadGroups: [groups, 1, 1],
    threadsPerThreadgroup: [threads, 1, 1]
});
```

A wave kernel then reads that snapshot and writes the live buffer each frame. Each entry is one
`float4x4`, column-major, so column 3 holds the translation:

```
// Inside the wave kernel
float4x4 m = orig[i];
m[3].y = m[3].y + sin(U.time * 2.0 + length(m[3].xz) * U.spatialFreq) * U.amplitude;
out[i] = m;
```

::: tip The buffer is not in metres
It holds the instanced mesh's own units. On a primitive those are metres, but a model scaled to a
fitting box can be hundreds to one – one real model measured 407 buffer units to the metre, so an
8 cm wave written as `0.08` moved each copy by 0.2 mm and looked frozen.

`instances.localToMesh` is the conversion. Its scale, element 0, is the factor:

```javascript
var perMetre = instances.localToMesh[0];
var uniforms = new Float32Array([
    0,                                   // time
    0.08 * perMetre,                     // an 8 cm wave
    (Math.PI * 2 / 0.63) / perMetre,     // a 63 cm wavelength
    instances.count
]);
```

`instances.meshToLocal` goes the other way, for reading a distance back out. Both are identity on
a primitive, so converting costs nothing and keeps the same script correct on a model.
:::

::: tip Models need Flatten switched on
Instancing works on one mesh, the same way it does everywhere else: three.js instances one
geometry, Godot's `MultiMesh` takes one mesh, and Apple's own example collapses a twelve-mesh
robot before instancing it.

A primitive is always one mesh, so nothing is needed. A model keeps whatever node tree it was
exported with, so turn on its **Flatten** adjustment, which loads it as a single mesh. Otherwise
nothing is instanced, the console names the meshes it found, and `rep.instances` stays `null`.

To instance one node of an unflattened model instead, use
`rep.findChild(name).setInstances(...)`. That takes matrices in **that node's own space**, which
can be far from metres – a node scaled by its exporter can be thousands of times smaller.
:::

The bounds are worked out when `setInstances` runs and do not follow instances a kernel moves, so
copies pushed outside the original extent are culled and lose their shadows.

## Instancing vs cloning

Documentation source: [Mesh Instancing](https://scenery.app/docs/scripting/guide/instancing.md).

Instances are **rendering-only**: they share the base object's mesh and material and are not
individual entities. You can't tap one, script one, or give one its own physics body. When you
need copies that behave independently – each collidable, tappable, or separately animated – use
[`entity.clone()`](https://scenery.app/docs/scripting/api/objectentity) instead. Rule of thumb: dozens of interactive copies →
clone; hundreds or thousands of visual copies → instance.

::: tip Shadows on dense fields
A large instanced field can alias the shared shadow map into streaks. Turn the projected
shadow off for the base object so the field stays clean:

```javascript
createBox(0.03, 0.03, 0.03).shadow({ directional: false });
```

:::

Instancing needs iOS 26, iPadOS 26, macOS 26 or visionOS 26. Gate a portable script with
`environment.features.has('instancing')` – see [Feature Detection](https://scenery.app/docs/scripting/guide/feature-detection).

---

Source page: Gaussian Splats

Source URL: https://scenery.app/docs/scripting/guide/splats.md

# Gaussian Splats

Documentation source: [Gaussian Splats](https://scenery.app/docs/scripting/guide/splats.md).

A splat capture is a scanned object or place, stored as hundreds of thousands of tiny coloured
blobs rather than as a mesh. Place one in a scene like any other object. From a script you can
reach the capture's per-splat data and drive it with a [compute kernel](https://scenery.app/docs/scripting/guide/compute),
which is how reveals, dissolves and interactive effects are built.

## Reaching a capture

Documentation source: [Gaussian Splats](https://scenery.app/docs/scripting/guide/splats.md).

`representation.splat` is the handle. It is `null` on any representation that is not a splat, and
on a device that cannot render them, so a single check covers both:

```javascript
// Attach to: On Experience Start
var entity = scene.findEntity({ name: 'Statue' });
await entity.waitUntilReady();

var splat = entity.representation.splat;
if (!splat) {
    console.log('No splat capture here');
    return;
}
console.log(splat.count + ' splats');
```

While a capture is still loading the handle exists but reports `count === 0`, so wait for the
representation before reading anything from it.

## What each splat carries

Documentation source: [Gaussian Splats](https://scenery.app/docs/scripting/guide/splats.md).

Five attributes, each a buffer you can bind to a kernel:

| Attribute | Per splat | Notes |
|---|---|---|
| `position` | 3 floats | Centre of the blob, in the capture's own space |
| `scale` | 3 floats | Size per axis, stored logarithmically |
| `rotation` | 4 floats | Orientation, stored `w` first |
| `opacity` | 1 float | Stored pre-sigmoid, so `0` is half opaque |
| `sphericalHarmonics` | `itemSize` floats | View-dependent colour |

Two of those storage formats matter as soon as you write a kernel:

* **Scale is a logarithm.** Multiplying a splat's size means *adding* to its scale, so half size is
  `scale - log(2)`, not `scale * 0.5`.
* **Opacity is a logit.** Fade the alpha rather than the stored value, or every splat sits near
  half opaque for most of the ramp and then pops at the end.

`splat.boundingBox` gives the capture's extent, which is what radial and staggered effects key off.
Use it rather than the representation's bounding box, which measures an internal proxy.

## Animating a capture

Documentation source: [Gaussian Splats](https://scenery.app/docs/scripting/guide/splats.md).

Each attribute vends `.read` and `.write` tokens for a kernel's buffer maps, exactly as a
[texture](https://scenery.app/docs/scripting/api/texturebinding) does. A `.write` buffer arrives uninitialised, so an
effect that reads the live buffer and adds to it drifts further from the original every frame and
never lands back on the authored look. Copy the pristine attributes into your own buffers once,
then compute every frame from that snapshot, and progress 1 writes the originals back exactly.

Note the types in the snapshot kernel: a `float3` declaration aligns to 16 bytes and reads garbage
against the 12-byte stride, so position and scale are `packed_float3`. The bounds guard matters
too, since a thread past the end writes into memory the renderer is using.

```javascript
// Attach to: On Experience Start
var threads = 64;
var groups = Math.ceil(splat.count / threads);

var authoredPos = Buffer.float32(splat.count * 3, 0);
var authoredScale = Buffer.float32(splat.count * 3, 0);
var authoredOpacity = Buffer.float32(splat.count, 0);

var snapshot = await Kernel.fromSource({
    source: `
        #include <metal_stdlib>
        using namespace metal;
        struct Uniforms { float count; };

        kernel void splatSnapshot(constant Uniforms& U                  [[buffer(0)]],
                                  device const packed_float3* srcPos    [[buffer(1)]],
                                  device const packed_float3* srcScale  [[buffer(2)]],
                                  device const float* srcOpacity        [[buffer(3)]],
                                  device packed_float3* dstPos          [[buffer(4)]],
                                  device packed_float3* dstScale        [[buffer(5)]],
                                  device float* dstOpacity              [[buffer(6)]],
                                  uint i [[thread_position_in_grid]]) {
            if (i >= (uint)U.count) { return; }
            dstPos[i] = srcPos[i];
            dstScale[i] = srcScale[i];
            dstOpacity[i] = srcOpacity[i];
        }
    `,
    functionName: 'splatSnapshot'
});

snapshot.run({
    uniforms: new Float32Array([splat.count]),
    inputBuffers: {
        srcPos: splat.position.read,
        srcScale: splat.scale.read,
        srcOpacity: splat.opacity.read
    },
    outputBuffers: {
        dstPos: authoredPos,
        dstScale: authoredScale,
        dstOpacity: authoredOpacity
    },
    threadGroups: [groups, 1, 1],
    threadsPerThreadgroup: [threads, 1, 1]
});
```

Your effect kernel then reads those buffers and writes `splat.position.write` and friends each
frame. Fading uses the alpha rather than the stored value:

```
// Inside the effect kernel, with `progress` from a uniform
float origAlpha = 1.0 / (1.0 + exp(-origOpacity[i]));
float alpha = clamp(origAlpha * progress, 1e-6, 1.0 - 1e-6);
outOpacity[i] = log(alpha / (1.0 - alpha));
```

Written values stay put. Once a dispatch lands, the capture keeps those values with no further
dispatches, so a one-shot reveal can stop when it finishes.

## Known limitations

Documentation source: [Gaussian Splats](https://scenery.app/docs/scripting/guide/splats.md).

* **Displacement is clipped.** The volume the renderer culls against is fixed when the capture
  loads and does not follow splats a kernel moves, so an effect that pushes splats outward meets
  a hard edge. Gather, swirl and shrink read well; explosions do not.
* **A scene holds up to eight captures.** Past that they stop rendering, so budget them like
  video rather than like props.
* **Captures are placed in the editor, not from a script.** There is no script-side factory for
  one yet, so find a placed capture with `scene.findEntity(...)` and drive it from there.
* **Colour is the expensive attribute.** Changing it means rewriting every spherical-harmonic
  coefficient for every splat, because a `.write` buffer arrives uninitialised. Position, scale
  and opacity are far cheaper to animate.

Splat captures need iOS 27, iPadOS 27, macOS 27 or visionOS 27. Gate a portable script on the
handle itself, since `representation.splat` is `null` wherever they are unavailable.

---

Source page: Paths & Splines

Source URL: https://scenery.app/docs/scripting/guide/paths.md

# Paths & Splines

Documentation source: [Paths & Splines](https://scenery.app/docs/scripting/guide/paths.md).

Build a smooth curve through a set of control points and drive an object along it. Paths are a
runtime construct – `scene.createPath(...)` returns a handle you query and hand to
`entity.followPath(...)`; they aren't saved in the experience.

## Create a path

Documentation source: [Paths & Splines](https://scenery.app/docs/scripting/guide/paths.md).

Pass at least two control points. The curve is a smooth spline through them:

```javascript
var path = scene.createPath({
    points: [
        new Vector3(-0.6, 0, -1.2),
        new Vector3(-0.2, 0.4, -1.2),
        new Vector3(0.2, -0.2, -1.4),
        new Vector3(0.6, 0.3, -1.2)
    ]
});
```

`createPath` returns `null` if you pass fewer than two valid points.

## Query the curve

Documentation source: [Paths & Splines](https://scenery.app/docs/scripting/guide/paths.md).

| Member | Result |
| --- | --- |
| `path.length` | Total arc length, in metres. |
| `path.point(t)` | Position at parameter `t` (0…1 across the whole path). |
| `path.pointAtDistance(d)` | Position at arc-length distance `d` (0…`length`) – constant-speed spacing. |
| `path.tangent(t)` | Unit direction of travel at parameter `t`. |

```javascript
console.log('length', path.length.toFixed(2), 'm');

// Drop a marker every fifth of the way along, evenly spaced by distance.
for (var i = 0; i <= 5; i++) {
    var p = path.pointAtDistance((i / 5) * path.length);
    await scene.createEntity(createSphere(0.01).anchor(Anchor.position(p.x, p.y, p.z)));
}
```

## Follow a path

Documentation source: [Paths & Splines](https://scenery.app/docs/scripting/guide/paths.md).

`entity.followPath(path, options)` animates an object along the curve:

```javascript
var box = await scene.createEntity(
    createBox(0.05, 0.05, 0.05).anchor(Anchor.position(0, 0, 0))
);

box.followPath(path, {
    duration: 4,
    constantSpeed: true,    // even speed regardless of control-point spacing (default true)
    alignsToTangent: true,  // nose points along the direction of travel (default false)
    timing: 'easeInOut',    // linear | easeIn | easeOut | easeInOut
    repeat: true            // true to loop, or a number of cycles
});
```

::: tip Anchor anywhere
`followPath` positions the object in world space, so the anchor you give the object only sets
its starting reference – the path drives it from there.
:::

---

Source page: Location

Source URL: https://scenery.app/docs/scripting/guide/location.md

# Location

Documentation source: [Location](https://scenery.app/docs/scripting/guide/location.md).

Read the device's geographic location from a script through `environment.location`. Coarse
reads ride the base location grant; precise accuracy is a separate, explicit opt-in.

## Request access and read a fix

Documentation source: [Location](https://scenery.app/docs/scripting/guide/location.md).

Ask for access once, then read the current location. Reads never prompt on their own – call
`requestAccess()` first.

```javascript
await environment.location.requestAccess();
var here = await environment.location.current();
console.log(here.latitude, here.longitude, '±' + here.horizontalAccuracy + 'm');
```

`current()` resolves a `GeoCoordinate`. On a live fix it also carries `horizontalAccuracy`
(metres) and `timestamp`; those are `null` on a coordinate you construct yourself.

## Coordinates: distance and bearing

Documentation source: [Location](https://scenery.app/docs/scripting/guide/location.md).

`GeoCoordinate` carries the great-circle helpers, so you can measure against a point of
interest without any external maths:

```javascript
var target = new GeoCoordinate(48.1372, 11.5756);   // latitude, longitude
console.log('distance', Math.round(here.distanceTo(target)), 'm');   // metres
console.log('bearing', Math.round(here.bearingTo(target)) + '°');    // 0–360 from north
```

## Watch position

Documentation source: [Location](https://scenery.app/docs/scripting/guide/location.md).

Observe location continuously – for example, reveal something when the user gets close:

```javascript
var target = new GeoCoordinate(48.1372, 11.5756);
var sub = environment.location.watch(function(here) {
    if (here.distanceTo(target) < 50) {
        sub.stop();
        scene.setVariable('arrived', true);
    }
});
```

Call `sub.stop()` to end the subscription.

## Precise accuracy

Documentation source: [Location](https://scenery.app/docs/scripting/guide/location.md).

The base grant may be coarse. When your experience genuinely needs precise positioning, ask
for it explicitly – the user sees a confirmation carrying your `reason`, then the system
accuracy prompt:

```javascript
var precise = await environment.location.requestPreciseAccess({
    reason: 'to guide you to nearby points of interest'
});
if (precise) {
    var fix = await environment.location.current();
}
```

::: tip Ask only when needed
Request precise accuracy at the moment the feature needs it, not on load – the prompt reads
better in context, and coarse location is enough for most distance/region checks.
:::

---

Source page: Tracking

Source URL: https://scenery.app/docs/scripting/guide/tracking.md

# Tracking

Documentation source: [Tracking](https://scenery.app/docs/scripting/guide/tracking.md).

`scene.tracking` reads live tracking data from script – articulated hand joints, and face blendshapes when the scene runs in a face context. It is the author-facing entry point for both; you never talk to the underlying provider directly.

Two things it is useful for: reading hand or face data **without** planting an anchored object, and controlling when the hand-tracking provider is running.

## Hands

Documentation source: [Tracking](https://scenery.app/docs/scripting/guide/tracking.md).

Hand tracking is **currently available on Apple Vision Pro only**, and it is opt-in – nothing is tracked until a script asks for it. Gate portable scripts on the feature flag:

```javascript
// Attach to: On Experience Start
if (environment.features.has("handTracking")) {
    await scene.tracking.hands.enable();   // resolves when tracking is live
}
```

`enable()` rejects if the device cannot track hands or the person declines permission, so handle the rejection rather than assuming it succeeded:

```javascript
// Attach to: On Experience Start
try {
    await scene.tracking.hands.enable();
} catch (e) {
    console.log("Hand tracking unavailable: " + e.message);
}
```

Once tracking is live, read the hands each frame:

```javascript
// Attach to: On Render
var right = scene.tracking.hands.right;      // null when that hand isn't tracked
if (right) {
    var tip = right.joints.indexFingerTip.worldTransform.position;
    console.log("Right index tip: " + tip);
}
```

### Hands reference

Documentation source: [Tracking](https://scenery.app/docs/scripting/guide/tracking.md).

| Member | Type | Description |
|---|---|---|
| `enable()` | `Promise<void>` | Opt into hand tracking. Idempotent. Resolves when the provider is running and authorized; rejects if denied or unsupported. |
| `disable()` | – | Drop this script's request. Fire-and-forget. |
| `isSupported` | `boolean` | Whether this device can track hands at all. |
| `active` | `boolean` | Whether the provider is authorized and running. |
| `enabled` | `boolean` | Whether this script currently requests hand tracking. |
| `left` | [`AnchorData`](https://scenery.app/docs/scripting/api/anchordata) | `null` | Left hand, or `null` when it isn't tracked. |
| `right` | [`AnchorData`](https://scenery.app/docs/scripting/api/anchordata) | `null` | Right hand, or `null` when it isn't tracked. |
| `anchors` | `Array<`[`AnchorData`](https://scenery.app/docs/scripting/api/anchordata)`>` | All currently tracked hands. |

::: tip active vs enabled vs a hand being visible
These are three different questions – `enabled` is what your script asked for, `active` is whether tracking is actually running, and a `left` / `right` of `null` means that particular hand isn't in view right now. Poll `active` to notice permission being revoked or tracking being lost after a successful `enable()`.
:::

## Face

Documentation source: [Tracking](https://scenery.app/docs/scripting/guide/tracking.md).

Face data needs no opt-in – it is already flowing whenever the scene runs in a face tracking context, so there is nothing to enable.

```javascript
// Attach to: On Render
var face = scene.tracking.face.current;
if (face) {
    console.log("Face at: " + face.worldTransform.position);
}
```

### Face reference

Documentation source: [Tracking](https://scenery.app/docs/scripting/guide/tracking.md).

| Member | Type | Description |
|---|---|---|
| `isSupported` | `boolean` | Whether the scene can deliver face tracking data. |
| `active` | `boolean` | Whether a face is currently tracked. |
| `current` | [`AnchorData`](https://scenery.app/docs/scripting/api/anchordata) | `null` | The current face anchor – blendshapes and eye transforms – or `null`. |

## Coordinate spaces

Documentation source: [Tracking](https://scenery.app/docs/scripting/guide/tracking.md).

Joint and face positions are in **world space**. To use them against an object you created, convert into that object's local frame first – see [Coordinate spaces](https://scenery.app/docs/scripting/guide/vectors-transforms#coordinate-spaces).

## The lower-level equivalent

Documentation source: [Tracking](https://scenery.app/docs/scripting/guide/tracking.md).

`scene.tracking` is a convenience layer over `scene.getAnchors(...)`, which stays available if you would rather filter the anchor list yourself:

```javascript
// Attach to: On Render
var anchors = scene.getAnchors("hand");
for (var i = 0; i < anchors.length; i++) {
    if (anchors[i].chirality === "right") {
        console.log("Right hand at: " + anchors[i].worldTransform.position);
    }
}
```

The difference is lifecycle: only `scene.tracking.hands` can turn the hand-tracking provider on and off. `getAnchors("hand")` returns an empty list until something has enabled it.

## Related

Documentation source: [Tracking](https://scenery.app/docs/scripting/guide/tracking.md).

* [Anchors](https://scenery.app/docs/editor/anchors) – anchoring an object to a hand joint instead of reading joints yourself
* [Feature Detection](https://scenery.app/docs/scripting/guide/feature-detection) – the full capability matrix
* [Examples](https://scenery.app/docs/scripting/guide/examples) – worked hand-tracking snippets

---

Source page: Compute Kernels

Source URL: https://scenery.app/docs/scripting/guide/compute.md

# Compute Kernels

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

GPU compute lets scripts run a function across thousands of threads in parallel – typical uses are heightmap textures, particle simulations, vertex displacement on a dynamic mesh, or "how many triangles did marching cubes emit this frame" atomic counters.

::: warning Apple GPUs only, for now
Compute kernels are **currently available on Apple GPUs only** – web / WebXR support is planned but **not yet available**. Today you author the kernel directly in **Metal Shading Language (MSL)**, which makes this the one corner of the scripting API that isn't fully engine-agnostic. Always gate compute behind `environment.features.has('compute')` ([Feature Detection](https://scenery.app/docs/scripting/guide/feature-detection)) so a script degrades cleanly on devices – and platforms – that don't support it yet.
:::

```javascript
// Attach to: onStart

if (!environment.features.has('compute')) {
    console.warn('compute not supported – bailing');
    return;
}

const heightMap = await Texture.compute({
    pixelFormat: 'rgba8Unorm',
    width: 256, height: 256
});

const kernel = await Kernel.fromSource({
    source: `
        #include <metal_stdlib>
        using namespace metal;
        struct Uniforms { float time; };
        kernel void wave(constant Uniforms& U                       [[buffer(0)]],
                         texture2d<float, access::write> outTex     [[texture(0)]],
                         uint2 gid                                  [[thread_position_in_grid]])
        {
            float2 uv = float2(gid) / float2(outTex.get_width(), outTex.get_height());
            float r = 0.5 + 0.5 * sin(U.time + uv.x * 6.28);
            outTex.write(float4(r, uv.y, 0.5, 1.0), gid);
        }`,
    functionName: 'wave'
});

const uniforms = new Float32Array(1);
scene.on('render', function () {
    uniforms[0] = scene.time;
    kernel.run({
        uniforms: uniforms,
        outputTextures: { outTex: heightMap.write },
        threadGroups: [16, 16, 1]
    });
});
```

## Dispatch entry points

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

Two ways to dispatch a kernel:

* **`mesh.runCompute(kernel, options)`** – when the kernel writes mesh attribute buffers (`storage: "compute"` attributes) or the mesh's index buffer. The mesh sits in `buffer(1...)` slots.
* **`kernel.run(options)`** – standalone compute. No mesh involvement. Use for texture generation, particle simulation, atomic counters, anything that doesn't displace mesh geometry.

Both paths share the same options shape; `kernel.run` simply skips the mesh-related slots.

## MSL slot ordering – strict and positional

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

Author-side bindings map to MSL `[[buffer(N)]]` / `[[texture(N)]]` indices in a fixed order:

| Slot | Source | Notes |
|---|---|---|
| `buffer(0)` | `uniforms: Float32Array` | Always slot 0, packed as raw bytes |
| `buffer(1..A)` | `outputs[]` (mesh attributes) | Only for `mesh.runCompute`. Order matches the array – `outputs: ['position', 'normal']` binds `position` at 1, `normal` at 2 |
| `buffer(A+1)` | mesh index buffer | Only when `outputIndices: true` and the mesh has `indexCapacity > 0` |
| `buffer(A+2..)` | `inputBuffers` then `outputBuffers` | Both maps merged into one continuous block, inputs first |
| `texture(0..)` | `inputTextures` then `outputTextures` | Separate slot space from buffers, inputs first |

Match your MSL signature to this order. Slot indices the kernel declares (`[[buffer(N)]]`) must match what the runtime binds.

## Common pitfalls

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

### "No outputs declared" warning

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

```
kernel.run: no outputs declared (outputs / outputIndices / outputBuffers / outputTextures all empty).
Kernel will run but nothing it writes is observable – likely a bug.
```

A dispatch without any write target runs the kernel but has no observable effect – the GPU reads inputs, computes values, then throws them away. Almost always a missed wiring. Add the destination map you meant to (`outputBuffers: { triCount: counter }`, `outputTextures: { outTex: heightMap.write }`, etc.).

### Slot ordering off by one

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

MSL kernels declare slot indices by hand (`constant Uniforms& U [[buffer(0)]]`). If you change the JS dispatch options – add an attribute to `outputs`, toggle `outputIndices`, add an `inputBuffer` – every later slot index shifts. Always re-check the MSL signature when you change the dispatch options.

### Texture token swap (`.read` vs `.write`)

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

A texture handle has two binding tokens: `.read` (sample inside the kernel) and `.write` (write to inside the kernel). They route to different Metal APIs under the hood. Passing `.read` where you meant `.write` (or vice versa) means the kernel binds the texture in the wrong access mode – usually a silent no-op for writes, or undefined sampling for reads. Token name = what the kernel does with it.

### Uniforms must be a `Float32Array`

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

`uniforms` is packed as raw bytes. The runtime only accepts a `Float32Array`. Plain JS arrays and other typed arrays trigger a warn and skip. To pack mixed types (a float and an integer index, say), reinterpret memory inside MSL or use an `inputBuffers` entry instead.

### `outputs` only valid with a mesh

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

`outputs: [...]` and `outputIndices: true` are mesh-attribute writes. They mean nothing for `kernel.run(...)` (no mesh) and are silently ignored there. If you want raw output, use `outputBuffers: { ... }` with a `Buffer` handle.

### Forgetting `await` on factory promises

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

`Texture.compute(...)`, `Kernel.fromSource(...)`, and `Kernel.fromAsset(...)` all return Promises. Without `await`, downstream code touches a Promise object – `kernel.run(...)` fails, `texture.write` is undefined. The `_promisify` wrapper logs nothing helpful here; just remember the `await`.

### Buffer size mismatches on `writeSync`

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

```
Buffer.writeSync: undersize write – source has 2 elements, buffer holds 4.
Copying 2 elements; tail of buffer UNTOUCHED.
```

The warn is loud on purpose. Seeding partial data is usually a bug – match `src.length` to the buffer's declared element count.

## Capability gate

Documentation source: [Compute Kernels](https://scenery.app/docs/scripting/guide/compute.md).

Always gate compute calls with `environment.features.has('compute')` – devices below the Apple 7 GPU family or below iOS 18 / visionOS 2 / macOS 15 return `false`. The Swift bridge throws cleanly if you slip past, but the JS-side gate keeps your script structure honest.

---

Source page: Feature detection

Source URL: https://scenery.app/docs/scripting/guide/feature-detection.md

# Feature detection

Documentation source: [Feature detection](https://scenery.app/docs/scripting/guide/feature-detection.md).

Not every Scenery feature is available on every platform or every runtime
version. Compute shaders are gated behind a future runtime; hand tracking
needs a visionOS device; SharePlay is stripped out of App Clip builds.

Authors branch on capability through a single string-keyed registry on
`environment.features`:

```javascript
if (environment.features.has('compute')) {
    mesh.runCompute('advect', { uniforms });
} else {
    stepOnCPU();
}
```

Unknown feature names return `false` rather than throwing – this matches
WebGPU's `Set.has` semantic and lets forward-looking scripts query
features that may land in a future runtime version without crashing on
today's runtime.

## Listing what's available

Documentation source: [Feature detection](https://scenery.app/docs/scripting/guide/feature-detection.md).

```javascript
console.log(environment.features.list());
// → ['sharedActivities']
```

`list()` returns every feature string the current runtime + device
actually supports. Use it when debugging ("why isn't my branch firing?")
or when reflecting capability state into telemetry.

## Current feature strings

Documentation source: [Feature detection](https://scenery.app/docs/scripting/guide/feature-detection.md).

| Feature | Today | Notes |
|---------|-------|-------|
| `compute` | Apple-family 7+ devices on iOS 18 / visionOS 2 / macOS 15+ | GPU compute-kernel dispatch. `Kernel.fromSource(...)` / `Kernel.fromAsset(...)` compile a kernel; `mesh.runCompute(kernel, options)` dispatches it against `storage: "compute"` attribute buffers and / or compute textures. |
| `sharedActivities` | platform-dependent | Multi-user / SharePlay support. `false` in App Clip and any build without the shared-activities trait. |
| `cameraFeed` | iOS / iPadOS | Live camera-feed texture (via `Texture.cameraFeed()`). Uses the AR camera capture; not available on Mac Catalyst (no AR camera) or visionOS (different passthrough surface). |
| `screenGestures` | iPhone / iPad / Mac | Screen-space `scene.on('pan'\|'pinch'\|'rotate')` and the `consume` camera claim. Not delivered on visionOS, where input is spatial (eyes + pinch) – use UI panels / buttons there instead. |
| `instancing` | iOS 26 / visionOS 26 / macOS 26+ | GPU mesh instancing via `rep.setInstances(Instances.transforms([...]))` – render hundreds of copies of a mesh cheaply. Rendering-only (no physics, collision, or per-instance identity); use `entity.clone()` for objects the user interacts with. |
| `splats` | iOS 27 / visionOS 27 / macOS 27, devices only | Gaussian splat captures via `createSplat(...)`. Neither simulator can render them. Check it before creating a splat, so a script can place something else instead. |

Once a splat exists, the handle answers the same question for that object:
`representation.splat` is `null` both on a representation that is not a capture and on a system
that cannot render one:

```javascript
var splat = entity.representation.splat;
if (!splat) {
    return;
}
```

More feature strings land here as their backends wire up. A name not in
the table above always returns `false` from `has()` – never throws.

## Pattern

Documentation source: [Feature detection](https://scenery.app/docs/scripting/guide/feature-detection.md).

Feature detection is the right tool for runtime branching across
platforms and capability classes. Use it for:

* Hardware capabilities the device may or may not have (compute, future:
  `handTracking`, `planeDetection`, `sceneReconstruction`).
* Build-trait features that strip out of compact targets
  (`sharedActivities`, future: `gamification`).
* Runtime-version features (anything reserved for a later API bump).

For pure platform identity – "am I on visionOS?" – read
`environment.hostingPlatform` directly:

```javascript
if (environment.hostingPlatform === 'visionOS') {
    enableHandTrackingUI();
}
```

When you care about the **interaction model** rather than the exact OS,
`environment.deviceCategory` is usually the cleaner branch – `'handheld'`
(iPhone, iPad), `'spatial'` (Apple Vision Pro and other headsets), or
`'desktop'` (Mac, desktop web). It collapses several hosts into the axis
that actually drives your decision:

```javascript
if (environment.deviceCategory === 'spatial') {
    showControlPanel();   // spatial input – use UI, not screen gestures
}
```

Platform identity is single-valued (you're on exactly one host, in one
category) and so stays a string property; capabilities form a set and
live in the registry. Reach for a capability flag like
`environment.features.has('screenGestures')` when you want the precise
"does this specific API work here" answer rather than a form-factor guess.

---

Source page: Examples

Source URL: https://scenery.app/docs/scripting/guide/examples.md

# Examples

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Complete patterns for common scripting tasks. Each example is self-contained – attach to the indicated event and it works.

## Entity hierarchy and lookup

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Every object in the scene is an **Entity** (the anchor container). Each entity has one or more **Representations** (the visuals inside it – models, shapes, images, audio, etc.).

```
scene
└─ Entity ("MyObject")          ← scene.findEntity({ name: "MyObject" })
   ├─ representation (primary)  ← entity.representation
   ├─ Representation "Audio1"   ← entity.findRepresentation({ name: "Audio1" })
   └─ Representation "SubModel" ← entity.findRepresentation({ name: "SubModel" })
```

::: warning Common Gotcha
`scene.findEntity` only finds **top-level entities** – not nested representations inside them. Find the parent entity first, then use `findRepresentation` to navigate.
:::

Find the parent entity first, then navigate to the representation:

```javascript
// WRONG – Audio1 is a representation, not a top-level entity
var audio = scene.findEntity({ name: "Audio1" }); // null!

// RIGHT – find the parent entity, then the nested representation
var parent = scene.findEntity({ name: "MyObject" });
var audio = parent.findRepresentation({ name: "Audio1" });
audio.isEnabled = true;
```

Look up by ID or name:

```javascript
// Entity lookup
var entity = scene.findEntity("ABC123");          // by ID
var entity = scene.findEntity({ name: "MyBox" }); // by name

// Representation lookup (from entity)
var rep = entity.representation;                         // primary (first) representation
var rep = entity.findRepresentation("DEF456");           // by ID
var rep = entity.findRepresentation({ name: "Wheel" });  // by name
```

Explore a model's internal hierarchy:

```javascript
var entity = scene.findEntity({ name: "Robot" });
var rep = entity.representation;

// List all nested children (bones, sub-meshes, etc.)
var names = rep.getChildNames();
console.log(names); // ["torso", "arm_left", "arm_right", ...]

// Access a specific child
var arm = rep.findChild("arm_left");
arm.transform = Transform({ rotation: Rotation(0, 0, Math.PI / 4) });
```

### Event context: objectEntity vs representationEntity

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

When a script runs from an event (tap, collision, etc.), the event data includes both:

```javascript
// objectEntity = the top-level entity (anchor container)
var entity = scriptContext.sourceEvent.objectEntity;

// representationEntity = the specific representation that triggered the event
var rep = scriptContext.sourceEvent.representationEntity;

// Common pattern: use representationEntity for visual changes
rep.opacity = 0.5;
rep.animateTo({ scale: Vector3(1.2, 1.2, 1.2) }, 0.3);

// Use objectEntity to find sibling representations
var audio = entity.findRepresentation({ name: "Audio1" });
audio.isEnabled = true;
```

### Sequential audio with collision counter

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

A practical example combining entity navigation with state:

```javascript
// Attach to: On Object Collision (on each trigger object)
// Setup: Parent entity "AudioPlayer" contains representations "Audio1", "Audio2", "Audio3"

var count = experience.getVariable("hitCount") ?? 0;
count = count + 1;
experience.setVariable("hitCount", count);

if (count <= 3) {
    var player = scene.findEntity({ name: "AudioPlayer" });
    var audio = player.findRepresentation({ name: "Audio" + count });
    if (audio) {
        audio.isEnabled = true;
    }
}
```

## Create objects dynamically

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Spawn a box in front of the camera:

```javascript
// Attach to: On Screen Tap
var box = await scene.createEntity(
    createBox(0.3, 0.3, 0.3) // width, height, depth in meters
        .anchor(Anchor.currentPOV(0, 0, -1)) // x, y, z offset from camera
);
console.log("Created: " + box.id);
```

Create a sphere at a fixed world position with traits:

```javascript
var sphere = await scene.createEntity(
    createSphere(0.1) // radius in meters
        .name("Ball")
        .anchor(Anchor.position(0, 1.5, -2)) // x, y, z world position
        .opacity(0.8)
);
```

Choose how an object animates in and out:

```javascript
var card = await scene.createEntity(
    createImage("https://picsum.photos/800/600", 0.4, 1.5)
        .anchor(Anchor.currentPOV(0, 0, -1))
        .revealAnimation({ style: 'fadeAndScale', duration: 0.5, scaleFactor: 0.8 })
        .removalAnimation({ style: 'fade', duration: 0.2 })
);
```

The styles are the editor's: `'default'`, `'disabled'`, `'fade'`, `'fadeAndScale'`. A script that
animates the object in itself wants the built-in one out of the way – `.revealAnimation(false)`.

Prepare an object before anyone sees it:

```javascript
var ball = await scene.createEntity(
    createSphere(0.05)
        .physics({ mode: 'dynamic', shape: 'sphere', mass: 0.15 })
        .anchor(Anchor.position(0, 1, -1.5))
        .hideByDefault()
);
await ball.waitUntilReady();
await scene.toggle([ball], true);   // shown now, physics starts now
```

`hideByDefault` still loads the object, it just isn't shown and its physics stays paused. Build a
batch that way and one `scene.toggle` brings them all up on the same frame, so a stack doesn't
settle against its half-built self.

Place an object on a detected floor:

```javascript
var marker = await scene.createEntity(
    createSphere(0.05)
        .name("Marker")
        .anchor(Anchor.horizontalPlane("floor"))
);
```

Load a 3D model from a remote URL:

```javascript
// Attach to: On Experience Start
var model = await scene.createEntity(
    createModel("https://developer.apple.com/quick-look-gallery/models/soccerball/ball_soccerball_realistic.usdz")
        .name("RemoteModel")
        .anchor(Anchor.position(0, 1, -2))
        .fittingBox(0.5) // fit into 0.5m bounding box
);

// Spin on tap
model.on('tap', function() {
    model.play(EntityAnimation.spin(1, 0.8, { axis: [0, 1, 0] }));
});
```

Display an image:

```javascript
var photo = await scene.createEntity(
    createImage("https://picsum.photos/800/600", 0.5, 1.5) // url, width (m), aspect ratio (w/h)
        .anchor(Anchor.currentPOV(0, 0, -1.5))
);
```

## Adjust an authored object before it appears

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

`findEntity` gives you an object that's already in the scene. `scene.getObjectDescriptor` gives you the **recipe** of an object you built in the editor – so a script can adjust it *before* it's displayed, then write it back with `scene.setObjectDescriptor`. Use it to adapt an authored object to the device, add an interaction the editor can't express per platform, or spawn variations from it.

The edit takes effect the next time the object is displayed, so run the script **before** the object's "Add to Scene" action, in the same event – at the top level or in a Sequence, not grouped with it (a Group runs its actions at the same time).

Enable a throw gesture only where there's no touchscreen. On Apple Vision Pro there are no screen gestures, so drag‑to‑throw has to live on the object itself – author the ball once, then add the gesture at runtime only where it's needed:

```javascript
// Attach to: On Start, before the ball's Add to Scene action
if (!environment.features.has('screenGestures')) {
    const ball = scene.getObjectDescriptor({ name: 'ball' });
    ball.gestures({ drag: true, releaseBehavior: 'momentum' });
    scene.setObjectDescriptor(ball);
}
```

Swap the source asset per device – a lighter model on a phone, a heavier one on a headset. `.asset(...)` replaces a model's or video's source, routed to the right place for its kind:

```javascript
const hero = scene.getObjectDescriptor({ name: 'hero' });
hero.asset(environment.deviceCategory === 'spatial' ? 'hero_hi.usdz' : 'hero_lo.usdz');
scene.setObjectDescriptor(hero);
```

Spawn variations from one authored template. `.clone()` copies the descriptor with fresh ids, so you can add many:

```javascript
const template = scene.getObjectDescriptor({ name: 'can' });
for (const p of positions) {
    await scene.createEntity(template.clone().transform({ position: p }));
}
```

Passing the authored descriptor to `createEntity` *without* `.clone()` is rejected – its id already belongs to the authored object, so clone first for a distinct copy.

Replace the whole representation. `.representation(...)` swaps the visual entirely – the way to change kind, e.g. a simple shape instead of a model on a low‑end device – keeping the object's placement and events:

```javascript
const crate = scene.getObjectDescriptor({ name: 'crate' });
crate.representation(createBox(0.3, 0.3, 0.3).material('crate-mat'));
scene.setObjectDescriptor(crate);
```

::: tip
Inspect what you fetched with `descriptor.kind` (`'model'`, `'primitive'`, `'visualMedia'`, …) and branch on it, and keep `descriptor.id` to look the object up later with `findEntity`.
:::

::: warning Session only
These edits live in memory for the running session – they change how the object appears now, not the saved experience.
:::

## Light a scene

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Lights are objects you create like any other. A spot is aimed by its rotation, a point light
radiates in every direction, and a directional light is a sun whose position does nothing.

```javascript
// Attach to: On Experience Start
var lamp = await scene.createEntity(
    createSpotLight({
        name: 'Lamp',
        color: '#FFD9A0',
        intensity: 4000,           // lumens
        outerAngle: 45,            // full cone aperture, in degrees
        attenuationRadius: 3,      // metres to nothing
        shadow: { edges: 'soft', lightSize: 0.2 },
        anchor: Anchor.position(0, 2, -1),
        transform: { rotation: Rotation(-Math.PI / 2, 0, 0) }   // straight down
    })
);
```

Everything worth animating lives on `entity.representation.light`:

```javascript
var light = lamp.representation.light;

animateValue({
    from: 3000,
    to: 5000,
    duration: 1.4,
    curve: 'easeInOut',
    repeatCount: -1,
    reverseOnRepeat: true,
    onUpdate: function(value) {
        light.intensity = value;
    }
});
```

A candle, whose colour drifts as it burns:

```javascript
var flame = await scene.createEntity(
    createPointLight({ color: '#FF9A3C', intensity: 800, attenuationRadius: 1.5 })
);

animateValue({
    from: 0, to: 1, duration: 2.5, repeatCount: -1, reverseOnRepeat: true,
    onUpdate: function(t) {
        flame.representation.light.color = Color(1, 0.5 + 0.2 * t, 0.2 * t);
    }
});
```

A sun, where `cascades` buys sharper shadows far from the camera:

```javascript
await scene.createEntity(
    createDirectionalLight({
        intensity: 2500,           // lux, not lumens
        shadow: { maximumDistance: 20, cascades: 3 },
        transform: { rotation: Rotation(-0.6, 0.7, 0) }
    })
);
```

::: tip Check before you rely on it
Soft edges, projected images and the surroundings light need a recent OS, and the surroundings
light is Apple Vision Pro only. Gate on them so a portable script degrades instead of looking
broken:

```javascript
var shadow = environment.features.has('softShadows')
    ? { edges: 'soft', lightSize: 0.2 }
    : true;

await scene.createEntity(createSpotLight({ intensity: 4000, shadow: shadow }));
```

:::

A spot can project a texture through its cone, which is how you get a pattern rather than a
plain circle. It must be **opaque with a black background**: black blocks the light and bright
areas pass it, so a transparent PNG projects as an even circle.

`projectedTexture` takes an asset id or URL, or a handle from
[Texture](https://scenery.app/docs/scripting/api/texture), so the same cone can project a video, the camera feed, or a
compute kernel's output.

```javascript
if (environment.features.has('projectedLightTexture')) {
    var projector = await scene.createEntity(
        createSpotLight({
            projectedTexture: 'my-gobo-asset-id',
            intensity: 6000,
            outerAngle: 50,
            anchor: Anchor.position(0, 2.5, 0),
            transform: { rotation: Rotation(-Math.PI / 2, 0, 0) }
        })
    );

    // The one part worth animating: turn the pattern, not the light.
    animateValue({
        from: 0, to: Math.PI * 2, duration: 12, repeatCount: -1,
        onUpdate: function(radians) {
            projector.representation.light.projectedTextureRotation = radians;
        }
    });
}
```

::: warning Point lights cast no shadow
That is an engine limitation on every OS, not a setting. Use a spot or a directional light
where you need one.
:::

## Animate objects

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Simple property animation:

```javascript
var box = scene.findEntity({ name: "MyBox" });

// Animate to target values (fire-and-forget, no await needed)
box.animateTo(
    { position: Vector3(0, 2, -1), opacity: 0.5 },
    1.0,
    { timingFunction: "easeInOut" }
);
// Available: "linear", "easeIn", "easeOut", "easeInOut"
```

Chained animations with async/await:

```javascript
var box = scene.findEntity({ name: "MyBox" });

await box.animateTo({ position: Vector3(0, 2, 0) }, 1.0);
await box.animateTo({ scale: Vector3(2, 2, 2) }, 0.5);
await box.animateTo({ opacity: 0 }, 0.3);
```

Using EntityAnimation with play():

```javascript
var box = scene.findEntity({ name: "MyBox" });

// Spin 2 full revolutions over 3 seconds
await box.play(EntityAnimation.spin(2, 3.0, { axis: [0, 1, 0] }));

// Keyframe animation
await box.play(EntityAnimation.keyframes([
    { position: Vector3(0, 1, -2) },
    { position: Vector3(1, 2, -2) },
    { position: Vector3(0, 3, -2) }
], 2.0, { tweenMode: "linear" }));

// Group multiple animations together
await box.play(EntityAnimation.group([
    EntityAnimation.to({ opacity: 0.5 }, 1.0),
    EntityAnimation.spin(1, 1.0)
]));
```

## Value animations

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

::: tip Spring animations
`animateTo` supports `"linear"`, `"easeIn"`, `"easeOut"`, `"easeInOut"` timing. For spring dynamics, use `animateValue` with a `spring` config instead.
:::

Animate a number and apply it each frame:

```javascript
var box = scene.findEntity({ name: "MyBox" });

animateValue({
    from: 0,
    to: Math.PI * 2,
    duration: 3.0,
    curve: "easeInOut",
    repeatCount: -1,
    onUpdate: function(value) {
        // position is an offset from where the box was placed in the editor, so this circles that spot.
        box.representation.position = Vector3(
            Math.sin(value) * 2,
            1,
            Math.cos(value) * 2
        );
    }
});
```

Spring-based value animation:

```javascript
animateValue({
    from: 0.6,
    to: 0.08,
    spring: { duration: 0.6, bounce: 0 },
    onUpdate: function(h) {
        scene.setVariable("baseColor", Color.hsl(h, 0.8, 0.55));
    }
});
```

Repeating pulse animation:

```javascript
animateValue({
    from: 0.6,
    to: 0.65,
    duration: 4,
    curve: 'easeInOut',
    repeatCount: -1,
    reverseOnRepeat: true,
    onUpdate: function(h) {
        scene.setVariable("baseColor", Color.hsl(h, 0.5, 0.5));
    }
});
```

## Fetch data from an API

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

GET request – fetch live weather data:

```javascript
// Attach to: On Experience Start
var response = await http.get(
    "https://api.open-meteo.com/v1/forecast?latitude=52.52&longitude=13.41&current=temperature_2m"
);

var temp = response.data.current.temperature_2m;
console.log("Berlin: " + temp + "°C");
```

POST request with JSON:

```javascript
var response = await http.post(
    "https://api.example.com/submit",
    JSON.stringify({ score: 100, name: "Player" }),
    { headers: { "Content-Type": "application/json" } }
);
console.log("Status: " + response.status);
```

Custom request with an API key:

```javascript
var response = await http.request("https://api.example.com/data", {
    method: "POST",
    secret: "my-api",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query: "test" })
});
console.log(response.data.results);
```

::: tip Keep your API key out of the script
Add the key in the editor under Secrets, then name it with `secret`. Scenery makes the request and adds the key on the way out, so it stays on your account rather than being shipped with the experience.

A secret is tied to the API's address, so the key is only ever sent there, and you can replace it without touching your scripts. Works with any API that takes its key in a header.
:::

Binary response as base64 (e.g. text-to-speech):

```javascript
var response = await http.request("https://api.openai.com/v1/audio/speech", {
    method: "POST",
    secret: "openai",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
        model: "tts-1",
        input: "Hello from augmented reality!",
        voice: "nova",
        response_format: "pcm"
    }),
    responseType: "base64"
});

if (response.status === 200) {
    var entity = scene.findEntity({ name: "Speaker" });
    await entity.playAudioBuffer(response.data, { sampleRate: 24000 });
}
```

## How long an API call takes

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Nearly all of it is the API's own time, so budget for the one you chose rather than for Scenery.

A call spends about 100ms inside Scenery: reading which key the name points at, decrypting it, and counting it against the daily limit. That part is steady. The API's own reply is usually several times that, and on a measured run against OpenAI the swing between identical calls was larger than everything Scenery does.

Two things follow. Reach for an API when something happens, not on every frame, and never inside an update loop. And when a call is slow, look at the endpoint before looking here: a refused key comes back in about 400ms because the API rejects it at once, while a listing or a completion takes as long as it takes.

If a viewer waits on the answer, say so in the scene. A label that reads "Thinking…" until the reply lands is the difference between a pause and a broken experience.

## When an API call fails

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Two different things can go wrong, and they arrive differently. This catches people out, so it is worth reading once.

The API's own refusal comes back as an ordinary response carrying its status. A spent quota at the vendor, a model name it doesn't know, a malformed body: all of these are a normal result with `status` set to 429 or 400, not an error. A script that only wraps the call in `try` never notices them.

Scenery declining to make the call at all rejects the promise. The name in `secret` isn't bound to this experience, the address doesn't match the one the key was stored for, or the secret has spent its daily limit. These arrive as an error carrying `code` and `reason` you can branch on.

Neither is written for the person standing in your scene. Put the detail in the console, where only you read it, and give the viewer a line that belongs in the experience:

```javascript
var speaker = scene.findEntity({ name: "Speaker" });
var caption = speaker.representation.findView({ name: "caption" });

try {
    var response = await http.request("https://api.openai.com/v1/audio/speech", {
        method: "POST",
        secret: "openai",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            model: "tts-1",
            input: "Hello from augmented reality!",
            voice: "nova",
            response_format: "pcm"
        }),
        responseType: "base64"
    });

    if (response.status === 200) {
        await speaker.playAudioBuffer(response.data, { sampleRate: 24000 });
    } else {
        console.error("Speech request failed with status " + response.status);
        caption.setProperty("text", "The guide has gone quiet for a moment.");
    }
} catch (error) {
    console.error("Speech request refused: " + error.reason + " (" + error.code + ")");
    caption.setProperty("text", "The guide has gone quiet for a moment.");
}
```

### Out of calls for today

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

A secret has a daily limit, and it is shared by everyone who opens an experience using it. Two refusals share the code `resource-exhausted` and want opposite advice, so branch on `reason`:

```javascript
} catch (error) {
    if (error.reason === "owner_busy") {
        // Too many calls at once. Retrying shortly usually works.
        caption.setProperty("text", "One moment…");
    } else if (error.reason === "ceiling_reached") {
        // The day's limit is spent. error.details.resetAt is when it returns.
        console.error("Daily limit of " + error.details.limit + " reached, resets " + error.details.resetAt);
        caption.setProperty("text", "The guide is resting until tomorrow.");
    } else {
        console.error("Refused: " + error.reason + " (" + error.code + ")");
        caption.setProperty("text", "The guide has gone quiet for a moment.");
    }
}
```

::: tip Write the viewer's line yourself
`error.message` and `error.reason` describe your credential and your account, in wording that can change. Keep them in the console and write what the viewer sees in the voice of the experience.
:::

## WebSocket real-time connection

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

```javascript
// Attach to: On Experience Start
var ws = websocket.connect("wss://echo.websocket.org", {
    headers: { "Authorization": "Bearer YOUR_TOKEN" }
});

ws.onOpen = function() {
    console.log("Connected");
    ws.send(JSON.stringify({ type: "hello" }));
};

ws.onMessage = function(event) {
    var data = JSON.parse(event.data);
    console.log("Received: " + data.type);
};

ws.onClose = function() {
    console.log("Disconnected");
};

ws.onError = function(event) {
    console.log("Error: " + event.error);
};
```

## Shader material parameters

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Bind a shader parameter to a variable, then toggle it:

```javascript
var box = scene.findEntity({ name: "Box" });

// Bind the ShaderGraphMaterial parameter "isOn" to scene variable "isOn"
box.representation.bindMaterialParameter("isOn", "isOn", { update: "onChange" });

// Initialize the variable
scene.setVariable("isOn", false);

// Toggle on tap
box.on("tap", function() {
    var isOn = scene.getVariable("isOn") ?? false;
    scene.setVariable("isOn", !isOn);
});
```

Animate a material parameter via variables:

```javascript
var entity = scriptContext.sourceEvent.representationEntity;

// Bind material parameters to variables
entity.bindMaterialParameter("baseColor", "baseColor", { update: "onChange" });
entity.bindMaterialParameter("intensity", "intensity", { update: "onChange" });

// Animate color via variable (material auto-updates)
scene.setVariable("baseColor", Color.hsl(0.6, 0.5, 0.5));
scene.setVariable("intensity", 0.15);

// Smoothly ramp intensity to a target – animateValue paces by
// wall-clock so the ramp takes the same time regardless of frame rate.
// Hand-rolled `lerp on render tick` looks similar but converges twice
// as fast at 120 Hz as at 60 Hz.
animateValue({
    from: 0.15,
    to: 0.5,
    duration: 0.6,
    curve: "easeOut",
    onUpdate: function (v) { scene.setVariable("intensity", v); }
});
```

## Toggle behavior on tap

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Use a variable to alternate between two actions on each tap:

```javascript
// Attach to: On Experience Start
experience.setVariable("isOpen", false);

var lid = scene.findEntity({ name: "Lid" });

lid.on('tap', function() {
    var isOpen = experience.getVariable("isOpen");

    if (isOpen) {
        lid.animateTo({ rotation: Rotation(0, 0, 0) }, 0.4, { timingFunction: "easeInOut" });
    } else {
        lid.animateTo({ rotation: Rotation(-Math.PI / 2, 0, 0) }, 0.4, { timingFunction: "easeOut" });
    }

    experience.setVariable("isOpen", !isOpen);
});
```

Or use `on`/`off` to swap between different event handlers:

```javascript
// Attach to: On Experience Start
var box = scene.findEntity({ name: "MyBox" });
var currentTap = null;

function listenShrink() {
    currentTap = box.on('tap', function() {
        box.off(currentTap);
        box.animateTo({ scale: Vector3(0.5, 0.5, 0.5) }, 0.3, { timingFunction: "easeOut" });
        listenGrow();
    });
}

function listenGrow() {
    currentTap = box.on('tap', function() {
        box.off(currentTap);
        box.animateTo({ scale: Vector3(1, 1, 1) }, 0.3, { timingFunction: "easeOut" });
        listenShrink();
    });
}

listenShrink();
```

## State management with variables

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Variables live on two scopes:

* **`experience`** – persists across all scenes. Use for global state like scores, settings, or progress.
* **`scene`** – cleared on scene transition. Use for local state like counters, toggles, or material bindings.

Experience-scoped (persists across scenes):

```javascript
// Script A (On Experience Start): initialize state
experience.setVariable("score", 0);
experience.setVariable("level", 1);

// Script B (On Tap Gesture): update state
var score = experience.getVariable("score");
experience.setVariable("score", score + 10);

// Script C (On Variable Change): react to changes
var newScore = experience.getVariable("score");
console.log("Score: " + newScore);
```

Scene-scoped (cleared on scene transition):

```javascript
scene.setVariable("localCounter", 0);
var count = scene.getVariable("localCounter");
scene.setVariable("localCounter", count + 1);
```

## Raycasting

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Cast a ray from the screen center to find objects:

```javascript
// Attach to: On Render or On Screen Tap
var center = Vector2(0.5, 0.5);
var ray = scene.screenToRay(center);
if (!ray) return;

var hits = scene.raycast(ray.origin, ray.direction);
if (hits.length > 0) {
    var hit = hits[0];
    console.log("Hit at: " + hit.position.x.toFixed(2) + ", " + hit.position.y.toFixed(2) + ", " + hit.position.z.toFixed(2));
}
```

Place an object aligned to the surface normal:

```javascript
function transformFromNormal(position, normal) {
    var n = normal.normalize();
    var up = Vector3(0, 1, 0);
    var dot = up.dot(n);

    if (dot > 0.999) return Transform({ position: position });
    if (dot < -0.999) return Transform({ position: position, rotation: Rotation(Math.PI, 0, 0) });

    var axis = up.cross(n).normalize();
    var angle = Math.acos(dot);
    var halfAngle = angle / 2;
    var s = Math.sin(halfAngle);

    return Transform({
        position: position,
        rotation: Rotation.quaternion(axis.x * s, axis.y * s, axis.z * s, Math.cos(halfAngle))
    });
}

var ray = scene.screenToRay(Vector2(0.5, 0.5));
if (ray) {
    var hits = scene.raycast(ray.origin, ray.direction);
    if (hits.length > 0) {
        var entity = scene.findEntity({ name: "Marker" });
        entity.representation.worldTransform = transformFromNormal(hits[0].position, hits[0].normal);
    }
}
```

Cast against AR planes (real-world surfaces):

```javascript
var ray = scene.screenToRay(Vector2(0.5, 0.5));
var arHits = scene.raycastAR(ray.origin, ray.direction, "existingPlaneGeometry", "horizontal");

if (arHits.length > 0) {
    var hit = arHits[0];
    console.log("Surface: " + hit.targetAlignment);

    scene.createEntity(
        createSphere(0.05)
            .anchor(Anchor.position(hit.worldTransform.position))
    );
}
```

## Audio

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Play spatial audio on an object:

```javascript
var speaker = scene.findEntity({ name: "Speaker" });

await speaker.playAudio("https://example.com/sound.mp3", {
    gain: 0.8,
    loops: true,
    inputMode: "spatial"
});
```

Play audio from a generated buffer:

```javascript
// Generate a 440Hz sine wave tone (1 second)
var sampleRate = 24000;
var numSamples = Math.floor(sampleRate * 1.0);
var samples = new Int16Array(numSamples);

for (var i = 0; i < numSamples; i++) {
    var t = i / sampleRate;
    samples[i] = Math.floor(Math.sin(2 * Math.PI * 440 * t) * 32767 * 0.5);
}

// Convert to base64
var bytes = new Uint8Array(samples.buffer);
var binary = '';
for (var j = 0; j < bytes.length; j++) {
    binary += String.fromCharCode(bytes[j]);
}
var base64 = btoa(binary);

var entity = scene.findEntity({ name: "Speaker" });
await entity.playAudioBuffer(base64, { sampleRate: sampleRate });
```

Stream audio in real-time:

```javascript
var entity = scene.findEntity({ name: "Speaker" });
var stream = entity.createAudioStream({ sampleRate: 24000 });

// Append base64-encoded PCM16 audio chunks as they arrive
stream.append(base64AudioData);

// Check if buffer has finished playing
if (stream.isDrained) {
    console.log("Playback finished");
}

// Stop when done
stream.stop();
```

## Microphone input

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

```javascript
// Attach to: On Experience Start
var mic = scene.microphone;

mic.configure({
    sampleRate: 24000,
    silenceThreshold: 0,
    highpassFrequency: 0
});

mic.onData = function(base64Chunk) {
    // Process audio chunk (e.g. send to server or WebSocket)
    ws.send(JSON.stringify({
        type: "input_audio_buffer.append",
        audio: base64Chunk
    }));
};

mic.onError = function(error) {
    console.log("Mic error: " + error);
};

mic.start();
// Later: mic.stop();
```

## Face tracking (blend shapes)

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Drive a 3D face model with live face tracking data:

```javascript
// Attach to: On Render
// Requires a model with blend shape support (e.g. a face-tracking-capable head model)
var headModel = scene.findEntity({ name: "Head" }).representation;
var faces = scene.getAnchors("face");

if (faces.length > 0) {
    headModel.setBlendShapeWeights(faces[0].blendShapes);
}
```

## Hand tracking (visionOS)

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Hand tracking is available on Apple Vision Pro. Gate portable scripts with
`environment.features.has('handTracking')`.

Attach an object to the user's hand:

```javascript
scene.createEntity(
    createSphere(0.02)
        .name("HandMarker")
        .anchor(Anchor.hand("right", "indexFingerTip", "full", 0.5, true))
);
```

Read hand joint data without placing an object – opt into the provider, then
poll the live hands each frame:

```javascript
// Attach to: On Experience Start
await scene.tracking.hands.enable();   // resolves when tracking is live; rejects if denied / unsupported
```

```javascript
// Attach to: On Render
var right = scene.tracking.hands.right;             // null when that hand isn't tracked
if (right) {
    var tip = right.joints.indexFingerTip.worldTransform.position;
    console.log("Right index tip: " + tip);
}
```

`scene.tracking.hands` owns the provider lifecycle (`enable()` / `disable()`,
`isSupported`, `active`) and the live reads (`left` / `right` / `anchors`).

Joint positions are in **world space**. To use them against an object you built (a mesh, a placed entity), convert into that object's local frame first – see [Coordinate spaces](https://scenery.app/docs/scripting/guide/vectors-transforms#coordinate-spaces).

`scene.getAnchors("hand")` remains the low-level equivalent:

```javascript
// Attach to: On Render
var anchors = scene.getAnchors("hand");
for (var i = 0; i < anchors.length; i++) {
    var hand = anchors[i];
    if (hand.chirality === "right") {
        console.log("Right hand at: " + hand.worldTransform.position);
    }
}
```

Inspect model hierarchy for hand mesh rigging:

```javascript
var entity = scene.findEntity({ name: "Glove" });
var rep = entity.representation;
var names = rep.getChildNames();

names.forEach(function(name) {
    var child = rep.findChild(name);
    console.log(name + " - joints: " + child.jointNames.length);
});
```

## Cross-platform surface input

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

`scene.createSurfaceInput` gives you interaction points on a surface using whatever input the platform offers – fingertips on Apple Vision Pro (hand tracking), screen taps and drags on iPhone, iPad and Mac. Your code reads the same points either way and never branches on platform.

Read `points` each frame. Each point is in the surface's own local frame and carries a stable `id`, a `phase` (`began` / `moved` / `ended`) and a `source` (`hand` / `screen`):

```javascript
// Attach to: On Experience Start
var surface = scene.findEntity({ name: "Surface" });

var input = scene.createSurfaceInput({
    target: surface.representation,     // points are returned in this representation's local frame
    plane: { axis: "y", offset: 0 },    // how a screen ray maps to the surface (a flat plane here)
    maxDistance: 0.08                   // a fingertip counts as touching within 8 cm of the plane
});

scene.on('render', function () {
    input.points.forEach(function (p) {
        if (p.phase === 'began') {
            console.log('touch started via ' + p.source + ' at ' + p.x.toFixed(2) + ', ' + p.z.toFixed(2));
        }
        // p.x / p.y / p.z are local to the surface — feed them into your own logic
        // (deform a mesh, spawn something, move an object …).
    });
});

// When you no longer need it (for example before leaving the scene):
// input.stop();
```

::: tip

* `target` is the **representation** whose local frame you want, usually `entity.representation`. For a composed object with nested representations, pass the specific one that holds the surface.
* `project: 'plane'` (the default) needs no collision – ideal for water, tables, or a deforming mesh. Use `project: 'collision'` to raycast a solid model's collision geometry instead.
* On Apple Vision Pro the points come from fingertips; on iPhone / iPad / Mac they come from taps and drags. Nothing else in your code changes.
  :::

## Image tracking

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Track a physical image and attach content:

```javascript
scene.createEntity(
    createBox(0.1, 0.1, 0.01)
        .name("ImageOverlay")
        .anchor(Anchor.image(
            "https://example.com/marker.jpg",
            0.15,    // physical width in meters
            "myMarker",
            "any",
            true,    // track continuously
            true,    // hide if tracking lost
            true     // show discovery hint
        ))
);
```

## Render loop patterns

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Smooth oscillation:

```javascript
// Attach to: On Render
var box = scene.findEntity({ name: "MyBox" });
var t = scriptContext.sourceEvent.time;

// An offset from where the box was placed, so it sways around that spot.
box.representation.position = Vector3(
    Math.sin(t) * 0.5,
    Math.sin(t * 2) * 0.2,
    0
);
```

Frame-rate independent movement:

```javascript
// Attach to: On Render
var box = scene.findEntity({ name: "MyBox" });
var dt = scriptContext.sourceEvent.deltaTime;
var speed = 2.0;

var pos = box.representation.position;
box.representation.position = Vector3(pos.x + speed * dt, pos.y, pos.z);
```

Throttled updates for expensive operations:

```javascript
scene.on('render', { throttle: 0.1 }, function(e) {
    // Runs at 10 FPS instead of every frame
    var anchors = scene.getAnchors("plane");
    console.log("Planes: " + anchors.length);
});
```

## Look at camera (billboard)

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

```javascript
// Attach to: On Render
var label = scene.findEntity({ name: "Label" });
var cam = scene.cameraTransform;

var dir = cam.position.subtract(label.representation.worldPosition).normalize();
var yaw = Math.atan2(dir.x, dir.z);
label.representation.rotation = Rotation(0, yaw, 0);
```

## Scene transitions

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

```javascript
// Pass data to the next scene via experience variables
experience.setVariable("selectedLevel", 3);

// Transition (use scene ID from editor)
experience.transitionToScene("SCENE_ID");
```

## Platform-specific behavior

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Use `environment` to check the current platform and adapt:

```javascript
// Attach to: On Experience Start
var platform = environment.hostingPlatform; // "iOS", "macOS", "visionOS", or "web"

if (platform === "visionOS") {
    // Add hand-tracked content
    scene.createEntity(
        createSphere(0.02)
            .name("HandMarker")
            .anchor(Anchor.hand("right", "indexFingerTip", "full", 0.5, true))
    );
} else {
    console.log("Running on " + platform + " (" + environment.systemOSVersion + ")");
    console.log("Locale: " + environment.locale);
}
```

## Arrange objects in a line

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

On screen tap, find multiple entities and animate them into a row:

```javascript
// Attach to: On Screen Tap
var names = ["BoxA", "BoxB", "BoxC", "BoxD", "BoxE"];
var spacing = 0.4;
var startX = -((names.length - 1) * spacing) / 2;

for (var i = 0; i < names.length; i++) {
    var entity = scene.findEntity({ name: names[i] });
    if (!entity) continue;

    var targetPos = Vector3(startX + i * spacing, 1.2, -2);
    entity.animateTo(
        { position: targetPos, rotation: Rotation(0, 0, 0), scale: Vector3(1, 1, 1) },
        0.6 + i * 0.1,
        { timingFunction: "easeOut" }
    );
}
```

Arrange in a circle:

```javascript
// Attach to: On Screen Tap
var names = ["Obj1", "Obj2", "Obj3", "Obj4", "Obj5", "Obj6"];
var radius = 1.0;
var center = Vector3(0, 1.2, -2.5);

for (var i = 0; i < names.length; i++) {
    var entity = scene.findEntity({ name: names[i] });
    if (!entity) continue;

    var angle = (i / names.length) * Math.PI * 2;
    var targetPos = Vector3(
        center.x + Math.sin(angle) * radius,
        center.y,
        center.z + Math.cos(angle) * radius
    );

    // Face center
    var yaw = Math.atan2(
        center.x - targetPos.x,
        center.z - targetPos.z
    );

    entity.animateTo(
        { position: targetPos, rotation: Rotation(0, yaw, 0) },
        0.8,
        {
            timingFunction: "easeOut",
            delay: i * 0.08
        }
    );
}
```

## Procedural spiral with tap bounce

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Create boxes in a rainbow spiral. Each box gets an inline unlit material with a unique HSL color. Tap any box to bounce it:

```javascript
// Attach to: On Experience Start
var count = 24;
var baseRadius = 0.8;
var heightStep = 0.06;
var turns = 2.5;

async function buildSpiral() {
    for (var i = 0; i < count; i++) {
        var t = i / count;
        var angle = t * Math.PI * 2 * turns;
        var radius = baseRadius * (0.3 + t * 0.7);
        var size = 0.06 + t * 0.06;

        var x = Math.sin(angle) * radius;
        var y = 1.0 + i * heightStep;
        var z = -2.5 + Math.cos(angle) * radius;

        var box = await scene.createEntity(
            createBox(size, size, size)
                .name("Spiral_" + i)
                .anchor(Anchor.position(x, y, z))
        );

        // Face outward from center
        var yaw = Math.atan2(x, z - (-2.5));
        box.animateTo(
            { rotation: Rotation(0, yaw, 0) },
            0.3,
            { delay: i * 0.03 }
        );

        // Bounce on tap
        box.on('tap', function(e) {
            e.representationEntity.animateTo(
                { scale: Vector3(1.5, 1.5, 1.5) },
                0.3,
                { timingFunction: "easeOut" }
            );
        });
    }
}

buildSpiral();
```

## UI panel with bound slider

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Build a small control panel, bind a slider to a scene variable, and
read the live value back in a label via `${var|fixed(2)}` – the label
re-renders automatically whenever the variable changes. See
[Live labels](https://scenery.app/docs/scripting/guide/user-interface#live-labels) for the full filter reference.

```javascript
// Attach to: On Experience Start
scene.setVariable("brightness", 0.5);

var panel = createPanel(
    UI.vStack({
        spacing: 16,
        padding: 24,
        children: [
            UI.label({ text: "Brightness: ${brightness|fixed(2)}" }),
            // Sliders fill the stack's width by default – no `sizing` needed.
            UI.slider({
                name: "brightness",
                range: [0, 1],
                value: 0.5
            })
        ]
    }),
    // Panel size in points (~1360 pt/m). Use 'auto', 'fill', or [w, h].
    { panelSize: [400, 200] }
)
    .name("controls")
    // Static world anchor in front of the user at eye height.
    .anchor(Anchor.position(0.5, 1.4, -0.8));

var entity = await scene.createEntity(panel);
entity.representation.findView({ name: "brightness" }).bind("value", "brightness");
```

## Dynamic mesh ribbon

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Generate a growing ribbon procedurally: each frame, append two new
vertices to the strip, then publish the updated draw range. Vertex
writes go through a single `memcpy` from a reused TypedArray.

```javascript
// Attach to: On Experience Start
var MAX_SEGMENTS = 256;
var vertexCapacity = MAX_SEGMENTS * 2; // two verts per segment

var ribbon = await scene.createEntity(
    createMesh({
        vertexCapacity: vertexCapacity,
        indexCapacity: vertexCapacity,
        attributes: {
            position: { format: "float3", storage: "dynamic" },
            color:    { format: "uchar4Normalized", storage: "dynamic" }
        },
        parts: [{
            indexCount: 0,
            topology: "triangleStrip",
            bounds: { min: [-1, -1, -1], max: [1, 1, 1] }
        }]
    })
);
var mesh = ribbon.representation.mesh;

// triangleStrip walks the vertex buffer in order, so the index buffer
// is just identity. Written once; drawCount expands per-frame.
var indices = new Uint32Array(vertexCapacity);
for (var i = 0; i < vertexCapacity; i++) { indices[i] = i; }
mesh.writeIndices(0, indices);

// Reusable scratch buffers – allocated once, extended lazily as the
// ribbon grows.
var positions = new Float32Array(vertexCapacity * 3);
var colors = new Uint8Array(vertexCapacity * 4);
var written = 0; // high-water mark – each segment's geometry is deterministic

function writeSegment(i) {
    var t = i * 0.05;
    var x = Math.sin(t) * 0.4;
    var y = i * 0.01;
    var z = Math.cos(t) * 0.4;

    positions[(i * 2) * 3 + 0]     = x; positions[(i * 2) * 3 + 1]     = y;        positions[(i * 2) * 3 + 2]     = z;
    positions[(i * 2 + 1) * 3 + 0] = x; positions[(i * 2 + 1) * 3 + 1] = y + 0.03; positions[(i * 2 + 1) * 3 + 2] = z;

    var hue = (i / MAX_SEGMENTS) * 255;
    colors[(i * 2) * 4 + 0]     = hue; colors[(i * 2) * 4 + 1]     = 200; colors[(i * 2) * 4 + 2]     = 255 - hue; colors[(i * 2) * 4 + 3]     = 255;
    colors[(i * 2 + 1) * 4 + 0] = hue; colors[(i * 2 + 1) * 4 + 1] = 200; colors[(i * 2 + 1) * 4 + 2] = 255 - hue; colors[(i * 2 + 1) * 4 + 3] = 255;
}

// Wall-clock paced reveal via animateValue – same duration at 60, 120,
// 240 Hz. Avoid hand-rolled `segments++` per render tick: that ties the
// reveal speed to the frame rate.
animateValue({
    from: 0,
    to: MAX_SEGMENTS,
    duration: 4.0,
    curve: "linear",
    onUpdate: function (s) {
        var target = Math.floor(s);
        // Extend the buffer to cover any newly-visible segments.
        for (var i = written; i < target; i++) writeSegment(i);
        if (target > written) {
            mesh.writeVertices("position", 0, positions);
            mesh.writeVertices("color", 0, colors);
            written = target;
        }
        mesh.drawCount = target * 2;
        mesh.setBounds({ min: [-0.5, 0, -0.5], max: [0.5, Math.max(0.05, target * 0.01), 0.5] });
    }
});
```

## Follow a path

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Build a spline with `scene.createPath` and drive an object along it with `followPath`:

```javascript
// Attach to: On Experience Start
var pts = [
    new Vector3(-0.6, 0, -1.2),
    new Vector3(-0.2, 0.4, -1.2),
    new Vector3(0.2, -0.2, -1.4),
    new Vector3(0.6, 0.3, -1.2)
];
var path = scene.createPath({ points: pts });

var box = await scene.createEntity(
    createBox(0.05, 0.05, 0.05).anchor(Anchor.position(0, 0, 0))
);
box.followPath(path, {
    duration: 4,
    constantSpeed: true,    // even speed regardless of control-point spacing
    alignsToTangent: true,  // nose points along the direction of travel
    timing: 'easeInOut',
    repeat: true
});
```

## Mesh instancing

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Render thousands of copies of one object cheaply with `setInstances` – far lighter than
cloning. Here, a sunflower spiral:

```javascript
// Attach to: On Experience Start
var base = await scene.createEntity(
    createBox(0.03, 0.03, 0.03).anchor(Anchor.position(0, 0, -1.5))
);

var spots = [];
var count = 1000;
var goldenAngle = Math.PI * (3 - Math.sqrt(5));
for (var i = 0; i < count; i++) {
    var r = 0.4 * Math.sqrt(i / count);
    var a = i * goldenAngle;
    spots.push(new Vector3(r * Math.cos(a), 0, r * Math.sin(a)));
}
base.setInstances(Instances.transforms(spots));
```

## Read the device location

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Ride the base location grant, read a fix, and measure distance to a point of interest:

```javascript
// Attach to: On Experience Start
await environment.location.requestAccess();
var here = await environment.location.current();
console.log('You are at', here.latitude, here.longitude, '±' + here.horizontalAccuracy + 'm');

var munich = new GeoCoordinate(48.1372, 11.5756);
console.log('Distance to Munich:', Math.round(here.distanceTo(munich)), 'm');
console.log('Bearing to Munich:', Math.round(here.bearingTo(munich)) + '°');
```

## AI voice assistant (OpenAI Realtime)

Documentation source: [Examples](https://scenery.app/docs/scripting/guide/examples.md).

Full conversational AI with voice input/output and tool calling:

```javascript
// Attach to: On Did Appear (on the assistant entity)
var entity = scriptContext.sourceEvent.representationEntity;
var stream = entity.createAudioStream({ sampleRate: 24000 });
var isResponding = false;

var ws = websocket.connect("wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview", {
    headers: {
        "Authorization": "Bearer YOUR_KEY",
        "OpenAI-Beta": "realtime=v1"
    }
});

ws.onOpen = function() {
    ws.send(JSON.stringify({
        type: "session.update",
        session: {
            modalities: ["text", "audio"],
            input_audio_format: "pcm16",
            output_audio_format: "pcm16",
            voice: "ash",
            turn_detection: {
                type: "semantic_vad",
                eagerness: "medium",
                create_response: true,
                interrupt_response: true
            },
            instructions: "You are a helpful AR assistant. Keep responses brief."
        }
    }));
    startListening();
};

ws.onMessage = function(event) {
    var msg = JSON.parse(event.data);

    if (msg.type === "response.created") {
        isResponding = true;
        scene.microphone.stop();
    }
    if (msg.type === "response.audio.delta") {
        stream.append(msg.delta);
    }
    if (msg.type === "response.done") {
        isResponding = false;
        // Resume mic after audio finishes
        waitForDrain(function() { startListening(); });
    }
};

function startListening() {
    if (isResponding) return;
    scene.microphone.configure({ sampleRate: 24000, silenceThreshold: 0, highpassFrequency: 0 });
    scene.microphone.onData = function(base64) {
        if (!isResponding) {
            ws.send(JSON.stringify({ type: "input_audio_buffer.append", audio: base64 }));
        }
    };
    scene.microphone.start();
}

function waitForDrain(callback) {
    if (stream.isDrained) { callback(); return; }
    setTimeout(function() { waitForDrain(callback); }, 100);
}
```

---

Source page: Migration Guide

Source URL: https://scenery.app/docs/scripting/guide/migration.md

# Migration Guide

Documentation source: [Migration Guide](https://scenery.app/docs/scripting/guide/migration.md).

Scripts pin to the runtime version they were written against, so upgrading is opt-in –
an experience keeps running on its saved version until you move it forward. This guide
covers what to change when you do.

## 0.1.0 → 0.2.0

Documentation source: [Migration Guide](https://scenery.app/docs/scripting/guide/migration.md).

### Traits are now direct methods on the descriptor

Documentation source: [Migration Guide](https://scenery.app/docs/scripting/guide/migration.md).

The `.traits(t => …)` callback is **deprecated**. The trait configurators are now direct,
chainable methods on the object descriptor – they read the same, chain, and are the
supported form going forward.

::: warning Deprecated, not removed
`.traits(fn)` still works so existing scripts don't break, but it will be removed in a
future runtime version. Prefer the direct methods below.
:::

**Before** (0.1.0):

```javascript
var ball = await scene.createEntity(
    createSphere(0.05)
        .name('Ball')
        .traits(function(t) {
            return t
                .physics({ mode: 'dynamic', mass: 0.2 })
                .material(goldMaterial)
                .shadow({ grounding: true })
                .build();
        })
);
```

**After** (0.2.0):

```javascript
var ball = await scene.createEntity(
    createSphere(0.05)
        .name('Ball')
        .physics({ mode: 'dynamic', mass: 0.2 })
        .material(goldMaterial)
        .shadow({ grounding: true })
);
```

Each configurator that lived inside the `.traits(t => …)` callback is now a method on the
descriptor itself:

| Inside `.traits(t => …)` | Direct method |
| --- | --- |
| `t.physics({…})` | `.physics({…})` |
| `t.material(idOrMaterial)` | `.material(idOrMaterial)` |
| `t.gestures({…})` | `.gestures({…})` |
| `t.shadow({…})` | `.shadow({…})` |
| `t.transform({…})` | `.transform({…})` |
| `t.opacity(value)` | `.opacity(value)` |
| `t.fittingBox(size)` | `.fittingBox(size)` |
| `t.pivot({…})` | `.pivot({…})` |

Notes:

* Drop the trailing `.build()` – the direct methods return the descriptor, so you chain
  straight into the next call (or hand it to `scene.createEntity`).
* Behaviour is identical: chained calls **add on top** of traits already set (e.g. materials
  passed to `createMesh({ materials: [...] })`), they don't replace them.

