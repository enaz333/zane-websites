# Events Animation and Interaction Logic

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: tap; click; button; text; score; overlay; HUD; hide; show; animate; sound; trigger; action; repeat; toggle; timing; slider.

## Contents

- User Interface
- Panels
- Layout & Sizing
- Views
- Styling
- Text & Variables
- Interaction
- Design Guidelines
- Events & Triggers
- Actions
- Scene Content
- Action Ordering
- Animations & Appearance
- Audio & Haptics
- Video
- Physics
- Experience
- Dynamic Scene Adjustments
- Developer

---

Source page: User Interface

Source URL: https://scenery.app/docs/editor/user-interface.md

# User Interface&#x20;

Documentation source: [User Interface](https://scenery.app/docs/editor/user-interface.md).

A **User Interface** object is a 2D panel you design yourself – buttons, labels, images, sliders, toggles, text fields and more, laid out with stacks. You can place the panel in the scene like any other object, or pin it to the screen as an overlay. Its controls fire [events](https://scenery.app/docs/editor/user-interface/interaction), so a tap on a panel button can start the same actions a tap on a 3D object can.

Typical uses:

* an info card next to a product or exhibit
* a control panel that switches between variants of a model
* a heads-up display with a score, a timer or a restart button
* a short form or quiz answered inside the experience

User Interface is part of the **Pro** plan and up. On a free account the insert menu still lists it, marked Pro, and choosing it opens the plan offer.

## Add a panel

Documentation source: [User Interface](https://scenery.app/docs/editor/user-interface.md).

1. Open the **+** (Insert) menu and choose **Add User Interface**. To put a panel inside a container, right-click the container and pick **Insert → User Interface**.
2. The new object starts as a small panel with one "Hello World" label in a vertical stack.
3. In the object's inspector, click **Edit Interface** to open the UI editor.
4. Build the panel, then close the editor with the **checkmark** button to save it back to the object.

Like any new object, the panel starts with a **Position** anchor at the scene origin, so it stands in the world. To pin it to the screen instead, change its anchor to Screen Space – see [where a panel appears](#where-a-panel-appears) below.

## The UI editor

Documentation source: [User Interface](https://scenery.app/docs/editor/user-interface.md).

The UI editor opens on top of the main editor, at the size of the editor window. It has three columns and a toolbar.

| Area | What it does |
|---|---|
| **Toolbar** | **+** adds a view, grouped as **Layout**, **Controls** and **Display**. The sidebar button shows or hides the inspector, and the **checkmark** saves and closes. |
| **Hierarchy** (left) | The panel's tree. The **Panel** row at the top holds the panel's own settings; below it are the root view and its children. Drag rows to reorder or move views into another stack. Hidden and disabled views show an icon on their row. |
| **Canvas** (middle) | A live preview of the panel, drawn the same way it renders in the experience. Click a view to select it. |
| **Inspector** (right) | The settings of whatever is selected: the panel itself, or one view. |

The navigator and inspector can be resized by dragging their edges, the same as in the main editor.

### Adding views

Documentation source: [User Interface](https://scenery.app/docs/editor/user-interface.md).

**+** inserts the new view next to the current selection:

* with a **stack** selected, the view is added as its last child
* with any other view selected, the view is added right after it
* with the **Panel** row or the root view selected, the view is added at the end of the root stack

A panel holds up to **50 views**. When it is full, **+**, paste and duplicate stop adding views.

### The hierarchy's context menu

Documentation source: [User Interface](https://scenery.app/docs/editor/user-interface.md).

Right-click a row for:

* **Copy**, **Cut**, **Paste** – paste lands inside a selected stack, or after any other view, with fresh copies of every view
* **Copy Style**, **Paste Style** – copy one view's look onto another (see [Styling](https://scenery.app/docs/editor/user-interface/styling#copy-and-paste-a-style))
* **Duplicate**
* **Wrap into…** – put the view inside a new VStack, HStack or ZStack
* **Dissolve Stack** – replace a stack that holds exactly one child with that child
* **Replace with…** – change the view's kind while keeping its name, style, padding and state; replacing a stack with a non-stack asks before removing its children
* **Delete**
* **Copy Development ID** – the view's ID, for scripts

The root view can't be cut, duplicated or deleted, because a panel always needs one.

### Keyboard shortcuts

Documentation source: [User Interface](https://scenery.app/docs/editor/user-interface.md).

| Shortcut | Action |
|---|---|
| ↑, ↓ | Select the previous, next row |
| ↩ | Rename the selected view |
| ⌫ | Delete the selected view |
| ⌘C, ⌘X, ⌘V | Copy, cut, paste a view |
| ⌘D | Duplicate |
| ⌘⌥C, ⌘⌥V | Copy, paste a style |
| ⌘Z, ⌘⇧Z | Undo, redo |
| Tab, ⇧Tab | Move to the next, previous field in the inspector |

Undo inside the UI editor covers everything you did since you opened it. Saving with the checkmark records the whole edit as one step in the main editor.

## Where a panel appears

Documentation source: [User Interface](https://scenery.app/docs/editor/user-interface.md).

A panel is placed by its object's [anchor](https://scenery.app/docs/editor/anchors), like any other object. Two kinds of placement behave differently:

* **In the world** – with a Position, Plane, Image or any other spatial anchor, the panel is a flat surface in the scene. People walk up to it, it can be partly hidden behind other objects, and it is in photos and videos taken in the experience.
* **On the screen** – with the [Screen Space](https://scenery.app/docs/editor/anchors#screen-space) anchor, the panel is pinned to the display as an overlay that stays put while the camera moves. You set its alignment (centre, an edge or a corner), its distance from the screen edges, and whether it keeps clear of the notch and home indicator. On Apple Vision Pro, a screen-space panel sits in a layer about 60 cm in front of the viewer that follows their head.

Screen Space is offered only for a User Interface object with no nested content.

::: tip One panel, a different placement per device
With [per-device anchoring](https://scenery.app/docs/editor/anchors#per-device-anchoring-device-configuration), the same panel can sit on the screen on one kind of device and in the world on another. A common setup is **Handheld → Screen Space**, so the panel stays flat and readable on a phone or tablet whatever the camera does, and **Spatial → Position**, so on Apple Vision Pro it stands in the room where people can walk up to it and touch it. Pick the anchor for each category under **Device Configuration** in the object's anchor settings.
:::

How the panel's size, background and touch handling change between these two placements is covered in [Panels](https://scenery.app/docs/editor/user-interface/panels).

## Where to go next

Documentation source: [User Interface](https://scenery.app/docs/editor/user-interface.md).

* **[Panels](https://scenery.app/docs/editor/user-interface/panels)** – size, background material, corner radius, scrolling, and how panels render on each device
* **[Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout)** – stacks, spacers, alignment, sizing, padding
* **[Views](https://scenery.app/docs/editor/user-interface/views)** – every view kind and its settings
* **[Styling](https://scenery.app/docs/editor/user-interface/styling)** – style presets, colours, fonts, borders, shadows, and on/off states
* **[Text & Variables](https://scenery.app/docs/editor/user-interface/text)** – markdown in labels and live variable values
* **[Interaction](https://scenery.app/docs/editor/user-interface/interaction)** – reacting to taps, toggles, sliders and text input
* **[Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines)** – text sizes, touch targets, spacing and contrast that work in AR, with a checklist

To build or change panels from a script, see the scripting guide's [User Interface](https://scenery.app/docs/scripting/guide/user-interface) page.

---

Source page: Panels

Source URL: https://scenery.app/docs/editor/user-interface/panels.md

# Panels

Documentation source: [Panels](https://scenery.app/docs/editor/user-interface/panels.md).

The panel is the surface that holds your views. Select the **Panel** row at the top of the hierarchy to see its settings.

| Setting | Options |
|---|---|
| **Size** | Hug, Fill, Fixed (width and height in points) |
| **Material** | System (with a Prominence of Standard or Expressive), Solid (a colour), Transparent |
| **Corner Radius** | 0–32 pt, default 8 |
| **Scrollable** | on or off |
| **Hide in Captures** | on or off – screen-space panels only |

## Size

Documentation source: [Panels](https://scenery.app/docs/editor/user-interface/panels.md).

* **Hug** (the default) – the panel wraps its content. It grows until it is about **1 m wide** in the world (1360 pt); past that, labels wrap onto more lines instead of the panel getting wider. A Hug panel is never smaller than 44 × 44 pt.
* **Fixed** – an exact width and height in points. Switching to Fixed starts at 320 × 200 pt.
* **Fill** – for a screen-space panel, the panel covers the whole screen. Its background runs edge to edge while its content stays inside the safe area. A panel placed in the world has nothing to fill, so Fill sizes it the same way as Hug.

In the world, **1360 points make about one metre**. A 340 pt wide panel is roughly 25 cm across, and a 15 pt label is about 1 cm tall. Pick sizes with the viewing distance in mind: text that is comfortable on a phone screen can be small on a panel two metres away. Scaling the object in the main editor scales the whole panel.

::: tip Fixed for steady layouts
A Hug panel re-measures itself whenever its content changes width – a counter gaining a digit, a longer place name. That is often what you want. Choose **Fixed** when the panel sits beside other content and should keep its outline while its values change.
:::

## Material

Documentation source: [Panels](https://scenery.app/docs/editor/user-interface/panels.md).

The material is the panel's background.

* **System** – a translucent surface that lets the scene behind it show through. Its **Prominence** is **Standard** or **Expressive**.
* **Solid** – a flat colour you pick, including its opacity.
* **Transparent** – no background. Only the views themselves are drawn, which suits floating labels and buttons that carry their own fill.

What System looks like depends on where the panel is:

| | Placed in the world | Screen space |
|---|---|---|
| **iPhone, iPad, Mac** | Frosted glass that blurs the scene behind it | A system blur. Standard is a thin material; Expressive is an ultra-thin, more see-through one |
| **Apple Vision Pro** | The system's own window glass | – |

**Prominence** changes only screen-space panels on iPhone, iPad and Mac. A panel in the world uses the same glass for both values.

Panels always render in **dark appearance**, whatever the device setting: light text on a dark, translucent surface. Choose colours that read well on a dark backdrop, or use a Solid material when you need a light panel.

## Corner Radius

Documentation source: [Panels](https://scenery.app/docs/editor/user-interface/panels.md).

Rounds the panel's corners, from 0 to 32 pt. The corners use the same continuous curve as system windows. Views inside the panel are clipped to it.

## Scrollable

Documentation source: [Panels](https://scenery.app/docs/editor/user-interface/panels.md).

With **Scrollable** on, content taller than the panel scrolls vertically – drag on an empty part of the panel to scroll it. Scrolling needs a panel of **Fixed** size: with Hug or Fill the panel simply grows to fit its content, so there is nothing to scroll.

With Scrollable off, a Fixed panel clips whatever doesn't fit.

## Hide in Captures

Documentation source: [Panels](https://scenery.app/docs/editor/user-interface/panels.md).

Shown only when the object uses a [Screen Space](https://scenery.app/docs/editor/anchors#screen-space) anchor on at least one device. When on, the panel disappears while someone takes a photo or records a video in the experience, so a shared capture shows the scene without your HUD over it. It reappears as soon as capturing ends.

A panel placed in the world is part of the scene and always appears in captures.

## Touches on screen-space panels

Documentation source: [Panels](https://scenery.app/docs/editor/user-interface/panels.md).

A screen-space panel sits above the scene, so its **Material** also decides what happens to touches that miss a control:

* **Transparent** – taps and drags on empty areas pass through to the scene behind, so a HUD of a few buttons doesn't stop people moving around.
* **System** or **Solid** – the panel is a visible surface and absorbs those touches, like a card.

Controls always receive their own taps. Labels, images and shapes take a tap only when you've given them an [event](https://scenery.app/docs/editor/user-interface/interaction); otherwise touches pass through them.

## Interacting with a panel in the world

Documentation source: [Panels](https://scenery.app/docs/editor/user-interface/panels.md).

On iPhone and iPad people tap the panel's controls directly on screen; on Mac they click them; on Vision Pro they look and pinch, or touch the panel directly. Dragging a slider, scrolling a Scrollable panel and typing all work on every device:

* Tapping a **text field** on iPhone, iPad or Mac opens a text entry prompt with the keyboard. On Vision Pro the field is edited in place.
* A **web view** inside a world panel takes touches on Vision Pro. On iPhone, iPad and Mac it shows the page but doesn't take touches; put a web page people need to scroll or tap into a screen-space panel there.

A panel in the world is an ordinary object, so everything else in the inspector still applies: [object events](https://scenery.app/docs/editor/triggers) such as On Tap, gestures, reveal animations, and the [Billboard](https://scenery.app/docs/editor/asset-appearances#transform-alignment) alignment constraint to keep it facing the viewer.

---

Source page: Layout & Sizing

Source URL: https://scenery.app/docs/editor/user-interface/layout.md

# Layout & Sizing

Documentation source: [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout.md).

Panels are laid out with **stacks**, the same model SwiftUI and Figma's auto layout use. You don't position views at coordinates. You put them in stacks, and each stack arranges its children in a row, a column or layers. Stacks can hold other stacks, so a few levels are enough for most panels.

## The three stacks

Documentation source: [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout.md).

| Stack | Arranges its children | Typical use |
|---|---|---|
| **VStack** (Vertical) | top to bottom | a card: title, text, button |
| **HStack** (Horizontal) | left to right | a row of buttons, an icon beside a label |
| **ZStack** (Depth) | on top of each other | text over an image, a badge in a corner |

Every panel has one root view, and it is almost always a stack. A new panel starts with a VStack.

Select a stack and change its **Direction** to turn it into another kind of stack without rebuilding it. Switching between Vertical and Horizontal keeps the alignment and spacing; switching to or from Depth resets them, because a ZStack aligns differently.

To group views you've already placed, right-click one and choose **Wrap into…** a VStack, HStack or ZStack. **Dissolve Stack** does the opposite for a stack with a single child.

### A worked example

Documentation source: [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout.md).

A product card with an image on top, a title, a line of text and two buttons side by side:

```
VStack  (alignment Fill, spacing 12, padding 16)
├── Image        (Fixed 280 × 160)
├── Label        "**Lounge Chair**"
├── Label        "Oak and wool, made in Berlin."
└── HStack       (distribution Fill Equally, spacing 8)
    ├── Button   "Colours"
    └── Button   "Details"
```

The VStack's **Fill** alignment stretches every row to the card's width, and **Fill Equally** gives both buttons the same width.

## Stack settings

Documentation source: [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout.md).

**VStack and HStack:**

* **Alignment** – where children sit across the stack: horizontally in a VStack, vertically in an HStack. **Leading**, **Center** and **Trailing** are for a VStack; **Top**, **Center** and **Bottom** are for an HStack. **Fill** stretches every child to the stack's full width (VStack) or height (HStack). In an HStack, Leading means Top and Trailing means Bottom.
* **Distribution** – how children share the stack's length when there is room to spare. **Fill** lets them keep their own sizes, with any Spacer or Fill-sized child taking up the rest. **Fill Equally** makes every child the same length – the usual choice for a row of equal buttons.
* **Spacing** – the gap between neighbouring children, 0–200 pt. New stacks use 8.

A new VStack starts with Fill alignment; a new HStack starts centred.

**ZStack:**

* **Alignment** – where smaller children sit inside the ZStack: Center, an edge (Top, Bottom, Leading, Trailing) or a corner (Top Leading, Top Trailing, Bottom Leading, Bottom Trailing). Children are layered in hierarchy order, so the last child is drawn on top.

A ZStack doesn't take its size from its children. Give it a **Fixed** size, or **Fill**, so its children have an area to align within.

### Spacers and dividers

Documentation source: [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout.md).

* **Spacer** – an empty, flexible gap inside a stack. It grows to take up the free space, so a Spacer between two buttons pushes them to opposite ends. Several Spacers in one stack share the free space equally. **Min Length** sets the smallest it may become; unset, it keeps at least 8 pt.
* **Divider** – a thin line between views. Set its **Thickness** (0.5–8 pt) and its **Color** in Appearance Overrides.

## Sizing

Documentation source: [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout.md).

Every view except a Spacer has a **Sizing** setting in its **Layout** section:

* **Intrinsic** – the view is as big as its content: a label as big as its text, a button as big as its title plus padding.
* **Fill** – the view expands to take the space its stack offers, in both directions.
* **Fixed** – an exact width and height in points.

Some views have no natural size, so they offer only Fill and Fixed: **Slider**, **Progress View**, **Text Field**, **Divider**, **Web View** and **Shape**. New views start with a sensible size: Images at 200 × 200 pt, Shapes at 100 × 100 pt, and Sliders, Progress Views, Text Fields, Dividers and Web Views at Fill.

A view never grows past the stack it sits in. A long label in a narrow column wraps instead of spilling out of the panel.

### Max Width and Max Height

Documentation source: [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout.md).

**Max Width** and **Max Height** cap a view's size on top of its sizing mode, the way `max-width` works on the web:

* a **Fill** label with Max Width 400 stretches with the panel but stops at 400 pt, which keeps long lines readable
* an **Intrinsic** image with Max Height 120 keeps its natural size until it would get taller than 120 pt

The caps appear only for an axis that isn't Fixed. Spacers and Dividers don't have them.

## Padding

Documentation source: [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout.md).

**Padding** is space between a view's edge and its content, set separately for top, bottom, leading and trailing. It sits *inside* the view's background: a button's fill, border and rounded corners include its padding. On a stack, padding insets all of its children – the usual way to give a card breathing room.

Most views start with no padding. Buttons with a title, and Custom toggles with a title, start with 8 pt top and bottom and 12 pt leading and trailing.

Padding isn't offered on Sliders, Progress Views, Dividers, Spacers, Web Views and Switch-style toggles, because those controls can't apply it. Wrap one in a stack and pad the stack instead.

## Offset

Documentation source: [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout.md).

**Offset** nudges a view by a number of points without changing the layout: the view moves, and everything around it stays where it was. Use it for fine adjustments, like pulling a badge slightly over the edge of an image. To move views relative to each other, change the stacks instead.

## Hiding and disabling views

Documentation source: [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout.md).

Each view's **State** section has two switches:

* **Hidden** – removes the view from the layout entirely; its neighbours close the gap. The hierarchy marks hidden views with an eye icon.
* **Disabled** – keeps the view visible but dimmed to 40 % and unresponsive to touches.

To show or hide views while the experience runs, use a script – see [Interaction](https://scenery.app/docs/editor/user-interface/interaction#changing-a-panel-while-it-runs).

---

Source page: Views

Source URL: https://scenery.app/docs/editor/user-interface/views.md

# Views

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

A view is one element of a panel. The **+** menu groups them in three sections:

| Group | Views |
|---|---|
| **Layout** | VStack, HStack, ZStack, Spacer, Divider |
| **Controls** | Button, Toggle, Slider, Stepper, Text Field, Segmented Control |
| **Display** | Label, Image, Shape, Progress View, Web View |

Selecting a view shows its inspector, top to bottom:

* **Identity** – the view's **Name**
* **Layout** – sizing, max width and height, padding and offset (see [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout))
* a section for the view's kind, described on this page
* **Appearance Overrides** – colours, font, shape, border, shadow, opacity (see [Styling](https://scenery.app/docs/editor/user-interface/styling))
* **State** – Hidden and Disabled
* **Accessibility** – a **Label** that VoiceOver reads for the view

::: tip Name the views you'll refer to
Give a view a **Name** when an event or a script needs to find it. The name replaces the generated one in the hierarchy and in the trigger's view picker, so "Buy Button" is easy to tell apart from "Button – Buy" and two other buttons. Scripts look views up by the same name.
:::

## Label

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

Text. The label's text field turns into a multi-line editor while **Wraps Text** is on.

* **Text** – any length. Supports [markdown and live variable values](https://scenery.app/docs/editor/user-interface/text).
* **Wraps Text** – on (the default) lets the text flow onto as many lines as it needs. Off keeps it on one line and ends it with "…" when it doesn't fit.
* **Text Alignment** – Leading, Center or Trailing. Visible only when the label is wider than its text: wrapped text, or a Fill-sized label.
* **Text Transform** – None, Uppercase, Lowercase or Capitalize. The stored text stays as you typed it.

A label's text is 15 pt system font in the panel's light text colour until you set a **Font** and **Foreground** in Appearance Overrides.

## Button

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

A tappable button.

* **Style** – **Primary** (filled blue, white text), **Secondary** (a soft grey fill with blue text), **Destructive** (filled red) or **Custom** (no fill, blue text, ready for your own overrides). See [Styling](https://scenery.app/docs/editor/user-interface/styling#style-presets).
* **Title** – the button's text. Remove it for an icon-only button.
* **Icon** – an image from the asset library, drawn before the title.
* **Icon Size** – the size the icon is drawn at, default 14 pt. Shown once an icon is set.

A button with a title starts with 8 pt top and bottom and 12 pt side padding. Pressing a button gives a short shrink as feedback.

## Toggle

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

An on/off control, in one of two styles:

* **Switch** – a standard switch, with the **Title** as a label beside it.
* **Custom** – a button-shaped control that changes its look when switched on. Its title, image and style can differ between off and on, so one toggle can read "Show Measurements" when off and "Hide Measurements" when on.

Settings:

* **Style** – Switch or Custom.
* **Default On** – the position the toggle starts in. People can flip it; this only sets the start.
* **Title** – the text.
* **Image** – Custom style only; an image from the asset library, drawn before the title.

With **Custom** selected, an **Off / On** tab bar appears at the top of the inspector. The tab decides which state the Title, Image and Appearance Overrides apply to, and the canvas shows the toggle in that state. Settings that aren't per state, such as Default On and layout, apply to both. See [Styling](https://scenery.app/docs/editor/user-interface/styling#off-and-on-states).

## Slider

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

A draggable control for a number.

* **Number Type** – **Integer** snaps to whole numbers; **Decimal** allows fractions.
* **Default Value** – where the thumb starts, within the range.
* **Range** – the minimum and maximum. Typing a minimum above the maximum swaps them.
* **Step** – optional. When set, the slider snaps to multiples of the step, counted from the minimum – 5 gives 0, 5, 10 and so on. Unset, an Integer slider snaps to 1 and a Decimal slider moves smoothly.

**Foreground** in Appearance Overrides colours the filled part of the track on iPhone, iPad and Vision Pro. On Mac the slider keeps the system accent colour.

## Stepper

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

Minus and plus buttons around a value.

* **Label** – optional text shown before the buttons.
* **Value** – the starting value.
* **Step** – how much one press adds or removes.
* **Range** – the minimum and maximum. Each button is greyed out at its end of the range.

The value shows without decimals when the step is a whole number, and with one decimal otherwise.

## Text Field

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

A single line of text input.

* **Default Text** – text already in the field when the panel appears.
* **Placeholder** – grey hint text shown while the field is empty.

The field has no border or background of its own; give it a **Fill**, **Border** and **Shape** in Appearance Overrides so people can see where to tap. See [Interacting with a panel in the world](https://scenery.app/docs/editor/user-interface/panels#interacting-with-a-panel-in-the-world) for how typing works on each device.

## Segmented Control

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

A row of mutually exclusive choices.

* **Segments** – one row per segment with its title. **Add Segment** adds one, up to **6**; the trash button removes one.
* **Default Selected** – which segment is selected when the panel appears.

## Image

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

A picture from the asset library.

* **Source** – the image asset.
* **Content Mode** – **Fit** shows the whole image inside the view, leaving empty space if the proportions differ. **Fill** covers the whole view and crops the edges.

New images start at a fixed 200 × 200 pt, so a large photo doesn't take over the panel. Give an image a **Shape** to round its corners or crop it to a circle.

## Shape

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

A filled shape for backgrounds, dots, badges and dividers of your own.

* **Shape** – Rectangle, Rounded (with a corner radius), Capsule or Circle.

Colour it with **Fill**, and add a **Border** or **Shadow** in Appearance Overrides. New shapes are 100 × 100 pt and light grey. A Shape is often the back layer of a ZStack, with text or an icon on top.

## Progress View

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

A progress indicator.

* **Determinate** – on shows a bar filled to **Progress** (0 to 1). Off shows a spinning activity indicator instead.

**Foreground** colours the bar or the spinner.

## Web View

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

A web page inside the panel.

* **URL** – the page's address.
* **Interactive** – whether the page takes taps and scrolling.
* **Allow Link Navigation** – currently has no effect: links behave as they do in a browser whichever way it is set.

A web view has no natural size, so it is Fill or Fixed. **Fill** in Appearance Overrides shows while the page loads and wherever the page is transparent. On iPhone, iPad and Mac, a web view in a world panel displays but doesn't take touches – see [Panels](https://scenery.app/docs/editor/user-interface/panels#interacting-with-a-panel-in-the-world).

## VStack, HStack, ZStack, Spacer, Divider

Documentation source: [Views](https://scenery.app/docs/editor/user-interface/views.md).

The layout views are described in [Layout & Sizing](https://scenery.app/docs/editor/user-interface/layout).

---

Source page: Styling

Source URL: https://scenery.app/docs/editor/user-interface/styling.md

# Styling

Documentation source: [Styling](https://scenery.app/docs/editor/user-interface/styling.md).

Views start with a plain, legible look: light text on the panel's dark glass, system font at 15 pt. Two layers change that:

1. **Style presets** – on buttons, one setting that sets several properties at once.
2. **Appearance Overrides** – individual properties you set per view, on top of the preset.

Panels always render in dark appearance, so pick colours that read on a dark or translucent backdrop.

## Style presets

Documentation source: [Styling](https://scenery.app/docs/editor/user-interface/styling.md).

A **Button** has a **Style** at the top of its section:

| Style | Look |
|---|---|
| **Primary** (default) | Blue fill, white title and icon, rounded corners |
| **Secondary** | Soft grey fill, blue title and icon, rounded corners |
| **Destructive** | Red fill, white title and icon, rounded corners |
| **Custom** | No fill, blue title and icon – a starting point for your own look |

Any Appearance Override you set wins over the preset. A Primary button with a green **Fill** is a green button with the Primary title colour and corners.

## Appearance Overrides

Documentation source: [Styling](https://scenery.app/docs/editor/user-interface/styling.md).

Each override starts unset. Click **+** on its row to set it, and the trash button to remove it again; an unset override means "use the default".

| Override | Sets |
|---|---|
| **Shape** | Rectangle, Rounded (with a corner radius, 0–500 pt), Capsule or Circle. Rounds the view's background and clips its content |
| **Fill** | The background colour |
| **Foreground** | The colour of text and icons. On a Divider this row is called **Color** and sets the line; on a Slider it colours the track; on a Progress View, the bar or spinner |
| **Border** | A colour and a width, 0.5–8 pt |
| **Shadow** | A colour, an X and Y offset (−100 to 100 pt) and a Blur radius (0–50 pt). Starts as a soft black shadow 2 pt below the view |
| **Font** | **Family**, **Size** (6–200 pt), **Weight** and **Letter Spacing** (−10 to 20 pt) |
| **Opacity** | 0–100 % for the whole view, including its children |

Colour pickers include an opacity slider, so a Fill can be semi-transparent.

**Font families:** System, Rounded, Serif, Monospaced, Avenir and Futura. **Weights:** Regular, Medium, Semibold, Bold and Heavy.

A label's shadow follows the letters rather than the label's box, which makes it a text shadow.

### Which overrides each view offers

Documentation source: [Styling](https://scenery.app/docs/editor/user-interface/styling.md).

Only the overrides that change a view appear in its section:

| View | Overrides |
|---|---|
| Button, Text Field, Custom Toggle | Shape, Fill, Foreground, Border, Shadow, Font, Opacity |
| Label | Fill, Foreground, Shadow, Font, Opacity |
| Image, Web View, VStack, HStack, ZStack | Shape, Fill, Border, Shadow, Opacity |
| Shape | Fill, Border, Shadow, Opacity |
| Stepper | Foreground, Font, Opacity – applied to the stepper's Label text |
| Switch Toggle | Foreground, Opacity – Foreground colours the title |
| Slider, Progress View, Divider, Segmented Control | Foreground, Opacity |
| Spacer | none |

A styled stack is the usual way to build a card: give a VStack padding, a **Fill**, a Rounded **Shape** and a **Shadow**, and put the content inside it.

A Button's **Shape** offers Rectangle, Rounded and Capsule; a capsule-shaped square button is already a circle.

## Off and On states

Documentation source: [Styling](https://scenery.app/docs/editor/user-interface/styling.md).

A **Toggle** with the **Custom** style can look different when it is on. With a Custom toggle selected, an **Off / On** tab bar sits at the top of the inspector:

* **Off** edits the toggle's normal look.
* **On** edits only what changes when it is switched on. Anything you leave unset on the On tab is taken from the Off tab, so a toggle that just turns orange when on needs one override: **Fill** on the On tab.

The tab applies to the Title, the Image and every Appearance Override. The canvas shows the toggle in the selected state, whatever its Default On setting. Default On, layout and the other shared settings apply to both states.

A typical Custom toggle: Title "Show Dimensions" with an eye image when off, "Hide Dimensions" with a crossed-out eye and a filled background when on.

## Copy and paste a style

Documentation source: [Styling](https://scenery.app/docs/editor/user-interface/styling.md).

Right-click a view and choose **Copy Style** (⌘⌥C), then **Paste Style** (⌘⌥V) on another. Paste replaces the target's whole style – the preset, every Appearance Override and both Off and On states. Its text, layout and other settings stay as they were.

Copy Style is available only on a view that has a style set.

---

Source page: Text & Variables

Source URL: https://scenery.app/docs/editor/user-interface/text.md

# Text & Variables

Documentation source: [Text & Variables](https://scenery.app/docs/editor/user-interface/text.md).

Labels do more than show fixed text. They understand a small set of **markdown** for emphasis, and they can show the live value of a **variable**, updating by themselves whenever it changes.

## Markdown in labels

Documentation source: [Text & Variables](https://scenery.app/docs/editor/user-interface/text.md).

Type markdown straight into a label's **Text** field. The field shows exactly what you typed; the canvas shows the result.

| You type | You get |
|---|---|
| `**Bold**` | **Bold** |
| `*Italic*` or `_Italic_` | *Italic* |
| `***Bold italic***` | ***Bold italic*** |
| `` `code` `` | `code`, in a monospaced font |

Line breaks and extra spaces are kept as typed, so you can write a short paragraph with a blank line between parts.

Formatting builds on the label's own **Font**: bold makes the chosen family and size bold, italic makes it italic. Headings, lists, block quotes, links and strikethrough are not drawn – the text shows without that formatting, and a link isn't tappable. For a tappable link, use a **Button** with an [Open Link](https://scenery.app/docs/editor/actions/experience) action.

Markdown works in **Labels** only. Button titles, toggle titles, stepper labels and segment titles show their text exactly as typed.

## Live values with variables

Documentation source: [Text & Variables](https://scenery.app/docs/editor/user-interface/text.md).

A label can include the current value of a variable. Write the variable's name inside `${ }`:

```
Score: ${score}
```

While the experience runs, `${score}` is replaced with the variable's value, and the label updates on its own each time the variable changes. A label can mix as many references and as much plain text as you like:

```
Round ${round} of 5 – ${g:points} points
```

| Write | Reads |
|---|---|
| `${name}` | a variable of the current scene |
| `${g:name}` | a variable of the whole experience, kept across scenes |

A variable that hasn't been set yet shows as `UNDEFINED`. Give it a starting value when the experience or scene starts so viewers never see that.

In the UI editor's canvas a label shows its references as typed, like `${score}`, so you can see what it reads. Use **Preview** to see the live values.

### Formatting numbers

Documentation source: [Text & Variables](https://scenery.app/docs/editor/user-interface/text.md).

Add a filter after a `|` to format a number:

| Filter | Does | `0.6789` becomes |
|---|---|---|
| `${v\|fixed(2)}` | Rounds to N decimals (default 2) | `0.68` |
| `${v\|percent}` | Multiplies by 100 and adds `%`, N decimals (default 0) | `68%` |
| `${v\|int}` | Drops the decimals | `0` |
| `${v\|signed(1)}` | Always shows a sign, N decimals (default 0) | `+0.7` |
| `${v\|time}` | Seconds as minutes and seconds, or hours past an hour | `185` becomes `3:05` |

Filters apply to numbers only. On text they leave the value unchanged, and so does a filter name that doesn't exist.

### Where variables come from

Documentation source: [Text & Variables](https://scenery.app/docs/editor/user-interface/text.md).

Variables are set by [scripts](https://scenery.app/docs/scripting/guide/user-interface#live-labels), and by controls a script has bound to a variable – a slider bound to `volume` updates `${volume}` in every label as it is dragged. Scripting needs the Pro plan, like User Interface itself.

## Wrapping, alignment and case

Documentation source: [Text & Variables](https://scenery.app/docs/editor/user-interface/text.md).

* **Wraps Text** is on for new labels, so long text flows onto more lines. In a panel sized to its content, labels wrap once the panel reaches about 1 m wide; give the label a **Max Width** to wrap it sooner.
* **Text Alignment** (Leading, Center, Trailing) matters once the text wraps, or when the label is set to Fill.
* **Text Transform** changes the case when the text is drawn – handy for headings in capitals. It is applied before markdown, so `**bold**` stays bold in Uppercase.
* **Letter Spacing** sits in the label's **Font** override, under Appearance Overrides.

---

Source page: Interaction

Source URL: https://scenery.app/docs/editor/user-interface/interaction.md

# Interaction

Documentation source: [Interaction](https://scenery.app/docs/editor/user-interface/interaction.md).

Controls in a panel work on their own – a toggle flips, a slider drags, a text field takes typing. To make something *happen* when they are used, add an event to the panel's object with the **UI Interaction** trigger, then add actions as for any other [event](https://scenery.app/docs/editor/triggers).

## Add a UI Interaction event

Documentation source: [Interaction](https://scenery.app/docs/editor/user-interface/interaction.md).

1. Select the User Interface object and add an event in **Object Events**.
2. Choose the **UI Interaction** trigger. It is offered only on User Interface objects.
3. Pick the **Interaction** first, then the **View** it should listen to. The view picker shows the panel's hierarchy; views that can't produce the chosen interaction are greyed out.
4. Add the actions.

Pick the interaction before the view: changing the interaction clears a view that can't produce it. Views appear in the picker under their **Name** – naming the views you connect events to keeps the list readable on a busy panel.

If you later delete a view that an event listens to, the event shows **Missing View** with a warning, and it never fires until you pick another view.

## Which views fire what

Documentation source: [Interaction](https://scenery.app/docs/editor/user-interface/interaction.md).

| Interaction | Fires when | Views |
|---|---|---|
| **Tap** | the view is tapped | Button, Label, Image, Shape |
| **Toggled** | the toggle is switched on or off | Toggle |
| **Value Changed** | the value changes | Toggle, Slider, Stepper, Segmented Control |
| **Text Changed** | the text in the field changes | Text Field |

Progress View, Divider, Spacer, Web View and the stacks fire no interactions.

A few things to know:

* **Labels, images and shapes** become tappable only once an event listens to them. Without one they are decoration, and on a screen-space panel touches pass straight through them.
* **Sliders** fire Value Changed continuously while they are dragged, and **Text Fields** fire Text Changed on every keystroke. Keep the actions on those events light, or the experience does the same work many times a second.
* The event fires on every change and doesn't check the new value – a Toggled event runs its actions whether the toggle went on or off.

## Using the value in a script

Documentation source: [Interaction](https://scenery.app/docs/editor/user-interface/interaction.md).

Every UI Interaction carries three values: which view fired (`uiNodeId`), which interaction it was (`uiInteractionKind`), and the new value (`uiValue`) – `true` or `false` for a toggle, a number for a slider or stepper, the selected index for a segmented control, the text for a text field. A **Run Script** action reads them from `scriptContext.sourceEvent`:

```javascript
// Run Script on a Slider's Value Changed event
var opacity = scriptContext.sourceEvent.uiValue;
var lamp = scene.findEntity({ name: 'Lamp' });
lamp.representation.opacity = opacity;
```

This is how a toggle's on and off can lead to different results, and how a slider can drive a property continuously.

## Common patterns

Documentation source: [Interaction](https://scenery.app/docs/editor/user-interface/interaction.md).

* **Show or hide content** – a Button's Tap event with [Add to Scene](https://scenery.app/docs/editor/actions/scene-content#add-to-scene), [Remove from Scene](https://scenery.app/docs/editor/actions/scene-content#remove-from-scene) or [Toggle Object](https://scenery.app/docs/editor/actions/scene-content#toggle-object) shows another object, or closes the panel itself.
* **Switch between variants** – one Button per variant, each with a Tap event that removes the current model and adds the next.
* **Next scene** – a Button's Tap event with a [scene transition](https://scenery.app/docs/editor/actions/experience).
* **Open a website** – a Button's Tap event with [Open Link](https://scenery.app/docs/editor/actions/experience).

## Changing a panel while it runs

Documentation source: [Interaction](https://scenery.app/docs/editor/user-interface/interaction.md).

Actions work on whole objects, so the event system shows, hides and swaps entire panels. To change one view inside a panel while the experience runs – update a label's text, hide a button, move a slider – use a script: find the view by its **Name** with `findView`, then set its properties, or bind it to a variable. See the scripting guide's [User Interface](https://scenery.app/docs/scripting/guide/user-interface) page.

Set a panel up from a Run Script on the panel's own **On Will Appear** event: the views exist by then, and the panel isn't visible yet, so nothing jumps. See [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines#adapting-per-platform).

A label can also follow a variable without any script of its own, through `${name}` in its text – see [Text & Variables](https://scenery.app/docs/editor/user-interface/text#live-values-with-variables).

---

Source page: Design Guidelines

Source URL: https://scenery.app/docs/editor/user-interface/design-guidelines.md

# Design Guidelines

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

A panel in AR competes with the real world behind it: a moving camera image, bright windows, busy textures. What reads well on a flat screen can be hard to read on a panel two metres away. These guidelines give concrete values that work. They follow Apple's [Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines/), translated into the units the UI editor uses.

The short version: **few elements, generous space, large text, real contrast.**

## Know your viewing distance

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

Sizes in the UI editor are in points. Where the panel is decides what a point means:

* **Screen space** – a point is a point on the phone or tablet screen, exactly as in any app. Apple's iPhone and iPad sizes apply as they are.
* **In the world** – about **1360 points make one metre**. That is close to the scale of an Apple Vision Pro window at its usual distance, so Apple's Vision Pro sizes work for a panel viewed from about **1–1.5 m**.

Text has to grow with distance. A panel read from 3 m needs roughly twice the text size of one read from 1.5 m. Rather than retyping every size, scale the whole object up in the main editor: everything inside it grows together and keeps its proportions.

On an iPhone or iPad, a panel in the world is seen through a small screen, often from further away than people expect. Put text people must read – instructions, scores, critical labels – in a [screen-space](https://scenery.app/docs/editor/anchors#screen-space) panel on handheld devices, and keep world panels for content that belongs to a place or an object. [Per-device anchoring](https://scenery.app/docs/editor/user-interface/#where-a-panel-appears) does both with one panel.

## Sizing panels

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

**Pick the panel size mode by what the panel does:**

* **Hug** for almost everything. The panel fits its content, grows when a label gets longer, and works on every device without adjustment.
* **Fixed** when the panel must keep its outline – a scoreboard whose numbers change, a panel beside other content, or anything **Scrollable**.
* **Fill** only for screen-space panels that should cover the whole screen, such as a start screen or a pause overlay.

Inside a Hug panel, set the width through the content, not the panel: a **Max Width** on the main text block sets the panel's width, and rows set to Fill stretch to match it. A Hug panel with no Max Width anywhere grows to about 1 m before its text wraps.

**Physical sizes for panels in the world**, at 1360 pt per metre:

| Panel | Width | About |
|---|---|---|
| Label or tag on an object | 200–320 pt | 15–25 cm |
| Info card | 400–600 pt | 30–45 cm |
| Large panel, read from a few metres | 800–1000 pt | 60–75 cm |

Size for the **distance**, not for the screen you edit on. The UI editor's canvas shows the panel at screen size, which always looks larger than it will appear in the room. Check sizes in **Preview** on the device people will use, at the distance they will stand.

**Screen-space panels have to fit the smallest screen.** An iPhone in portrait is about 375 pt wide. Keep screen-space panels at or under about **340 pt** wide (Hug with a Max Width, or Fixed), so they fit with a margin on every phone; iPad and Mac then simply show them with more room around them. On Apple Vision Pro, screen-space panels share a layer of about **730 × 540 pt**, so design them to fit inside that.

## Adapting per platform

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

A panel that works on a phone isn't automatically right on Vision Pro, and the other way round. Three tools, from simplest to most flexible:

**1. Per-device anchoring.** One panel, placed differently per device category: **Handheld → Screen Space** for a readable HUD on phones and tablets, **Spatial → Position** for a panel in the room on Vision Pro. Set it under **Device Configuration** in the object's [anchor settings](https://scenery.app/docs/editor/anchors#per-device-anchoring-device-configuration).

**2. One panel per device category.** When the layouts should really differ – a compact HUD on iPhone, a larger card with more detail on Vision Pro – build two panels and use **Hidden** in Device Configuration so each one appears only on its devices. Both can listen to the same events and show the same variables.

**3. A script.** A script can read the device category and adjust the panel before anyone sees it. Put a **Run Script** action on an **On Will Appear** event of the panel object itself:

```javascript
// Object event on the panel: On Will Appear → Run Script
var panel = scriptContext.sourceEvent.objectEntity;

if (environment.deviceCategory === 'spatial') {
    // Apple Vision Pro: people stand further back, so the whole panel grows
    panel.scale = Vector3(1.5, 1.5, 1.5);
} else {
    // iPhone, iPad and Mac: keep it compact
    panel.representation.findView({ name: 'Details' }).isHidden = true;
}
```

`environment.deviceCategory` is `'handheld'` (iPhone, iPad), `'spatial'` (Apple Vision Pro) or `'desktop'` (Mac). Scaling the object resizes everything in a world panel together; a screen-space panel ignores the object's scale. Showing and hiding views lets one panel carry a short and a long version of its content. See [Find and update views](https://scenery.app/docs/scripting/guide/user-interface#find-and-update-views) for what a script can change.

**Pick the hook that runs before the panel is visible.** **On Will Appear** fires once the panel has loaded, before it is shown and before its Reveal Animation plays, so the adjustment is already in place when it appears. Two hooks look similar but cause problems:

* **On Experience Start** or a scene start event runs before the panel has loaded. Its views don't exist yet, so `findView` returns nothing and the change is lost.
* **On Did Appear** runs after the panel is on screen. The change is visible as a jump – the panel appears, then resizes or loses a row – and it fights the Reveal Animation.

The same applies to anything a script sets up on a panel: label text, bindings, `on(…)` listeners. Do it in the panel's On Will Appear.

## Typography

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

| Role | Size | Weight |
|---|---|---|
| Title | 24–28 pt | Semibold or Bold |
| Body | **17 pt** | Regular or Medium |
| Secondary text, captions | 13–15 pt | Regular or Medium |
| Absolute minimum | 12 pt (11 pt in screen space on iPhone) | – |

* **Use two or three sizes per panel**, not more. Hierarchy comes from a clear jump in size or weight, not from many small steps.
* **One font family.** System or Rounded suit most panels; add Monospaced only for numbers that change, like timers and scores.
* **No thin weights.** Regular is the lightest weight to use; small text often reads better in Medium or Semibold in AR.
* **Keep lines short.** Turn on **Wraps Text** and give body text a **Max Width** of about 400–560 pt. That keeps lines to a comfortable length (around 60 characters at 17 pt) instead of one long line across a wide panel.
* **Emphasise with weight, not colour alone.** `**Bold**` in a label is clearer than a coloured word.
* **Uppercase sparingly.** Text Transform → Uppercase works for short labels and section headings, not for sentences.

## Contrast and colour

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

* Panels always render in **dark appearance**: light text on a dark, translucent surface. White and light grey text is the safe default.
* Aim for a contrast ratio of at least **4.5:1** for text up to 17 pt, and **3:1** for larger or bold text.
* **Text needs a surface.** Text on a **Transparent** panel sits directly on the camera image and becomes unreadable over bright or busy backgrounds. Put readable text on the **System** material or a **Solid** fill.
* Don't rely on shadows to rescue contrast; give the text a surface or a bolder weight instead.
* Don't use colour as the only signal. A selected state, an error or a correct answer should also change an icon, a label or a shape.
* Use one accent colour for the primary action, and keep the rest neutral.

## Touch targets

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

| Where | Minimum size of anything tappable |
|---|---|
| Screen space on iPhone and iPad | **44 × 44 pt** |
| In the world, and on Apple Vision Pro | **60 × 60 pt** |

* A button's padding is part of its target, and padding is how you reach the size. With the default 8 pt top and bottom padding, a 15 pt title makes a button only about 34 pt tall. A **17 pt** title with **12 pt** top and bottom padding is about 44 pt; with **20 pt** it is about 60 pt.
* On Vision Pro, keep the centres of neighbouring buttons at least **60 pt apart**, with **16 pt** or more between them, so people's gaze lands on the one they mean.
* Make the whole row tappable rather than a small icon at its end.

## Spacing and padding

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

Use an **8-point grid**: 4, 8, 12, 16, 24, 32. Values off the grid make a panel look slightly wrong even when nobody can say why.

| Space | Value |
|---|---|
| Panel padding (around everything, on the root stack) | **16–24 pt** |
| Between items that belong together (a title and its text) | **4–8 pt** |
| Between groups (text block and buttons) | **16–24 pt** |
| Between buttons in a row | **8–12 pt**, 16 pt on Vision Pro |
| Inside a button or chip | 8–12 pt vertical, 12–16 pt horizontal |

* **Whitespace is the structure.** Group with space first; reach for Dividers and boxes only when space isn't enough.
* **Never let content touch the panel edge.** Always pad the root stack.
* **Align to one edge.** In a VStack, use one alignment – usually Leading for text, or Fill so rows share a width. Mixed alignments make a panel look unplanned.
* **Equal buttons get equal widths:** put them in an HStack with **Fill Equally**.
* Use a **Spacer** to push items apart, not a large fixed spacing.

## Corners and surfaces

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

* **Nested corners are concentric**: an element inside the panel gets a radius of the panel's radius minus the padding between them. A panel with a 24 pt radius and 16 pt padding takes cards or buttons with an 8 pt radius.
* Pick one radius family per panel – for example 24 pt for the panel, 12 pt for cards, Capsule for buttons – and reuse it.
* **One surface is usually enough.** A System panel with flat content reads better than a panel full of shadowed cards. Use a card (a stack with Fill, Shape and Shadow) only to set one group apart.
* Prefer **translucent** surfaces over large opaque ones in the world: an opaque wall of colour blocks the view and feels heavy. Use Solid fills for small elements – buttons, badges, chips.

## Where to put UI in AR

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

* **Keep the camera view clear.** On iPhone and iPad, put a screen-space HUD at an edge or a corner and leave the centre of the screen to the scene.
* **Show only what is needed now.** Split a long flow into steps and show one panel at a time with [Add to Scene](https://scenery.app/docs/editor/actions/scene-content#add-to-scene) and [Remove from Scene](https://scenery.app/docs/editor/actions/scene-content#remove-from-scene), rather than one panel that holds everything.
* **Keep words few.** People in AR are looking at the world, not reading. A title and one or two short lines usually do.
* **Face the viewer.** Give text panels in the world the [Billboard](https://scenery.app/docs/editor/asset-appearances#transform-alignment) alignment so they stay readable from an angle, and place them at about eye height.
* **Don't make people move to use the UI.** Controls they need often belong in screen space or within comfortable reach, not across the room.
* **Mind the 50-view limit.** A panel that needs more than a few dozen views is usually several panels.

## A worked example

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

An info card placed next to an object, read from about 1.5 m:

```
Panel       Size Hug · Material System · Corner Radius 24
└── VStack  alignment Leading · spacing 16 · padding 24 · Max Width 480
    ├── VStack  alignment Leading · spacing 4
    │   ├── Label  "Lounge Chair"            Font 28 pt Bold
    │   └── Label  "Oak and wool, 2026"       Font 15 pt Medium, light grey
    ├── Label  "Hand-finished in Berlin …"  Font 17 pt Regular · Wraps Text
    └── HStack  distribution Fill Equally · spacing 16
        ├── Button  "Colours"   Style Primary · Shape Capsule · Font 17 pt Semibold · padding 20 / 24
        └── Button  "Details"   Style Secondary · Shape Capsule · Font 17 pt Semibold · padding 20 / 24
```

(Padding 20 / 24 means 20 pt top and bottom, 24 pt leading and trailing.)

Three text sizes, one family, 16 and 24 pt spacing on the grid, 60 pt buttons, and nothing touching the edge.

## Checklist

Documentation source: [Design Guidelines](https://scenery.app/docs/editor/user-interface/design-guidelines.md).

Before you finish a panel – and when an AI agent builds one – check:

* \[ ] The root stack has **16–24 pt padding** and nothing touches the panel edge.
* \[ ] All spacing and padding values are on the **8-point grid** (4, 8, 12, 16, 24, 32).
* \[ ] Body text is **17 pt or larger**; nothing is under **12 pt**; no Thin or Light weights.
* \[ ] There are **at most three** text sizes and **one** font family.
* \[ ] Long text has **Wraps Text** on and a **Max Width** of about 400–560 pt.
* \[ ] Every tappable view is at least **44 pt** (screen space) or **60 pt** (world, Vision Pro) in both directions.
* \[ ] Readable text sits on a **System** or **Solid** surface, not directly on a Transparent panel.
* \[ ] Groups are separated by space, and items within a group sit closer together than the groups do.
* \[ ] Nested corner radii are concentric, and one radius family is used.
* \[ ] Buttons that belong together have equal widths (**Fill Equally**).
* \[ ] The panel size suits its distance: world panels follow the size table above, screen-space panels are at most about 340 pt wide.
* \[ ] Each device category gets a placement that suits it (Device Configuration), checked in Preview on the real device.
* \[ ] Scripts that set up the panel run from its **On Will Appear** event, not from the scene start or On Did Appear.
* \[ ] The panel shows only what is needed at this moment, in as few words as possible.
* \[ ] Views that events or scripts use have a **Name**.

---

Source page: Events & Triggers

Source URL: https://scenery.app/docs/editor/triggers.md

# Events & Triggers

Documentation source: [Events & Triggers](https://scenery.app/docs/editor/triggers.md).

Events are how an experience becomes interactive: a **trigger** decides *when* something happens, and one or more **actions** decide *what* happens. This page covers events and their triggers – for the actions themselves, see [Actions](https://scenery.app/docs/editor/actions).

You'll find events in the **Events panel** at the bottom of the editor (drag it upward for more room as it grows). Events come in two kinds, split down the middle of the panel:

* **Scene events** – apply to the whole scene.
* **Object events** – belong to a specific object.

::: tip Keep your events tidy
Deleting an object doesn't remove events that referenced it – they're left behind as "unlinked." After deleting content, glance through your events to keep things clean.
:::

![The Events panel at the bottom of the editor, split into Object events on the left and Scene events on the right](https://scenery.app/docs/assets/events-panel.fqcssPPN.jpg)
*The Events panel – Object Events and Scene Events.*

## Scene events

Documentation source: [Events & Triggers](https://scenery.app/docs/editor/triggers.md).

Scene-wide. When you add your first content, an **Add to scene** event on **On Experience Start** is created for you, so that content appears when the experience starts. (Rename events to describe what they do – it keeps complex scenes readable.)

### Scene triggers

Documentation source: [Events & Triggers](https://scenery.app/docs/editor/triggers.md).

* **On Experience Start** – fires once when the experience starts. The one you'll use most.
* **On Screen Tap** – fires when the user taps anywhere on the screen (not tied to an object), with an optional screen-area filter.
* **On Schedule** – fires on a timer. Either an **interval** (every N seconds, repeating a set number of times or indefinitely) or a specific **date & time** (with a choice of what to do if that time has already passed – skip it, or fire immediately).
* **Custom** – fired programmatically; used with scripting.
* **On Experience Load** – fires *earlier* than On Experience Start: while the scene is being prepared and assets load, before playback begins. Use it for setup that should happen before the user sees anything.
* **On Render** – fires every frame, with an optional **frame throttle** (a minimum time between fires – higher values reduce processing at the cost of responsiveness).

![The scene trigger picker – On Experience Start, On Screen Tap, Custom, On Schedule, On Experience Load, On Render](https://scenery.app/docs/assets/scene-trigger-picker.DJeTbJxw.jpg)
*The Scene trigger picker.*

**On Experience Load vs. On Experience Start:** *Load* runs during preparation (while assets load), *Start* runs when the experience actually begins playing. **Schedule** options are exactly an interval (seconds + repeat count, indefinite supported) or a date & time (with skip-if-passed / fire-immediately fallback).

::: info Scripting triggers
**On Experience Load**, **On Render**, and **Custom** are part of the scripting toolset. Scripting is part of the **Pro** plan and up; on a free account these triggers are marked Pro and open the plan offer. See [Developer actions](https://scenery.app/docs/editor/actions/developer).
:::

## Object events

Documentation source: [Events & Triggers](https://scenery.app/docs/editor/triggers.md).

Object events belong to a specific object and are grouped under it in the panel. Nothing is created automatically – it's entirely up to you. Add one with the **+** (or the **Add event** area), choose the **target** (an object can contain several models or media), then pick a trigger.

### Object triggers

Documentation source: [Events & Triggers](https://scenery.app/docs/editor/triggers.md).

* **On Will Appear** – just before the object appears.
* **On Did Appear** – right after it appears in the scene.
* **On Removal** – when it's removed from the scene.
* **On Tap Gesture** – when the user taps *this object* specifically (not the screen).
* **On Camera Collision** – when the camera passes through the object. Great for walk-through and collection mechanics.
* **On Object Collision** – when this object collides with another object you choose; fires on collision **began** or **ended**. Both objects need **physics** enabled – physics is what creates the collider that makes collisions detectable.
* **Distance Field** – based on the distance (in metres) between the object and the camera, or another object you choose; fires on **enter** or **exit** of that distance. Useful for proximity effects like fading ambient audio in and out.
* **Look Direction** – based on looking: by default, the user looking *at* the object (it can also be one object facing another). Fires on **look at** or **look away**, after a minimum duration.
* **Video Playback** – appears only for **video** elements. Fires when playback **begins**, **ends**, or reaches a **timestamp** you pick (with a frame-accurate scrubber to choose the exact moment). Great for syncing content to a video's timeline – e.g. spawn an object at 0:05, or branch a story at a chosen point.
* **UI Interaction** – appears only for **User Interface** elements. Fires when the user interacts with a view in the panel: a **Tap**, a **Toggled** switch, a **Value Changed** on a slider, stepper or segmented control, or a **Text Changed** in a text field. Pick the interaction, then the view. See [Interaction](https://scenery.app/docs/editor/user-interface/interaction).
* **On Gesture** – appears only for objects that have a **gesture** enabled (drag, rotate or resize). Where **On Tap Gesture** reacts to a tap, this reacts to the user actually *moving* the object, so you can respond to the manipulation itself. Pick the **phase** it fires on:
  * **Gesture Began** – the moment the user grabs the object.
  * **While Moving** – continuously, as the object is being moved. Use it for live updates that should follow the object.
  * **Gesture Ended** – when the user lets go.
  * **Any** – every phase. Note this fires on every frame of the movement, so prefer a specific phase unless that is what you want.

![The object trigger picker – On Will Appear, On Did Appear, On Removal, On Tap Gesture, On Camera Collision, On Object Collision, Distance Field, Look Direction](https://scenery.app/docs/assets/object-trigger-picker.CyfjxxeL.jpg)
*The Object trigger picker.*

## Event options

Documentation source: [Events & Triggers](https://scenery.app/docs/editor/triggers.md).

Every event offers:

* **Name** – for clarity in busy scenes.
* **Target** (object events) – which object / representation it applies to.
* **Can repeat** – whether it can fire more than once, or only once.
* **Is enabled** – turn the event on or off. Events can be enabled/disabled by *other* events and actions, which is how you build on/off cycles.
* **SharePlay synchronization** – whether the trigger also fires for other people in a shared experience. Usually leave this on.

![An event's options – name, target object, and the Is enabled toggle](https://scenery.app/docs/assets/event-options.C8rIJIZ-.jpg)
*An event's options – Name, Object, and Is Enabled.*

::: tip Build back-and-forth interactions
Because actions can toggle **Is enabled** on other events, you can make the same object alternate – e.g. tap to open (then disable "open" and enable "close"), tap again to close.
:::

## Triggers vs. actions

Documentation source: [Events & Triggers](https://scenery.app/docs/editor/triggers.md).

A trigger decides *when*; **actions** decide *what happens*. Add actions from the **+** on the right of an event, or right-click the action canvas for a quicker browsable list. By default, actions run **sequentially** (one after another); drag one onto another to form a **group**, whose actions run **simultaneously**. See [Actions](https://scenery.app/docs/editor/actions) for the full set.

---

Source page: Actions

Source URL: https://scenery.app/docs/editor/actions.md

# Actions

Documentation source: [Actions](https://scenery.app/docs/editor/actions.md).

Actions are *what happens* when an [event's trigger](https://scenery.app/docs/editor/triggers) fires. Each event holds one or more actions, shown on its action canvas.

Add an action from the **+** on the right of an event, or **right-click the canvas** for a quicker, browsable list. Actions are grouped into the categories below.

## How actions run

Documentation source: [Actions](https://scenery.app/docs/editor/actions.md).

* **Sequential by default** – without grouping, actions run one after another (shown by a small arrow between them).
* **Group** – drag one action onto another to form a group; actions in a group run **simultaneously**.
* **Convert** – right-click a group to convert it into a **Sequence**, **Random**, **Repeat**, or **Cycle**.

::: tip Build complex behaviour by nesting
Mix and match groups and sequences to choreograph an experience – e.g. a sequence that waits, plays a sound, then runs a group of animations together.
:::

## Categories

Documentation source: [Actions](https://scenery.app/docs/editor/actions.md).

* **[Scene Content](https://scenery.app/docs/editor/actions/scene-content)** – add, remove, and show/hide objects.
* **[Action Ordering](https://scenery.app/docs/editor/actions/action-ordering)** – group, sequence, wait, random, repeat, cycle, conditional logic.
* **[Animations & Appearance](https://scenery.app/docs/editor/actions/animations-appearance)** – animate objects, modify transform, blendshapes, particles.
* **[Audio & Haptics](https://scenery.app/docs/editor/actions/audio-haptics)** – ambient bed, per-object audio, haptics.
* **[Video](https://scenery.app/docs/editor/actions/video)** – play / pause and seek video.
* **[Physics](https://scenery.app/docs/editor/actions/physics)** – impulses and physics resets.
* **[Experience](https://scenery.app/docs/editor/actions/experience)** – scene transitions, post-FX, links, pause / end.
* **[Dynamic Scene Adjustments](https://scenery.app/docs/editor/actions/dynamic-scene-adjustments)** – custom events, toggling events and gestures.
* **[Developer](https://scenery.app/docs/editor/actions/developer)** – debug messages and scripts (appears when scripting is enabled).

::: info Variables
Variable actions (Set / Modify Variable) aren't in this menu.
:::

---

Source page: Scene Content

Source URL: https://scenery.app/docs/editor/actions/scene-content.md

# Scene Content

Documentation source: [Scene Content](https://scenery.app/docs/editor/actions/scene-content.md).

Actions that bring objects into the scene, take them out, or show and hide them. (For how to add actions and how they run, see [Actions](https://scenery.app/docs/editor/actions).)

## Add to Scene

Documentation source: [Scene Content](https://scenery.app/docs/editor/actions/scene-content.md).

Adds an object to the scene when the trigger fires – use it to bring content in **dynamically** (e.g. on a tap) rather than at the start.

By default, content you place is added automatically by an **Add to Scene** action on **On Experience Start**. If you'd rather introduce something later, delete that default action and add it from the event you want.

**Options**

* **Target Object** – the object to add.

## Remove from Scene

Documentation source: [Scene Content](https://scenery.app/docs/editor/actions/scene-content.md).

Removes an object from the scene. When the action sits on the object itself it removes that object; you can also target a different one.

**Options**

* **Target Object** – the object to remove.

## Toggle Object

Documentation source: [Scene Content](https://scenery.app/docs/editor/actions/scene-content.md).

Shows or hides a specific object. Each Toggle Object action sets a **fixed** state – shown or hidden – rather than flipping the object relative to whatever it currently is. The action's label reads **Show Object** or **Hide Object** to match.

**Options**

* **Target Object** – the object to show or hide.
* **Show** – on shows the object, off hides it.

To alternate an object **on each tap** (show, then hide, then show again), don't stack a Show and a Hide action on one trigger – both would run and the object would simply end on the last one. Instead, toggle the **Is enabled** state of two events that show and hide it (see [Events & triggers](https://scenery.app/docs/editor/triggers#event-options)).

---

Source page: Action Ordering

Source URL: https://scenery.app/docs/editor/actions/action-ordering.md

# Action Ordering

Documentation source: [Action Ordering](https://scenery.app/docs/editor/actions/action-ordering.md).

By default, an event's actions run **sequentially** – one after another, shown by the arrow between them. These actions let you change that flow and structure complex interactivity. You can also build groups and sequences just by dragging actions on top of each other. (See [Actions](https://scenery.app/docs/editor/actions) for the basics.)

## Group

Documentation source: [Action Ordering](https://scenery.app/docs/editor/actions/action-ordering.md).

Runs the actions inside it **simultaneously**.

## Sequence

Documentation source: [Action Ordering](https://scenery.app/docs/editor/actions/action-ordering.md).

Runs the actions inside it **one after another**.

## Wait

Documentation source: [Action Ordering](https://scenery.app/docs/editor/actions/action-ordering.md).

Pauses for a set time before the next action runs.

**Options**

* **Wait Duration** – the pause, in seconds.

::: tip Use Wait sparingly
Timing an experience mostly with Wait actions is fragile – change one animation and the whole chain falls out of sync. Prefer to drive timing from the animations and events themselves, and use Wait only for fine-tuning (a beat of breathing room after a video, for instance).
:::

## Random

Documentation source: [Action Ordering](https://scenery.app/docs/editor/actions/action-ordering.md).

Runs **one** randomly chosen action from the ones you place inside it – useful for surprise and variety in gamified experiences. It only picks from the actions you add, so the randomness stays controlled.

## Repeat

Documentation source: [Action Ordering](https://scenery.app/docs/editor/actions/action-ordering.md).

Repeats the actions inside it a set number of times.

**Options**

* **Repeat Count** – how many times (1–9).

## Cycle

Documentation source: [Action Ordering](https://scenery.app/docs/editor/actions/action-ordering.md).

Steps through several **states** each time it fires – each state is its own set of actions. Use it for multi-step toggles, e.g. cycling a light through off → dim → bright on repeated taps.

**Options**

* **Number of States** – 2 to 6.
* **Mode** – **Loop** (wraps back to the first state after the last), **Ping Pong** (advances to the last state, then reverses), or **One Shot** (advances and stops at the last state).

## Conditional Logic

Documentation source: [Action Ordering](https://scenery.app/docs/editor/actions/action-ordering.md).

Runs actions only if a condition is met, with an optional "else" branch for when it isn't.

**Options**

* **Condition** – what to ask:
  * **Platform Is** – the operating system: iOS & iPadOS, macOS, visionOS, or WebXR. Use it when the distinction you need is between a Mac and the web, which the two below cannot make.
  * **Device Is** – the kind of device: Handheld, Spatial, or Desktop. The same vocabulary the [Device Configuration](https://scenery.app/docs/editor/anchors#per-device-anchoring-device-configuration) picker uses for anchors, and the better choice for "is this a headset", since it keeps working as new devices arrive.
  * **Feature Is Supported** – whether a capability is actually available on the device running the experience. Neither of the above answers this: Bloom, for instance, needs a recent OS **and** capable hardware **and**, on Apple Vision Pro, an immersive space. Pick the feature and put the fallback in the else branch.

The model also carries value-based conditions (value equal, value less-or-equal) and script evaluation. An action already using one shows it here, but the picker cannot switch to them, because nothing in it edits the values they compare.

---

Source page: Animations & Appearance

Source URL: https://scenery.app/docs/editor/actions/animations-appearance.md

# Animations & Appearance

Documentation source: [Animations & Appearance](https://scenery.app/docs/editor/actions/animations-appearance.md).

Actions that move, animate, and change how objects look. (For how actions are added and ordered, see [Actions](https://scenery.app/docs/editor/actions).)

## Animate Object

Documentation source: [Animations & Appearance](https://scenery.app/docs/editor/actions/animations-appearance.md).

Plays an animation on an object. Selecting it opens a dedicated view: a **ghost outline** shows the object's start state, and you drag the model (or type values) to define the end state.

![The Animate Object editor – animation type, a timing curve, and per-property controls, with the animating model in the viewport](https://scenery.app/docs/assets/animate-object.BIxMFRZ3.jpg)
*The Animate Object editor – animation type, timing curve, and per-property controls.*

**Animation type** – pick how the object animates:

* **From / To** – animate between an explicit **start** and **end** state. You can animate the **transform** (position, rotation, scale), **opacity**, and **blendshape weights** (on a model that has them – set start weights and end weights, together or individually via *apply to all*).
* **From / By** – animate by a **relative amount** from wherever the object currently is, rather than to a fixed end state. (Useful when the start isn't known in advance – e.g. "rotate by 90°" regardless of current rotation.)
* **Model animation** – play an animation **baked into the 3D model**. A model carries a single baked timeline, so to use several animations, bake them into one and **trim** to a start/end timestamp (plus an optional delay) per action.
* **Spin** – continuous rotation around an axis.
* **Orbit** – orbit around an axis, with control over axes, number of revolutions, direction (clockwise/counter), and **orient to path** (face the direction of travel).
* **Presets** – ready-made motions (pop, blink, bounce, flip, float, jiggle, pulse, spin), each with a **motion style**: basic, playful, or wild.

![The Presets animation type – a motion type with Basic, Playful, and Wild styles](https://scenery.app/docs/assets/animation-presets.6hshkYcu.jpg)
*Preset motions, with Basic / Playful / Wild styles.*

**Common options** (where applicable):

* **Duration** – how long the animation runs, in seconds.
* **Transition duration** – eases the change in speed.
* **Delay** – wait before the animation starts.
* **Repeat mode** – No repeat, a fixed **Count**, **Forever**, **Auto-reverse** (play then reverse), or **Cumulative** (each repeat continues from where the last ended rather than restarting).
* **Additive** – blend this animation on top of other concurrent animations instead of overriding them.
* **Timing curve** – Linear, Ease In, Ease Out, Ease In Out, or a custom **Cubic Bézier** (drag the control points) to make motion feel natural rather than mechanical.
* **Reference space** – the frame the motion is interpreted in: the object's own space (default), **World** (the scene), or **Point of View** (relative to the camera). It matters because "move up" or "rotate" mean different things depending on the frame.

![The custom Cubic Bézier timing curve editor with draggable control points](https://scenery.app/docs/assets/timing-curve.DV9NIPjs.jpg)
*The custom Cubic Bézier timing curve.*

::: tip Preview a single action
Use the **Run action** button to preview just this animation, without entering full preview mode – much faster to iterate.
:::

## Modify Transform

Documentation source: [Animations & Appearance](https://scenery.app/docs/editor/actions/animations-appearance.md).

Changes an object's **position, rotation, or scale** when the action fires, without a full animation. Choose a **mode** (To or By), a target object, optional **transition smoothing**, and a **reference space** (local, world, or point of view).

Use **Modify Transform** for a direct, one-step change; reach for **Animate Object** when you want a timed animation with a duration, repeat, and timing curve.

![The Modify Transform action – mode, target, reference space, and start/end transform values](https://scenery.app/docs/assets/modify-transform.IvrVzRkZ.jpg)
*The Modify Transform action.*

## Update Blendshape Weights

Documentation source: [Animations & Appearance](https://scenery.app/docs/editor/actions/animations-appearance.md).

Sets the **blendshape weights** (morph targets / shape keys) on a model that has them – the controls that morph a mesh, like facial expressions or a blooming flower. Pick the target, the **weight set** (if the model has more than one), and either set **all** weights together or adjust them individually (the *apply to all* toggle).

This **sets** weights directly; to animate them over time, use **Animate Object** with the blendshape-weights property instead.

![Update Blendshape Weights – per-target weight sliders with an apply-to-all toggle](https://scenery.app/docs/assets/blendshape-weights.C5cL6t_w.jpg)
*Update Blendshape Weights – per-target sliders.*

## Play/Pause Animations

Documentation source: [Animations & Appearance](https://scenery.app/docs/editor/actions/animations-appearance.md).

Toggles an object's animations – on/off, resume or pause. It affects animations you set up in Scenery, and can also affect a model's **built-in (model-included) animations**.

::: tip Built-in animations autoplay by default
A model's baked-in animations play automatically when it's added. To drive one with this action instead, first turn off **Autoplay model animations** in that model's **Appearance** properties.
:::

## Stop Animations

Documentation source: [Animations & Appearance](https://scenery.app/docs/editor/actions/animations-appearance.md).

Completely **stops and removes** an object's animations (use it when you don't intend to resume them), with an optional **transition duration** for how quickly they stop.

## Burst Particles

Documentation source: [Animations & Appearance](https://scenery.app/docs/editor/actions/animations-appearance.md).

Emits a one-off burst from a model's **particle system**. The model must actually contain particles – particle systems are created in Reality Composer Pro and imported as USDZ. (In the asset library you can filter for **contains particles**; several particle assets ship with paid plans.)

**from-by** = a relative delta vs from-to's absolute end; **cumulative** repeat accumulates across loops; **reference space** = the object's own/local frame (default), World, or Point of View; the preset **motion types** and **styles** match the editor exactly.

---

Source page: Audio & Haptics

Source URL: https://scenery.app/docs/editor/actions/audio-haptics.md

# Audio & Haptics

Documentation source: [Audio & Haptics](https://scenery.app/docs/editor/actions/audio-haptics.md).

Actions for sound and touch. (For how actions are added and ordered, see [Actions](https://scenery.app/docs/editor/actions).)

## Two kinds of audio: Ambient vs. Play Audio

Documentation source: [Audio & Haptics](https://scenery.app/docs/editor/actions/audio-haptics.md).

Scenery gives you two distinct tools for sound, each suited to a different job:

* **Ambient audio** (Set / Toggle Ambient Audio) is the **scene-wide background bed** – music, or a narrator that guides the whole experience. It lives **independently of any object**.
* **Play Audio** plays a sound **emitted from a specific object** (e.g. a plane's engine), tied to that object.

Choose by what the sound *is*: background music or narration → **Ambient audio**; a sound that belongs to an object → **Play Audio**.

## Set Ambient Audio

Documentation source: [Audio & Haptics](https://scenery.app/docs/editor/actions/audio-haptics.md).

Sets the background audio bed for the scene.

**Options**

* **Audio** – the audio file to play.
* **Play instantly** – start immediately, or wait to be started.
* **Fade duration** – fade-in length.
* **Volume** – overall level, handy for balancing against other sounds without leaving the editor.

![The Set Ambient Audio action – the audio file, Plays Instantly, Fade Duration, and Audio Volume](https://scenery.app/docs/assets/set-ambient-audio.B6lfSusz.jpg)
*The Set Ambient Audio action.*

## Toggle Ambient Audio

Documentation source: [Audio & Haptics](https://scenery.app/docs/editor/actions/audio-haptics.md).

Turns the ambient bed on or off – set to **Automatically**, **Enable playback**, or **Disable playback**.

::: tip Duck the music near an object
Pair this with a [Distance Field](https://scenery.app/docs/editor/triggers#object-triggers) trigger: disable the ambient bed when the user comes close to a talking object, and enable it again when they leave.
:::

## Play Audio

Documentation source: [Audio & Haptics](https://scenery.app/docs/editor/actions/audio-haptics.md).

Plays a sound emitted from an object.

**Options**

* **Audio** – upload a file, or pick an **Integrated Asset** (built-in presets for AR scavenger-hunt moments: checkpoint reached, object collected/found, modifier unlocked).
* **Audio mode** – how the sound sits in space:
  * **Spatial** – fully 3D: the sound comes from the object's location, pans as the listener turns, and grows louder as they move closer. The usual choice for an object's sound. Use a **mono** source so it spatializes cleanly.
  * **Non-spatial** – flat: it plays the same wherever the listener stands or faces, like a 2D sound effect. (Still attached to the object, unlike the scene-wide Set Ambient Audio.)
  * **Ambient** – in between: it pans left and right with the listener's facing direction, but doesn't get louder or quieter with distance.
* **Volume** – level.
* **Loop** – repeat or play once.

![The Play Audio action with its audio mode menu – Spatial, Non-spatial, Ambient](https://scenery.app/docs/assets/play-audio-mode.7ZE0n_JZ.jpg)
*The Play Audio action and its Audio Mode menu.*

Spatial = directional panning plus distance attenuation; Ambient = directional panning only; Non-spatial = no spatialization.

::: tip Object sounds can also live on the object
If a sound is really a permanent sound effect for a model, you can attach it in the model's **Properties** (audio & haptics) instead of via an action, with the same mode and volume controls.
:::

## Fade Audio

Documentation source: [Audio & Haptics](https://scenery.app/docs/editor/actions/audio-haptics.md).

Fades an object's audio up or down to a target level.

**Options**

* **Target Object**, **Volume** (0–200), **Fade duration**.

## Seek Audio

Documentation source: [Audio & Haptics](https://scenery.app/docs/editor/actions/audio-haptics.md).

Jumps an object's audio to a specific **timestamp** (hours / minutes / seconds) – useful for jumping between sections of one longer file based on what the user does.

## Stop Audio

Documentation source: [Audio & Haptics](https://scenery.app/docs/editor/actions/audio-haptics.md).

Stops the audio on an object, with an optional **fade duration**.

## Emit Haptic Feedback

Documentation source: [Audio & Haptics](https://scenery.app/docs/editor/actions/audio-haptics.md).

Plays a haptic (a touch / vibration pattern) – a small detail that makes interactions feel more tangible.

**Options**

* **Custom asset** – upload an **AHAP** haptic file (created in external tooling; also covered under a model's audio & haptics properties).
* **Integrated asset** – built-in patterns: impact **Light, Medium, Heavy, Soft, Rigid**, and a selection of others.

![The Emit Haptic Feedback action – an integrated asset with a preset pattern](https://scenery.app/docs/assets/emit-haptic-feedback.CzRbyXbA.jpg)
*The Emit Haptic Feedback action.*

Set Ambient Audio is scene-wide and object-independent; Play Audio is object-emitted with a spatial / non-spatial / ambient input mode.

---

Source page: Video

Source URL: https://scenery.app/docs/editor/actions/video.md

# Video

Documentation source: [Video](https://scenery.app/docs/editor/actions/video.md).

Actions for controlling video playback on an object. (For how actions are added, see [Actions](https://scenery.app/docs/editor/actions).)

## Toggle Video Playback

Documentation source: [Video](https://scenery.app/docs/editor/actions/video.md).

Plays or pauses a video on an object.

**Options**

* **Target Object** – the object whose video to control.
* **Mode** – **Enable playback** (play), **Disable playback** (pause), or **Automatically** (toggle to the opposite of the current state).

## Seek Video

Documentation source: [Video](https://scenery.app/docs/editor/actions/video.md).

Jumps a video to a specific point – useful for branching or non-linear video, where a user's choice jumps to a different part of one file.

**Options**

* **Target Object**.
* **Timestamp** – where to jump to.

---

Source page: Physics

Source URL: https://scenery.app/docs/editor/actions/physics.md

# Physics

Documentation source: [Physics](https://scenery.app/docs/editor/actions/physics.md).

Actions that push, spin, and reset objects under physics simulation. (For how actions are added, see [Actions](https://scenery.app/docs/editor/actions).)

::: tip Set up physics first
Physics needs a few things in place before these actions do anything:

* In **Scene settings → Meshing**, enable the **floor mesh** (so objects don't fall through the floor), and **world meshing** if objects should interact with the real environment (LiDAR devices only).
* In **Scene settings → Physics**, enable **scene mesh collisions** (so objects react to that mesh), and adjust **gravity** if needed.
* On each object, enable **physics** in its **Properties**, and pick the right **collision shape** (sphere, box, or convex).
  :::

## Apply Impulse

Documentation source: [Physics](https://scenery.app/docs/editor/actions/physics.md).

Pushes an object with a one-off force.

**Options**

* **Target Object**.
* **Impulse position** – a fixed **point**, or the **user interaction** point.
* **Reference space** – the coordinate frame for the impulse: **Local** (the object's own orientation), **World** (absolute scene axes), or **Point of View** (relative to the camera).
* **Impulse** – the force along each axis (X, Y, Z), in newton-seconds.

![The Apply Impulse action – target, impulse position, reference space, and per-axis impulse](https://scenery.app/docs/assets/apply-impulse.DbTsM3DH.jpg)
*The Apply Impulse action.*

## Apply Angular Impulse

Documentation source: [Physics](https://scenery.app/docs/editor/actions/physics.md).

Like Apply Impulse, but **rotational** – makes the object spin. Same target, reference space, and per-axis impulse.

![The Apply Angular Impulse action – the rotational equivalent, with reference space and per-axis impulse](https://scenery.app/docs/assets/apply-angular-impulse.DpzjEN2Y.jpg)
*The Apply Angular Impulse action.*

## Reset Element Physics

Documentation source: [Physics](https://scenery.app/docs/editor/actions/physics.md).

Resets one object's physics state (position and motion).

## Reset Scene Physics

Documentation source: [Physics](https://scenery.app/docs/editor/actions/physics.md).

Resets the physics state of the whole scene – handy for switching between physics "states" (e.g. normal gravity vs. moon gravity) on demand.

The body physics mechanics these actions drive are explained under [Asset Properties → Physics](https://scenery.app/docs/editor/asset-properties#physics).

---

Source page: Experience

Source URL: https://scenery.app/docs/editor/actions/experience.md

# Experience

Documentation source: [Experience](https://scenery.app/docs/editor/actions/experience.md).

Actions that affect the whole experience, not a single object. (For how actions are added, see [Actions](https://scenery.app/docs/editor/actions).)

## Transition to Scene

Documentation source: [Experience](https://scenery.app/docs/editor/actions/experience.md).

Moves to another **scene** in the experience. Each scene keeps the experience's anchoring but is its own canvas, with its own content and events (see [Scenes](https://scenery.app/docs/editor/overview#scenes)).

**Options**

* **Scene** – which scene to transition to.

## Set Post-Processing Effect

Documentation source: [Experience](https://scenery.app/docs/editor/actions/experience.md).

Applies (or clears) a **post-processing effect** on the camera view – both shader effects and filters. Default is none. Create effects in the **Post-FX** section first, then select one here.

Because it's dynamic, you can change the whole visual style on user input – e.g. switch to a black-and-white filter when the user picks a "1920s" object.

## Set Surroundings Effect

Documentation source: [Experience](https://scenery.app/docs/editor/actions/experience.md).

Dims or tints the user's real surroundings.

::: warning Platform support
Set Surroundings Effect works on **Apple Vision Pro** only.
:::

**Options**

* **Effect** – not applied, semi-dark, dark, ultra-dark, a **custom dimming** value, or a **custom colour tint**.

Great for focus and mood – darken the room when the user picks up an object, or tint the space to match a video that's playing.

## Set Immersion Mode

Documentation source: [Experience](https://scenery.app/docs/editor/actions/experience.md).

Changes how much the experience replaces the real world, mid-experience – so you can switch immersion on user input, such as a button that takes the viewer from their room into a fully virtual space.

**Options**

* **Immersion Mode** – **Mixed** keeps the real world visible with content overlaid, **Full** replaces it with the virtual environment, and **Progressive** lets the viewer adjust the amount in between (on Apple Vision Pro, using the Digital Crown).
* **Progressive Immersion Range** – for Progressive, the minimum, maximum, and starting immersion level, as a percentage. *(currently Apple Vision Pro only)*

On iPhone and iPad, Full and Progressive both show the virtual environment (with AR tracking still active), while Mixed shows the camera.

## Open Link

Documentation source: [Experience](https://scenery.app/docs/editor/actions/experience.md).

Opens an external link in the browser.

**Options**

* **Link name** and **URL** (https).
* **Open in system browser**.
* A confirmation prompt that asks the user before leaving the experience (can be turned off).

## Pause Experience

Documentation source: [Experience](https://scenery.app/docs/editor/actions/experience.md).

Opens the pause menu. No options. Useful with custom UIs when you want full control over when the experience pauses.

## End Experience

Documentation source: [Experience](https://scenery.app/docs/editor/actions/experience.md).

Ends the experience (the user can't resume where they left off). On Agency / Enterprise plans you can also add an **outro text** and a **call-to-action button** (title + URL), which Scenery turns into a simple end screen – a way to send people somewhere after the experience.

---

Source page: Dynamic Scene Adjustments

Source URL: https://scenery.app/docs/editor/actions/dynamic-scene-adjustments.md

# Dynamic Scene Adjustments

Documentation source: [Dynamic Scene Adjustments](https://scenery.app/docs/editor/actions/dynamic-scene-adjustments.md).

Actions for firing reusable events and toggling interactivity. (For how actions are added, see [Actions](https://scenery.app/docs/editor/actions).)

## Trigger Custom Event

Documentation source: [Dynamic Scene Adjustments](https://scenery.app/docs/editor/actions/dynamic-scene-adjustments.md).

Fires a **custom event** – a reusable bundle of actions you define once (as a scene event with a **Custom** trigger) and trigger from many places. Build complex logic (including scripts) once, then re-run it from any number of triggers instead of rebuilding it each time.

**Options**

* **Event** – the custom event to fire. (Define it first under scene events; see [Events & triggers](https://scenery.app/docs/editor/triggers).)

## Toggle Events

Documentation source: [Dynamic Scene Adjustments](https://scenery.app/docs/editor/actions/dynamic-scene-adjustments.md).

Enables or disables other events on the fly – the mechanism behind on/off interaction cycles (tap to show, then disable that event and enable its opposite). See [Event options](https://scenery.app/docs/editor/triggers#event-options).

**Options**

* **Event(s)** to toggle, and whether to **enable** or **disable**.

## Toggle Object Gestures

Documentation source: [Dynamic Scene Adjustments](https://scenery.app/docs/editor/actions/dynamic-scene-adjustments.md).

Enables or disables an object's **drag / rotate / resize** gestures (set up in the object's [Properties → Gestures](https://scenery.app/docs/editor/asset-properties#gestures)). Reversible – you can turn them back on later.

## End Object Gestures

Documentation source: [Dynamic Scene Adjustments](https://scenery.app/docs/editor/actions/dynamic-scene-adjustments.md).

Cancels an object's gestures, **including one already in progress**. Unlike Toggle Object Gestures, this is one-way – it can't re-enable them.

## Cancel Scheduled Actions

Documentation source: [Dynamic Scene Adjustments](https://scenery.app/docs/editor/actions/dynamic-scene-adjustments.md).

Cancels all actions that are currently waiting or scheduled – a way to tidy up or stop a chain of interactivity when the story moves on.

---

Source page: Developer

Source URL: https://scenery.app/docs/editor/actions/developer.md

# Developer

Documentation source: [Developer](https://scenery.app/docs/editor/actions/developer.md).

Actions for debugging and scripting.

::: info Scripting is part of the Pro plan
**Run Script** and the scripting triggers ([On Experience Load, On Render, Custom](https://scenery.app/docs/editor/triggers#scene-triggers)) are part of the **Pro** plan and up. On a free account they are marked Pro and open the plan offer. The Scripting API itself is still in beta, so APIs may change between releases.
:::

## Show Debug Message

Documentation source: [Developer](https://scenery.app/docs/editor/actions/developer.md).

Shows a short message **during creation and preview** (not to end users) when the action fires. Handy for troubleshooting – you can see exactly when a particular point in a long chain of actions was reached.

**Options**

* **Message** – the text to show (supports variable interpolation).

## Run Script

Documentation source: [Developer](https://scenery.app/docs/editor/actions/developer.md).

Runs a custom **JavaScript** snippet. The editor includes a code editor with autocompletion. Scripting extends an experience beyond the no-code actions – start no-code, then take it further yourself or with developers.

See the [Scripting](https://scenery.app/docs/scripting/) documentation to learn the API.

