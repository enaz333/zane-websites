# Knowledge Map and Routing

Purpose: help complete beginners implement their own Scenery idea and get unstuck fast during a hackathon. Technical assistance takes priority over concept/design advice.

Snapshot: November 5, 2026. All 114 pages in the official published index are retained exactly once across the official topic files. This is a dated snapshot, not a live product specification.

## Evidence types

Files 01, 02, 04, 05, 06, 08, 10, 12–16 contain official text; their added search labels and source links are organizational aids. Files 03, 07, 09, 11 are authored support aids, explicitly grounded in linked official sources. Recipes are proposed compositions, not tested Scenery templates or proof of runtime behavior. This map is routing guidance. Historical release notes do not override current feature references without corroboration.

## Symptom and task routing

| Participant says | First file | Follow-up reference |
|---|---|---|
| I know what I want, how do I build it? | 03 | 01, 02, 04 |
| What should our project be about? | 09: mentor escalation | Do not choose the team's concept |
| I cannot create or find a control | 01 | 06, 10 |
| Poster, image marker, drifting, wrong placement | 02 | 09, 11 |
| Tap, animation, button, score, HUD, text, no response | 04 | 11, then 08 if code is necessary |
| Model/import/video/audio/lag | 05 | 10 best practices, 11 |
| QR/link/App Clip/Android/browser/device | 06 | 10, 11 |
| Face effect, blink, eyes, hands or body tracking | 07 | 02, 06, 04 |
| Script fails or advanced logic is requested | 08 | Exact API in 12–15 |
| I do not know what is broken | 09 | 11, then implicated official file |
| Feature missing/locked, plan, settings, secret | 10 | Feature page, 06, 16 |
| Repeat/toggle/null/black-video/Safari pitfalls | 11 | Linked feature source |
| Bugs, FAQ, latest change? | 16 | Date-check and escalate if current behavior is unknown |

## Exact filenames

- 00_Knowledge_Map_and_Routing.md
- 01_Getting_Started_and_Editor_Workflow.md
- 02_Experience_Types_Anchors_and_Tracking.md
- 03_Build_Recipes_and_MVP_Translation.md
- 04_Events_Animation_and_Interaction_Logic.md
- 05_Assets_Media_and_Performance.md
- 06_Sharing_Testing_and_Device_Differences.md
- 07_Face_Tracking_and_Special_Cases.md
- 08_Scripting_and_Advanced_Logic.md
- 09_Troubleshooting_Scope_and_Escalation.md
- 10_Product_Requirements_Settings_and_Limits.md
- 11_Documented_Pitfalls_and_Support_Checks.md
- 12_API_Math_and_Geometry.md
- 13_API_Scene_Entities_and_Environment.md
- 14_API_Creation_Materials_and_GPU.md
- 15_API_UI_Audio_Networking_and_Animation.md
- 16_FAQ_and_Release_History.md

## Complete source mapping

| Official page | File | Source |
|---|---|---|
| Guide | 01_Getting_Started_and_Editor_Workflow.md | https://scenery.app/docs/guide.md |
| What Is Scenery? | 01_Getting_Started_and_Editor_Workflow.md | https://scenery.app/docs/guide/what-is-scenery.md |
| What Makes It Different | 01_Getting_Started_and_Editor_Workflow.md | https://scenery.app/docs/guide/what-makes-different.md |
| Create Your First Experience | 01_Getting_Started_and_Editor_Workflow.md | https://scenery.app/docs/guide/first-experience.md |
| Experience Library | 01_Getting_Started_and_Editor_Workflow.md | https://scenery.app/docs/guide/discover.md |
| Asset Library & Folders | 01_Getting_Started_and_Editor_Workflow.md | https://scenery.app/docs/guide/asset-library.md |
| Settings & Account | 01_Getting_Started_and_Editor_Workflow.md | https://scenery.app/docs/guide/settings.md |
| Best Practices | 10_Product_Requirements_Settings_and_Limits.md | https://scenery.app/docs/guide/best-practices.md |
| Transparent Video | 05_Assets_Media_and_Performance.md | https://scenery.app/docs/guide/transparent-video.md |
| Compatibility | 06_Sharing_Testing_and_Device_Differences.md | https://scenery.app/docs/guide/compatibility.md |
| Publishing & Sharing | 06_Sharing_Testing_and_Device_Differences.md | https://scenery.app/docs/guide/publishing.md |
| Keyboard Shortcuts | 01_Getting_Started_and_Editor_Workflow.md | https://scenery.app/docs/guide/keyboard-shortcuts.md |
| Changelog | 16_FAQ_and_Release_History.md | https://scenery.app/docs/guide/changelog.md |
| FAQ | 16_FAQ_and_Release_History.md | https://scenery.app/docs/guide/faq.md |
| Editor Overview | 01_Getting_Started_and_Editor_Workflow.md | https://scenery.app/docs/editor/overview.md |
| Experiences, Scenes & Objects | 01_Getting_Started_and_Editor_Workflow.md | https://scenery.app/docs/editor/concepts.md |
| Tracking Contexts | 02_Experience_Types_Anchors_and_Tracking.md | https://scenery.app/docs/editor/tracking-contexts.md |
| Adding Content to a Scene | 05_Assets_Media_and_Performance.md | https://scenery.app/docs/editor/adding-content.md |
| Anchors | 02_Experience_Types_Anchors_and_Tracking.md | https://scenery.app/docs/editor/anchors.md |
| Asset Appearances | 05_Assets_Media_and_Performance.md | https://scenery.app/docs/editor/asset-appearances.md |
| Asset Properties | 05_Assets_Media_and_Performance.md | https://scenery.app/docs/editor/asset-properties.md |
| Materials | 05_Assets_Media_and_Performance.md | https://scenery.app/docs/editor/materials.md |
| Post-FX | 05_Assets_Media_and_Performance.md | https://scenery.app/docs/editor/post-fx.md |
| User Interface | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/user-interface.md |
| Panels | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/user-interface/panels.md |
| Layout & Sizing | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/user-interface/layout.md |
| Views | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/user-interface/views.md |
| Styling | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/user-interface/styling.md |
| Text & Variables | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/user-interface/text.md |
| Interaction | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/user-interface/interaction.md |
| Design Guidelines | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/user-interface/design-guidelines.md |
| Events & Triggers | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/triggers.md |
| Actions | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/actions.md |
| Scene Content | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/actions/scene-content.md |
| Action Ordering | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/actions/action-ordering.md |
| Animations & Appearance | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/actions/animations-appearance.md |
| Audio & Haptics | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/actions/audio-haptics.md |
| Video | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/actions/video.md |
| Physics | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/actions/physics.md |
| Experience | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/actions/experience.md |
| Dynamic Scene Adjustments | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/actions/dynamic-scene-adjustments.md |
| Developer | 04_Events_Animation_and_Interaction_Logic.md | https://scenery.app/docs/editor/actions/developer.md |
| Scene Settings | 10_Product_Requirements_Settings_and_Limits.md | https://scenery.app/docs/editor/scene-settings.md |
| Placement & Localization | 02_Experience_Types_Anchors_and_Tracking.md | https://scenery.app/docs/editor/placement.md |
| Experience Settings | 10_Product_Requirements_Settings_and_Limits.md | https://scenery.app/docs/editor/experience-settings.md |
| Secrets | 10_Product_Requirements_Settings_and_Limits.md | https://scenery.app/docs/editor/secrets.md |
| Environments & Lighting | 05_Assets_Media_and_Performance.md | https://scenery.app/docs/editor/environments-lighting.md |
| Scripting | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting.md |
| Getting Started | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/getting-started.md |
| The Console | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/console.md |
| Events | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/events.md |
| Vectors & Transforms | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/vectors-transforms.md |
| Gestures & Interactions | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/gestures.md |
| User Interface | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/user-interface.md |
| Materials | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/materials.md |
| Mesh Instancing | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/instancing.md |
| Gaussian Splats | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/splats.md |
| Paths & Splines | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/paths.md |
| Location | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/location.md |
| Tracking | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/tracking.md |
| Compute Kernels | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/compute.md |
| Feature detection | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/feature-detection.md |
| Examples | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/examples.md |
| Changelog | 16_FAQ_and_Release_History.md | https://scenery.app/docs/scripting/guide/changelog.md |
| Migration Guide | 08_Scripting_and_Advanced_Logic.md | https://scenery.app/docs/scripting/guide/migration.md |
| API Reference | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api.md |
| Vector2 | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api/vector2.md |
| Vector3 | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api/vector3.md |
| Vector4 | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api/vector4.md |
| Rotation | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api/rotation.md |
| Transform | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api/transform.md |
| BoundingBox | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api/boundingbox.md |
| Ray | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api/ray.md |
| Color | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api/color.md |
| Path beta | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api/path.md |
| GeoCoordinate beta | 12_API_Math_and_Geometry.md | https://scenery.app/docs/scripting/api/geocoordinate.md |
| Scene | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/scene.md |
| ObjectEntity | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/objectentity.md |
| RepresentationEntity | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/representationentity.md |
| Entity | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/entity.md |
| Experience | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/experience.md |
| Environment | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/environment.md |
| EnvironmentFeatures | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/environmentfeatures.md |
| Location beta | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/location.md |
| AnchorData | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/anchordata.md |
| CollisionCastHit | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/collisioncasthit.md |
| ARRaycastResult | 13_API_Scene_Entities_and_Environment.md | https://scenery.app/docs/scripting/api/arraycastresult.md |
| Kernel beta | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/kernel.md |
| Texture beta | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/texture.md |
| TextureBinding | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/texturebinding.md |
| Buffer beta | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/buffer.md |
| EngineBufferBinding | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/enginebufferbinding.md |
| Splat | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/splat.md |
| SplatAttribute | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/splatattribute.md |
| InstanceData | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/instancedata.md |
| Light | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/light.md |
| UIView beta | 15_API_UI_Audio_Networking_and_Animation.md | https://scenery.app/docs/scripting/api/uiview.md |
| Anchor | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/anchor.md |
| ObjectTraits | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/objecttraits.md |
| ObjectDescriptor | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/objectdescriptor.md |
| Material | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/material.md |
| Mesh beta | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/mesh.md |
| Instances beta | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/instances.md |
| Global Functions | 14_API_Creation_Materials_and_GPU.md | https://scenery.app/docs/scripting/api/functions.md |
| AudioStream | 15_API_UI_Audio_Networking_and_Animation.md | https://scenery.app/docs/scripting/api/audiostream.md |
| Microphone | 15_API_UI_Audio_Networking_and_Animation.md | https://scenery.app/docs/scripting/api/microphone.md |
| HTTPClient | 15_API_UI_Audio_Networking_and_Animation.md | https://scenery.app/docs/scripting/api/httpclient.md |
| WebSocket | 15_API_UI_Audio_Networking_and_Animation.md | https://scenery.app/docs/scripting/api/websocket.md |
| WebSocketManager | 15_API_UI_Audio_Networking_and_Animation.md | https://scenery.app/docs/scripting/api/websocketmanager.md |
| SecretsClient | 15_API_UI_Audio_Networking_and_Animation.md | https://scenery.app/docs/scripting/api/secretsclient.md |
| EntityAnimation | 15_API_UI_Audio_Networking_and_Animation.md | https://scenery.app/docs/scripting/api/entityanimation.md |
| ValueAnimation | 15_API_UI_Audio_Networking_and_Animation.md | https://scenery.app/docs/scripting/api/valueanimation.md |
| SharedActivity | 15_API_UI_Audio_Networking_and_Animation.md | https://scenery.app/docs/scripting/api/sharedactivity.md |
| Scenery on the Web (WebXR) | 06_Sharing_Testing_and_Device_Differences.md | https://scenery.app/docs/webxr.md |
