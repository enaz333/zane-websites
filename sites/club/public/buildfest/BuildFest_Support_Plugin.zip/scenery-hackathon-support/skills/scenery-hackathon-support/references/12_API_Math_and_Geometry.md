# API Math and Geometry

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: Vector; radians; rotation; coordinate; transform; math; color.

Audience: advanced reference. Retrieve only when code is necessary or explicitly requested. Start with the guides in 08 before using API signatures.

## Contents

- API Reference
- Vector2
- Vector3
- Vector4
- Rotation
- Transform
- BoundingBox
- Ray
- Color
- Path beta
- GeoCoordinate beta

---

Source page: API Reference

Source URL: https://scenery.app/docs/scripting/api.md

# API Reference

Documentation source: [API Reference](https://scenery.app/docs/scripting/api.md).

JavaScript API for creating AR experiences.

## Math & Geometry

Documentation source: [API Reference](https://scenery.app/docs/scripting/api.md).

* [Vector2](https://scenery.app/docs/scripting/api/vector2) - 2D vector for screen coordinates, UV mapping, and 2D math
* [Vector3](https://scenery.app/docs/scripting/api/vector3) - 3D vector for positions, directions, and scales
* [Vector4](https://scenery.app/docs/scripting/api/vector4) - 4D vector for quaternions, colors, and homogeneous coordinates
* [Rotation](https://scenery.app/docs/scripting/api/rotation) - Rotation represented as a quaternion
* [Transform](https://scenery.app/docs/scripting/api/transform) - 4x4 transformation matrix representing position, rotation, and scale
* [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox) - Axis-aligned bounding box for collision and visibility testing
* [Ray](https://scenery.app/docs/scripting/api/ray) - A ray with origin and direction, useful for raycasting
* [Color](https://scenery.app/docs/scripting/api/color) - RGBA color with components in 0-1 range
* [Path](https://scenery.app/docs/scripting/api/path) beta - Runtime path handle returned by `scene.createPath(...)`. Read-only spline queries; consumed by `entity.followPath(...)`. Not persisted (v1).
* [GeoCoordinate](https://scenery.app/docs/scripting/api/geocoordinate) beta - A geographic coordinate. Construct one for a point of interest, or receive a live fix from `environment.location.current()` (which additionally populates `horizontalAccuracy` and `timestamp`).

## Scene & Objects

Documentation source: [API Reference](https://scenery.app/docs/scripting/api.md).

* [Scene](https://scenery.app/docs/scripting/api/scene)
* [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity) - Entity in the scene
* [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity) - Visual representation of an entity (model, shape, etc.)
* [Entity](https://scenery.app/docs/scripting/api/entity) - Generic entity within a model hierarchy (bones, groups, nested models)
* [Experience](https://scenery.app/docs/scripting/api/experience)
* [Environment](https://scenery.app/docs/scripting/api/environment)
* [EnvironmentFeatures](https://scenery.app/docs/scripting/api/environmentfeatures) - Capability registry exposed at `environment.features`.
* [Location](https://scenery.app/docs/scripting/api/location) beta - The user's device location, exposed to scripting as `environment.location`. Coarse reads ride the base grant; precise accuracy is an explicit opt-in.
* [AnchorData](https://scenery.app/docs/scripting/api/anchordata)
* [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit) - Result from scene.raycast() when ray intersects an entity or scene mesh
* [ARRaycastResult](https://scenery.app/docs/scripting/api/arraycastresult) - Result from scene.raycastAR() when ray intersects real-world surfaces
* [Kernel](https://scenery.app/docs/scripting/api/kernel) beta - Opaque handle to a compiled GPU compute kernel. Returned by `Kernel.fromSource(...)` / `Kernel.fromAsset(...)`. Two dispatch entry points: `kernel.run({...})` for standalone compute (texture / buffer I/O, no mesh involvement) and `mesh.runCompute(kernel, options)` when the kernel writes mesh-attribute buffers.
* [Texture](https://scenery.app/docs/scripting/api/texture) beta - A GPU texture created and managed at runtime. Construct one from an image or video source (`Texture.image(...)`, `Texture.video(...)`), the live camera feed (`Texture.cameraFeed()`), or a compute kernel that writes its pixels (`Texture.compute(...)`).
* [TextureBinding](https://scenery.app/docs/scripting/api/texturebinding) - Marker token returned by `texture.read` / `texture.write`. Carries the backing texture and the role so dispatch knows whether to bind the texture as a kernel read source or write target.
* [Buffer](https://scenery.app/docs/scripting/api/buffer) beta - Raw GPU buffer wrapping a typed scratch region for compute kernels. Use for things meshes + textures don't model: atomic counters, lookup tables (e.g. marching cubes' triangle / edge tables), per-particle state, scratch arrays between kernel passes.
* [EngineBufferBinding](https://scenery.app/docs/scripting/api/enginebufferbinding) - Marker token for a GPU buffer the engine owns and renders from, as opposed to the scratch regions a script's own `Buffer` allocates. Mirrors `TextureBinding`: a role plus a way back to the memory, resolved at dispatch.
* [Splat](https://scenery.app/docs/scripting/api/splat) - The GPU buffers behind a Gaussian splat, for handing to a compute kernel.
* [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute) - One attribute's GPU buffer, as a pair of kernel bindings.
* [InstanceData](https://scenery.app/docs/scripting/api/instancedata) - The GPU buffer behind an entity's mesh instances, for handing to a compute kernel.
* [Light](https://scenery.app/docs/scripting/api/light) - A light in the running scene.

## User Interface

Documentation source: [API Reference](https://scenery.app/docs/scripting/api.md).

* [UIView](https://scenery.app/docs/scripting/api/uiview) beta - A view node inside a UI panel.

## Object Creation

Documentation source: [API Reference](https://scenery.app/docs/scripting/api.md).

* [Anchor](https://scenery.app/docs/scripting/api/anchor) - Anchor types for object placement
* [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits) - Builder object passed to the compatibility-only `.traits(t => …)` callback. New code should skip this entirely and use the direct descriptor methods (`.physics(…)`, `.material(…)`, `.shadow(…)`, `.gestures(…)`, `.transform(…)`, `.opacity(…)`, `.fittingBox(…)`, `.pivot(…)`, `.revealAnimation(…)`, `.removalAnimation(…)`, `.hideByDefault(…)`, `.flatten(…)`), which expose the same configuration and chain.
* [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor) - Descriptor for creating scene objects dynamically
* [Material](https://scenery.app/docs/scripting/api/material) - Chainable builder for an inline material. Six kinds: `unlit`, `pbr`, `occlusion`, `customShader`, `materialX`, `video`. Use the matching factory (`Material.unlit({...})`, etc.) or `new Material(kind)`.

Properties map to the underlying material data model with web-standard names: - Colors: `color`, `emissive`, `sheenColor`, `specularColor` – flat tint. - Maps: `map`, `emissiveMap`, `roughnessMap`, `metalnessMap`, `normalMap`, `aoMap`, `specularMap`, `sheenMap`, `clearcoatMap`, `alphaMap` – textures accept either a URL/asset-id string or `{ texture, scale }`. - Scalars: `roughness`, `metalness`, `clearcoat`, `opacity`, `emissiveIntensity`. - Rendering: `opaque`, `transparent`, `opacityThreshold`, `blendMode`, `faceCulling`, `wireframe`, `writesDepth`, `readsDepth`.

* [Mesh](https://scenery.app/docs/scripting/api/mesh) beta - Scriptable dynamic mesh with CPU-driven vertex and index updates.
* [Instances](https://scenery.app/docs/scripting/api/instances) beta - Instance-data handles for `rep.setInstances(...)` / `entity.setInstances(...)` – GPU mesh instancing draws one copy of a mesh per transform, far cheaper than real entities. Instances are rendering-only (no physics, collision, or per-instance identity); use `clone()` for objects the user interacts with. Gate with `environment.features.has('instancing')`.

## Audio

Documentation source: [API Reference](https://scenery.app/docs/scripting/api.md).

* [AudioStream](https://scenery.app/docs/scripting/api/audiostream) - Streaming audio player for real-time audio playback Used for continuous audio streams like OpenAI Realtime API
* [Microphone](https://scenery.app/docs/scripting/api/microphone) - Microphone audio streaming Access via `scene.microphone`

## Networking

Documentation source: [API Reference](https://scenery.app/docs/scripting/api.md).

* [HTTPClient](https://scenery.app/docs/scripting/api/httpclient) - HTTP client for making network requests Supports GET, POST, and custom requests with authentication
* [WebSocket](https://scenery.app/docs/scripting/api/websocket) - WebSocket connection for real-time communication
* [WebSocketManager](https://scenery.app/docs/scripting/api/websocketmanager) - WebSocket connection manager Access via `websocket.connect()`
* [SecretsClient](https://scenery.app/docs/scripting/api/secretsclient) - Mints short-lived credentials for the vendors that issue them.

## Animations

Documentation source: [API Reference](https://scenery.app/docs/scripting/api.md).

* [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation) - Entity animation factory - create animation descriptors for use with entity.play()
* [ValueAnimation](https://scenery.app/docs/scripting/api/valueanimation) - Value animations with spring and curve timing

## Multi-user

Documentation source: [API Reference](https://scenery.app/docs/scripting/api.md).

* [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity) - Shared activity state for multi-user sessions (SharePlay, WebSocket, etc.)

## Functions

Documentation source: [API Reference](https://scenery.app/docs/scripting/api.md).

* [wait()](https://scenery.app/docs/scripting/api/functions#wait) - Wait for specified seconds
* [animateValue()](https://scenery.app/docs/scripting/api/functions#animatevalue) - Create and start a value animation

Automatically interpolates between from/to values based on their type. Supports numbers, Vector2, Vector3, Vector4, Color, and Rotation. Rotations use spherical interpolation (slerp) automatically.

Animations clean up automatically when complete. For infinite animations, call destroy() to stop, or they clean up when the scene ends.

* [createBox()](https://scenery.app/docs/scripting/api/functions#createbox) - Create a box primitive descriptor
* [createSphere()](https://scenery.app/docs/scripting/api/functions#createsphere) - Create a sphere primitive
* [createPlane()](https://scenery.app/docs/scripting/api/functions#createplane) - Create a plane primitive
* [createModel()](https://scenery.app/docs/scripting/api/functions#createmodel) - Create a 3D model object descriptor
* [createSplat()](https://scenery.app/docs/scripting/api/functions#createsplat-beta) beta - Create a Gaussian splat capture object descriptor
* [createMedia()](https://scenery.app/docs/scripting/api/functions#createmedia) - Create a visual media object (image, video, or animated GIF)
* [createImage()](https://scenery.app/docs/scripting/api/functions#createimage) - Create an image
* [createVideo()](https://scenery.app/docs/scripting/api/functions#createvideo) - Create a video
* [createAnimatedGif()](https://scenery.app/docs/scripting/api/functions#createanimatedgif) - Create an animated GIF
* [createContainer()](https://scenery.app/docs/scripting/api/functions#createcontainer) - Create a container/composition
* [createPanel()](https://scenery.app/docs/scripting/api/functions#createpanel-beta) beta - Build a UI panel descriptor wrapping the given root view. Pass to `scene.createEntity(panel)` to instantiate.
* [createMesh()](https://scenery.app/docs/scripting/api/functions#createmesh-beta) beta - Create a scriptable dynamic mesh with CPU-driven vertex/index updates.

Returns an ObjectDescriptor – pass to `scene.createEntity(...)`. After the entity loads, reach the mesh via `entity.representation.mesh` and write buffer data with `mesh.writeVertices(...)` / `mesh.writeIndices(...)`. Bytes flow straight from `Float32Array` / `Uint32Array` into the GPU-side buffer – single memcpy per call, no per-element overhead.

* [createSpotLight()](https://scenery.app/docs/scripting/api/functions#createspotlight) - Create a spot light – a cone of light aimed along the object's forward axis.

Rotation aims it; position places it. Intensity is in lumens.

* [createPointLight()](https://scenery.app/docs/scripting/api/functions#createpointlight) - Create a point light – light radiating equally in every direction.

Only its position matters; rotation does nothing. Intensity is in lumens, and a point light cannot cast shadows.

* [createDirectionalLight()](https://scenery.app/docs/scripting/api/functions#createdirectionallight) - Create a directional light – a sun, shining from infinitely far away.

Only its rotation matters; position moves nothing but the editor's marker. Intensity is in lux rather than lumens, so the numbers are not comparable with the other two types.

---

Source page: Vector2

Source URL: https://scenery.app/docs/scripting/api/vector2.md

# Vector2

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

2D vector for screen coordinates, UV mapping, and 2D math

## Properties

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

### x

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

* **Type:** number
* X component

### y

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

* **Type:** number
* Y component

## Methods

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

### create()

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

```javascript
create(x: number, y: number): Vector2
```

Create a Vector2

**Parameters:**

* `x` (number) - X component
* `y` (number) - Y component

**Returns:** [Vector2](https://scenery.app/docs/scripting/api/vector2)

### distance()

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

```javascript
distance(v1: Vector2, v2: Vector2): number
```

Distance between two vectors

**Parameters:**

* `v1` ([Vector2](https://scenery.app/docs/scripting/api/vector2))
* `v2` ([Vector2](https://scenery.app/docs/scripting/api/vector2))

**Returns:** number

### dot()

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

```javascript
dot(v1: Vector2, v2: Vector2): number
```

Dot product of two vectors

**Parameters:**

* `v1` ([Vector2](https://scenery.app/docs/scripting/api/vector2))
* `v2` ([Vector2](https://scenery.app/docs/scripting/api/vector2))

**Returns:** number

### length()

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

```javascript
length(v: Vector2): number
```

Length of a vector

**Parameters:**

* `v` ([Vector2](https://scenery.app/docs/scripting/api/vector2))

**Returns:** number

### lerp()

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

```javascript
lerp(v1: Vector2, v2: Vector2, t: number): Vector2
```

Linearly interpolate between two vectors

**Parameters:**

* `v1` ([Vector2](https://scenery.app/docs/scripting/api/vector2)) - Start vector
* `v2` ([Vector2](https://scenery.app/docs/scripting/api/vector2)) - End vector
* `t` (number) - Interpolation factor (0-1)

**Returns:** [Vector2](https://scenery.app/docs/scripting/api/vector2)

### normalize()

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

```javascript
normalize(v: Vector2): Vector2
```

Normalize a vector (unit length)

**Parameters:**

* `v` ([Vector2](https://scenery.app/docs/scripting/api/vector2))

**Returns:** [Vector2](https://scenery.app/docs/scripting/api/vector2)

### one()

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

```javascript
one(): Vector2
```

One vector (1, 1)

**Returns:** [Vector2](https://scenery.app/docs/scripting/api/vector2)

### zero()

Documentation source: [Vector2](https://scenery.app/docs/scripting/api/vector2.md).

```javascript
zero(): Vector2
```

Zero vector (0, 0)

**Returns:** [Vector2](https://scenery.app/docs/scripting/api/vector2)

---

Source page: Vector3

Source URL: https://scenery.app/docs/scripting/api/vector3.md

# Vector3

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

3D vector for positions, directions, and scales

## Properties

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

### x

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

* **Type:** number
* X component

### y

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

* **Type:** number
* Y component

### z

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

* **Type:** number
* Z component

## Methods

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

### add()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
add(other: Vector3): Vector3
```

Add two vectors

**Parameters:**

* `other` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Vector to add

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### angleBetween()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
angleBetween(v1: Vector3, v2: Vector3): number
```

Angle between two vectors in radians

**Parameters:**

* `v1` ([Vector3](https://scenery.app/docs/scripting/api/vector3))
* `v2` ([Vector3](https://scenery.app/docs/scripting/api/vector3))

**Returns:** number

### angleTo()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
angleTo(other: Vector3): number
```

Calculate angle to another vector

**Parameters:**

* `other` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Other vector

**Returns:** number

### create()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
create(x: number, y: number, z: number): Vector3
```

Create a Vector3

**Parameters:**

* `x` (number) - X component
* `y` (number) - Y component
* `z` (number) - Z component

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### cross()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
cross(v1: Vector3, v2: Vector3): Vector3
```

Cross product of two vectors

**Parameters:**

* `v1` ([Vector3](https://scenery.app/docs/scripting/api/vector3))
* `v2` ([Vector3](https://scenery.app/docs/scripting/api/vector3))

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### cross()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
cross(other: Vector3): Vector3
```

Calculate cross product with another vector

**Parameters:**

* `other` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Other vector

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### distance()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
distance(v1: Vector3, v2: Vector3): number
```

Distance between two vectors

**Parameters:**

* `v1` ([Vector3](https://scenery.app/docs/scripting/api/vector3))
* `v2` ([Vector3](https://scenery.app/docs/scripting/api/vector3))

**Returns:** number

### distanceTo()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
distanceTo(other: Vector3): number
```

Calculate distance to another vector

**Parameters:**

* `other` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Other vector

**Returns:** number

### divide()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
divide(scalar: number): Vector3
```

Divide vector by scalar

**Parameters:**

* `scalar` (number) - Scalar value

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### dot()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
dot(v1: Vector3, v2: Vector3): number
```

Dot product of two vectors

**Parameters:**

* `v1` ([Vector3](https://scenery.app/docs/scripting/api/vector3))
* `v2` ([Vector3](https://scenery.app/docs/scripting/api/vector3))

**Returns:** number

### dot()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
dot(other: Vector3): number
```

Calculate dot product with another vector

**Parameters:**

* `other` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Other vector

**Returns:** number

### length()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
length(v: Vector3): number
```

Length of a vector

**Parameters:**

* `v` ([Vector3](https://scenery.app/docs/scripting/api/vector3))

**Returns:** number

### length()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
length(): number
```

Get length of vector

**Returns:** number

### lerp()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
lerp(v1: Vector3, v2: Vector3, t: number): Vector3
```

Linearly interpolate between two vectors

**Parameters:**

* `v1` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Start vector
* `v2` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - End vector
* `t` (number) - Interpolation factor (0-1)

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### lerp()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
lerp(other: Vector3, t: number): Vector3
```

Linearly interpolate to another vector

**Parameters:**

* `other` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Target vector
* `t` (number) - Interpolation factor (0-1)

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### multiply()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
multiply(scalar: number): Vector3
```

Multiply vector by scalar

**Parameters:**

* `scalar` (number) - Scalar value

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### normalize()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
normalize(v: Vector3): Vector3
```

Normalize a vector (unit length)

**Parameters:**

* `v` ([Vector3](https://scenery.app/docs/scripting/api/vector3))

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### normalize()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
normalize(): Vector3
```

Get normalized vector

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### one()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
one(): Vector3
```

One vector (1, 1, 1)

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### subtract()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
subtract(other: Vector3): Vector3
```

Subtract a vector from this vector

**Parameters:**

* `other` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Vector to subtract

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### zero()

Documentation source: [Vector3](https://scenery.app/docs/scripting/api/vector3.md).

```javascript
zero(): Vector3
```

Zero vector (0, 0, 0)

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

---

Source page: Vector4

Source URL: https://scenery.app/docs/scripting/api/vector4.md

# Vector4

Documentation source: [Vector4](https://scenery.app/docs/scripting/api/vector4.md).

4D vector for quaternions, colors, and homogeneous coordinates

## Properties

Documentation source: [Vector4](https://scenery.app/docs/scripting/api/vector4.md).

### w

Documentation source: [Vector4](https://scenery.app/docs/scripting/api/vector4.md).

* **Type:** number
* W component

### x

Documentation source: [Vector4](https://scenery.app/docs/scripting/api/vector4.md).

* **Type:** number
* X component

### y

Documentation source: [Vector4](https://scenery.app/docs/scripting/api/vector4.md).

* **Type:** number
* Y component

### z

Documentation source: [Vector4](https://scenery.app/docs/scripting/api/vector4.md).

* **Type:** number
* Z component

## Methods

Documentation source: [Vector4](https://scenery.app/docs/scripting/api/vector4.md).

### create()

Documentation source: [Vector4](https://scenery.app/docs/scripting/api/vector4.md).

```javascript
create(x: number, y: number, z: number, w: number): Vector4
```

Create a Vector4

**Parameters:**

* `x` (number) - X component
* `y` (number) - Y component
* `z` (number) - Z component
* `w` (number) - W component

**Returns:** [Vector4](https://scenery.app/docs/scripting/api/vector4)

---

Source page: Rotation

Source URL: https://scenery.app/docs/scripting/api/rotation.md

# Rotation

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

Rotation represented as a quaternion

Can be created from euler angles or quaternion components. Use `Rotation.slerp()` for smooth interpolation between rotations.

**Example:**

```javascript
// From euler angles (radians)
var rot = Rotation(0, Math.PI / 2, 0); // 90° around Y

// From quaternion
var rot = Rotation.quaternion(0, 0.707, 0, 0.707);

// Interpolate between rotations
var mid = Rotation.slerp(rotA, rotB, 0.5);
```

## Properties

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

### eulerAngles

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Euler angles in radians (x, y, z)

### quaternion

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

* **Type:** [Vector4](https://scenery.app/docs/scripting/api/vector4)
* Quaternion components (x, y, z, w)

## Methods

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

### create()

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

```javascript
create(): Rotation
```

Create identity rotation (no rotation)

**Returns:** [Rotation](https://scenery.app/docs/scripting/api/rotation)

### inverse()

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

```javascript
inverse(r: Rotation): Rotation
```

Get the inverse (conjugate) of a rotation

**Parameters:**

* `r` ([Rotation](https://scenery.app/docs/scripting/api/rotation)) - Rotation to invert

**Returns:** [Rotation](https://scenery.app/docs/scripting/api/rotation)

### inverse()

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

```javascript
inverse(): Rotation
```

Get the inverse of this rotation

**Returns:** [Rotation](https://scenery.app/docs/scripting/api/rotation)

### multiply()

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

```javascript
multiply(r1: Rotation, r2: Rotation): Rotation
```

Multiply two rotations (compose)

**Parameters:**

* `r1` ([Rotation](https://scenery.app/docs/scripting/api/rotation)) - First rotation
* `r2` ([Rotation](https://scenery.app/docs/scripting/api/rotation)) - Second rotation (applied after r1)

**Returns:** [Rotation](https://scenery.app/docs/scripting/api/rotation)

### multiply()

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

```javascript
multiply(other: Rotation): Rotation
```

Multiply (compose) with another rotation

**Parameters:**

* `other` ([Rotation](https://scenery.app/docs/scripting/api/rotation)) - Rotation to apply after this one

**Returns:** [Rotation](https://scenery.app/docs/scripting/api/rotation)

### slerp()

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

```javascript
slerp(r1: Rotation, r2: Rotation, t: number): Rotation
```

Spherically interpolate between two rotations

**Parameters:**

* `r1` ([Rotation](https://scenery.app/docs/scripting/api/rotation)) - Start rotation
* `r2` ([Rotation](https://scenery.app/docs/scripting/api/rotation)) - End rotation
* `t` (number) - Interpolation factor (0-1)

**Returns:** [Rotation](https://scenery.app/docs/scripting/api/rotation)

### slerp()

Documentation source: [Rotation](https://scenery.app/docs/scripting/api/rotation.md).

```javascript
slerp(other: Rotation, t: number): Rotation
```

Spherically interpolate to another rotation

**Parameters:**

* `other` ([Rotation](https://scenery.app/docs/scripting/api/rotation)) - Target rotation
* `t` (number) - Interpolation factor (0-1)

**Returns:** [Rotation](https://scenery.app/docs/scripting/api/rotation)

---

Source page: Transform

Source URL: https://scenery.app/docs/scripting/api/transform.md

# Transform

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

4x4 transformation matrix representing position, rotation, and scale

**Example:**

```javascript
// Create with specific values
var t = Transform({
    position: Vector3(0, 1, 0),
    rotation: Rotation(0, Math.PI, 0),
    scale: Vector3(1, 1, 1)
});

// Get entity's transform
var worldT = entity.worldTransform;

// Combine transforms
var combined = Transform.multiply(parentT, childT);

// Transform a point
var worldPoint = Transform.transformPoint(entity.transform, localPoint);
```

## Properties

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

### position

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Position vector

### rotation

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

* **Type:** [Rotation](https://scenery.app/docs/scripting/api/rotation)
* Rotation quaternion

### scale

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Scale vector

## Methods

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

### create()

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

```javascript
create(): Transform
```

Create identity transform (position: 0,0,0, rotation: identity, scale: 1,1,1)

**Returns:** [Transform](https://scenery.app/docs/scripting/api/transform)

### createWith()

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

```javascript
createWith(position: Vector3, rotation: Rotation, scale: Vector3): Transform
```

Create transform with specific values

**Parameters:**

* `position` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Position vector
* `rotation` ([Rotation](https://scenery.app/docs/scripting/api/rotation)) - Rotation quaternion
* `scale` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Scale vector

**Returns:** [Transform](https://scenery.app/docs/scripting/api/transform)

### inverse()

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

```javascript
inverse(transform: Transform): Transform
```

Get inverse transform

**Parameters:**

* `transform` ([Transform](https://scenery.app/docs/scripting/api/transform)) - Transform to invert

**Returns:** [Transform](https://scenery.app/docs/scripting/api/transform)

### inverse()

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

```javascript
inverse(): Transform
```

Get inverse transform

**Returns:** [Transform](https://scenery.app/docs/scripting/api/transform)

### multiply()

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

```javascript
multiply(t1: Transform, t2: Transform): Transform
```

Multiply two transforms (combine transformations)

**Parameters:**

* `t1` ([Transform](https://scenery.app/docs/scripting/api/transform)) - First transform
* `t2` ([Transform](https://scenery.app/docs/scripting/api/transform)) - Second transform

**Returns:** [Transform](https://scenery.app/docs/scripting/api/transform)

### multiply()

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

```javascript
multiply(other: Transform): Transform
```

Multiply with another transform

**Parameters:**

* `other` ([Transform](https://scenery.app/docs/scripting/api/transform)) - Other transform

**Returns:** [Transform](https://scenery.app/docs/scripting/api/transform)

### transformPoint()

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

```javascript
transformPoint(transform: Transform, point: Vector3): Vector3
```

Transform a point by this matrix

**Parameters:**

* `transform` ([Transform](https://scenery.app/docs/scripting/api/transform)) - Transform to apply
* `point` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Point to transform

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### transformPoint()

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

```javascript
transformPoint(point: Vector3): Vector3
```

Transform a point

**Parameters:**

* `point` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Point to transform

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### transformVector()

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

```javascript
transformVector(transform: Transform, vector: Vector3): Vector3
```

Transform a direction vector (ignores position)

**Parameters:**

* `transform` ([Transform](https://scenery.app/docs/scripting/api/transform)) - Transform to apply
* `vector` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Direction vector

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### transformVector()

Documentation source: [Transform](https://scenery.app/docs/scripting/api/transform.md).

```javascript
transformVector(vector: Vector3): Vector3
```

Transform a vector

**Parameters:**

* `vector` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Vector to transform

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

---

Source page: BoundingBox

Source URL: https://scenery.app/docs/scripting/api/boundingbox.md

# BoundingBox

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

Axis-aligned bounding box for collision and visibility testing

**Example:**

```javascript
var box = entity.boundingBox;
var center = box.center;
var size = box.extents;

// Check if point is inside
if (BoundingBox.contains(box, point)) {
    console.log('Point inside!');
}

// Check intersection
if (BoundingBox.intersects(box1, box2)) {
    console.log('Boxes overlap!');
}
```

## Properties

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

### boundingRadius

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

* **Type:** number
* Radius of bounding sphere

### center

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Center point of the box

### extents

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Half-size extents from center

### isEmpty

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

* **Type:** boolean
* Whether the box has zero volume

### max

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Maximum corner of the box

### min

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Minimum corner of the box

## Methods

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

### contains()

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

```javascript
contains(box: BoundingBox, point: Vector3): boolean
```

Check if a point is inside the box

**Parameters:**

* `box` ([BoundingBox](https://scenery.app/docs/scripting/api/boundingbox))
* `point` ([Vector3](https://scenery.app/docs/scripting/api/vector3))

**Returns:** boolean

### contains()

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

```javascript
contains(point: Vector3): boolean
```

Check if point is inside bounding box

**Parameters:**

* `point` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Point to check

**Returns:** boolean

### containsBox()

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

```javascript
containsBox(box1: BoundingBox, box2: BoundingBox): boolean
```

Check if one box fully contains another

**Parameters:**

* `box1` ([BoundingBox](https://scenery.app/docs/scripting/api/boundingbox))
* `box2` ([BoundingBox](https://scenery.app/docs/scripting/api/boundingbox))

**Returns:** boolean

### containsBox()

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

```javascript
containsBox(other: BoundingBox): boolean
```

Check if another bounding box is fully contained

**Parameters:**

* `other` ([BoundingBox](https://scenery.app/docs/scripting/api/boundingbox)) - Other bounding box

**Returns:** boolean

### create()

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

```javascript
create(min: Vector3, max: Vector3): BoundingBox
```

Create a bounding box from min/max corners

**Parameters:**

* `min` ([Vector3](https://scenery.app/docs/scripting/api/vector3))
* `max` ([Vector3](https://scenery.app/docs/scripting/api/vector3))

**Returns:** [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox)

### createEmpty()

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

```javascript
createEmpty(): BoundingBox
```

Create an empty bounding box

**Returns:** [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox)

### intersects()

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

```javascript
intersects(box1: BoundingBox, box2: BoundingBox): boolean
```

Check if two boxes intersect

**Parameters:**

* `box1` ([BoundingBox](https://scenery.app/docs/scripting/api/boundingbox))
* `box2` ([BoundingBox](https://scenery.app/docs/scripting/api/boundingbox))

**Returns:** boolean

### intersects()

Documentation source: [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox.md).

```javascript
intersects(other: BoundingBox): boolean
```

Check if bounding boxes intersect

**Parameters:**

* `other` ([BoundingBox](https://scenery.app/docs/scripting/api/boundingbox)) - Other bounding box

**Returns:** boolean

---

Source page: Ray

Source URL: https://scenery.app/docs/scripting/api/ray.md

# Ray

Documentation source: [Ray](https://scenery.app/docs/scripting/api/ray.md).

A ray with origin and direction, useful for raycasting

## Properties

Documentation source: [Ray](https://scenery.app/docs/scripting/api/ray.md).

### direction

Documentation source: [Ray](https://scenery.app/docs/scripting/api/ray.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Normalized ray direction

### origin

Documentation source: [Ray](https://scenery.app/docs/scripting/api/ray.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Ray starting point in world space

---

Source page: Color

Source URL: https://scenery.app/docs/scripting/api/color.md

# Color

Documentation source: [Color](https://scenery.app/docs/scripting/api/color.md).

RGBA color with components in 0-1 range

**Example:**

```javascript
// From RGBA
var c = Color(1, 0, 0, 1); // red

// From hex
var c = Color.hex("#FF5500");

// Preset colors
var c = Color.red();

// Interpolate
var mid = Color.lerp(Color.red(), Color.blue(), 0.5);
```

## Properties

Documentation source: [Color](https://scenery.app/docs/scripting/api/color.md).

### a

Documentation source: [Color](https://scenery.app/docs/scripting/api/color.md).

* **Type:** number
* Alpha component (0-1)

### b

Documentation source: [Color](https://scenery.app/docs/scripting/api/color.md).

* **Type:** number
* Blue component (0-1)

### g

Documentation source: [Color](https://scenery.app/docs/scripting/api/color.md).

* **Type:** number
* Green component (0-1)

### r

Documentation source: [Color](https://scenery.app/docs/scripting/api/color.md).

* **Type:** number
* Red component (0-1)

## Methods

Documentation source: [Color](https://scenery.app/docs/scripting/api/color.md).

### create()

Documentation source: [Color](https://scenery.app/docs/scripting/api/color.md).

```javascript
create(r: number, g: number, b: number, a: number): Color
```

Create a color from RGBA values

**Parameters:**

* `r` (number) - Red (0-1)
* `g` (number) - Green (0-1)
* `b` (number) - Blue (0-1)
* `a` (number) - Alpha (0-1)

**Returns:** [Color](https://scenery.app/docs/scripting/api/color)

### lerp()

Documentation source: [Color](https://scenery.app/docs/scripting/api/color.md).

```javascript
lerp(c1: Color, c2: Color, t: number): Color
```

Linearly interpolate between two colors

**Parameters:**

* `c1` ([Color](https://scenery.app/docs/scripting/api/color)) - Start color
* `c2` ([Color](https://scenery.app/docs/scripting/api/color)) - End color
* `t` (number) - Interpolation factor (0-1)

**Returns:** [Color](https://scenery.app/docs/scripting/api/color)

### lerp()

Documentation source: [Color](https://scenery.app/docs/scripting/api/color.md).

```javascript
lerp(other: Color, t: number): Color
```

Linearly interpolate to another color

**Example:**

```javascript
var blended = Color.red().lerp(Color.blue(), 0.5);
```

**Parameters:**

* `other` ([Color](https://scenery.app/docs/scripting/api/color)) - Target color
* `t` (number) - Interpolation factor (0-1)

**Returns:** [Color](https://scenery.app/docs/scripting/api/color)

---

Source page: Path beta

Source URL: https://scenery.app/docs/scripting/api/path.md

# Path beta

Documentation source: [Path beta](https://scenery.app/docs/scripting/api/path.md).

Runtime path handle returned by `scene.createPath(...)`. Read-only spline queries; consumed by `entity.followPath(...)`. Not persisted (v1).

## Properties

Documentation source: [Path beta](https://scenery.app/docs/scripting/api/path.md).

### length

Documentation source: [Path beta](https://scenery.app/docs/scripting/api/path.md).

* **Type:** number
* Total arc length of the path, in meters.

## Methods

Documentation source: [Path beta](https://scenery.app/docs/scripting/api/path.md).

### point()

Documentation source: [Path beta](https://scenery.app/docs/scripting/api/path.md).

```javascript
point(t: number): Vector3
```

Position at parameter `t` (0…1 across the whole path).

**Parameters:**

* `t` (number)

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### pointAtDistance()

Documentation source: [Path beta](https://scenery.app/docs/scripting/api/path.md).

```javascript
pointAtDistance(d: number): Vector3
```

Position at arc-length distance `d` (0…`length`) – constant-speed spacing.

**Parameters:**

* `d` (number)

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

### tangent()

Documentation source: [Path beta](https://scenery.app/docs/scripting/api/path.md).

```javascript
tangent(t: number): Vector3
```

Unit tangent (direction of travel) at parameter `t`.

**Parameters:**

* `t` (number)

**Returns:** [Vector3](https://scenery.app/docs/scripting/api/vector3)

---

Source page: GeoCoordinate beta

Source URL: https://scenery.app/docs/scripting/api/geocoordinate.md

# GeoCoordinate beta

Documentation source: [GeoCoordinate beta](https://scenery.app/docs/scripting/api/geocoordinate.md).

A geographic coordinate. Construct one for a point of interest, or receive a live fix from `environment.location.current()` (which additionally populates `horizontalAccuracy` and `timestamp`).

## Properties

Documentation source: [GeoCoordinate beta](https://scenery.app/docs/scripting/api/geocoordinate.md).

### latitude

Documentation source: [GeoCoordinate beta](https://scenery.app/docs/scripting/api/geocoordinate.md).

* **Type:** number
* Degrees north (−90 to 90).

### longitude

Documentation source: [GeoCoordinate beta](https://scenery.app/docs/scripting/api/geocoordinate.md).

* **Type:** number
* Degrees east (−180 to 180).

### altitude

Documentation source: [GeoCoordinate beta](https://scenery.app/docs/scripting/api/geocoordinate.md).

* **Type:** number | null
* Metres above sea level, or `null` when not provided.

### horizontalAccuracy

Documentation source: [GeoCoordinate beta](https://scenery.app/docs/scripting/api/geocoordinate.md).

* **Type:** number | null
* Radius of horizontal uncertainty in metres – smaller is more accurate. Populated on a live fix from `environment.location.current()`; `null` on an author-constructed coordinate.

### timestamp

Documentation source: [GeoCoordinate beta](https://scenery.app/docs/scripting/api/geocoordinate.md).

* **Type:** number | null
* When the fix was taken, in seconds. Populated on a live fix; `null` on an author-constructed coordinate.

## Instance Methods

Documentation source: [GeoCoordinate beta](https://scenery.app/docs/scripting/api/geocoordinate.md).

### distanceTo()

Documentation source: [GeoCoordinate beta](https://scenery.app/docs/scripting/api/geocoordinate.md).

```javascript
distanceTo(other: GeoCoordinate): number
```

Great-circle distance to another coordinate, in metres (haversine, 6371 km).

**Parameters:**

* `other` ([GeoCoordinate](https://scenery.app/docs/scripting/api/geocoordinate))

**Returns:** number

### bearingTo()

Documentation source: [GeoCoordinate beta](https://scenery.app/docs/scripting/api/geocoordinate.md).

```javascript
bearingTo(other: GeoCoordinate): number
```

Initial great-circle bearing to another coordinate, in degrees (0–360, from north).

**Parameters:**

* `other` ([GeoCoordinate](https://scenery.app/docs/scripting/api/geocoordinate))

**Returns:** number

