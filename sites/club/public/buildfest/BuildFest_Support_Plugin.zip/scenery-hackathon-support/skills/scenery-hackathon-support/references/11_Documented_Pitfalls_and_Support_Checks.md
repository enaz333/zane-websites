# Documented Pitfalls and Support Checks

Evidence: source-backed pitfalls from the November 5, 2026 docs. These are documented constraints and diagnostic checks, not a record of fixes validated on participants' devices. Keep hypotheses separate from confirmed causes.

## Create button missing / authoring versus viewing

Check which device is being used. The docs place authoring on Mac/iPad and primarily viewing on iPhone/Vision Pro. Do not infer broken permissions from a missing Create control on a viewing device.
Source: https://scenery.app/docs/guide/first-experience.md and https://scenery.app/docs/guide/compatibility.md

## Marker content wrong size or distance

Check the physical width of the printed image area itself, excluding borders. The Image anchor's physical width uses centimetres. Verify orientation, continuous tracking and hide-on-loss settings against the intended behavior. Glare or repeating artwork can also affect detection; test the actual print.
Source: https://scenery.app/docs/editor/anchors.md

## Object appears too soon / tap reveal does nothing

New content normally has Add to Scene on On Experience Start. For a later reveal, remove that target's startup action and add it from the intended event. Confirm event target, enabled state and repeat setting before changing unrelated tracking settings.
Source: https://scenery.app/docs/editor/actions/scene-content.md and https://scenery.app/docs/editor/triggers.md

## Show/hide does not alternate

Toggle Object sets a fixed visible/hidden state; its label is Show Object or Hide Object. It is not an automatic flip. Stacking show and hide on the same trigger runs both. Retrieve documented enabled-event switching or Cycle states to implement alternation.
Source: https://scenery.app/docs/editor/actions/scene-content.md and https://scenery.app/docs/editor/actions/action-ordering.md

## Timing / events left behind / collision not firing

Actions normally run sequentially; Group runs simultaneously. Avoid fragile long Wait chains when documented events can drive timing. Deleted objects can leave unlinked events. On Object Collision requires physics on both objects; do not generalize this requirement to every trigger such as Distance Field.
Source: https://scenery.app/docs/editor/triggers.md and https://scenery.app/docs/editor/actions/action-ordering.md

## Black background on transparent video

Check the documented codec/container/alpha requirements, not just the filename extension. The guide specifies HEVC with alpha in MOV and explains export steps. H.264 cannot preserve alpha. Retrieve the full guide before recommending an export workflow.
Source: https://scenery.app/docs/guide/transparent-video.md

## App Clip link fails / in-app browser / Safari

For Apple App Clip delivery, the publishing page describes QR/NFC as the smoothest entry and a browser link's Open App Clip prompt as Safari, non-private browsing only. Check the viewer platform, actual delivery route and availability settings. Opening an Apple browser link in non-private Safari is a relevant test; it is not a universal fix for Android/WebXR, native-app errors or asset loading.
Source: https://scenery.app/docs/guide/publishing.md and https://scenery.app/docs/webxr.md

## Script returns null / AI-generated code fails

Retrieve Getting Started and the exact API. scene.findEntity addresses top-level objects, with nested content reached through the documented hierarchy. A target must exist when its script runs; action order and appearance lifecycle matter. scene.createEntity takes one descriptor; use the documented chainable builder rather than inventing a second options argument. Rotation values are radians.
Source: https://scenery.app/docs/scripting/guide/getting-started.md and https://scenery.app/docs/scripting/api/scene.md

## Locked feature, beta, or disagreement about capabilities

Retrieve the feature's page plus current snapshot compatibility. Do not infer a plan entitlement from a general marketing statement. “Coming soon,” “experimental,” and “partial” are not equivalent to generally available. If the installed build or account differs, state that uncertainty and request the relevant evidence or escalate.
Source: https://scenery.app/docs/guide/compatibility.md ; https://scenery.app/docs/editor/actions/developer.md ; https://scenery.app/docs/scripting.md

## API keys and fake integrations

Scripts can be readable by viewers. Retrieve Secrets before recommending integration setup; use placeholders, not pasted credentials. A staged response must be described as staged, and a simulated sensor or service must not be presented as actually connected.
Source: https://scenery.app/docs/editor/secrets.md
