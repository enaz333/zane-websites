# Sharing Testing and Device Differences

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: QR code; link; cannot open; Safari; App Clip; Android; browser; iPhone; iPad; Mac; Vision Pro; sharing; WebXR.

## Contents

- Compatibility
- Publishing & Sharing
- Scenery on the Web (WebXR)

---

Source page: Compatibility

Source URL: https://scenery.app/docs/guide/compatibility.md

# Compatibility

Documentation source: [Compatibility](https://scenery.app/docs/guide/compatibility.md).

Scenery lets you **build once and deploy to many platforms** – but not every feature works everywhere. A small **compatibility** indicator appears throughout the editor next to features, contexts, and settings, telling you at a glance where each one is supported.

## Reading the indicator

Documentation source: [Compatibility](https://scenery.app/docs/guide/compatibility.md).

Tap a compatibility indicator to see per-platform support across **iPhone & iPad**, **Mac**, **Apple Vision Pro**, and the **web (WebXR)**. Each platform shows one of three states:

* **Fully compatible** – works as intended.
* **Partially compatible** – available with limits. Often this means **preview only**: on Mac, for instance, you can preview content in the simulator but not experience it at full scale, because a Mac has no depth sensing or full world tracking.
* **Not compatible** – not available on that platform.

![A compatibility popover for macOS – Partially Compatible Feature, supported in simulator mode](https://scenery.app/docs/assets/compatibility-popover.ByRvaaM8.jpg)
*A compatibility popover: Partially Compatible on Mac, supported in simulator mode.*

Because you choose a [tracking context](https://scenery.app/docs/editor/tracking-contexts) first, the compatibility shown depends partly on that choice – the context picker updates its indicator as you select.

## Tracking-context support

Documentation source: [Compatibility](https://scenery.app/docs/guide/compatibility.md).

How each context is supported, per platform:

| Context | iPhone & iPad | Mac | Apple Vision Pro | Web (WebXR) |
|---|---|---|---|---|
| **World-Tracking** | Full | Preview (simulator) | Full | Full |
| **Geo-Tracking** | Full | Preview (simulator) | Preview (diorama) | Coming soon |
| **Image-Tracking** | Full | Preview (simulator) | Partial | Partial (needs an experimental Chrome flag) |
| **Face-Tracking** | Full | Preview (simulator) | Not supported | Experimental |
| **Playspace** | Full | Preview (simulator) | Full | Coming soon |
| **Room Bound** | Coming soon | Coming soon | Coming soon | Coming soon |
| **Body-Tracking** | Coming soon | Coming soon | Coming soon | Coming soon |

For exactly what carries over to the browser, see [WebXR](https://scenery.app/docs/webxr/).

::: tip Authoring vs. viewing
Experiences are **currently built** on **Mac and iPad** (where the Create button appears). **iPhone** and **Apple Vision Pro** are primarily for **viewing** experiences.
:::

---

Source page: Publishing & Sharing

Source URL: https://scenery.app/docs/guide/publishing.md

# Publishing & Sharing

Documentation source: [Publishing & Sharing](https://scenery.app/docs/guide/publishing.md).

Every experience gets a **shareable link** – the gateway for others to open it. How it's delivered depends on the platform and your plan.

## Sharing on Apple devices

Documentation source: [Publishing & Sharing](https://scenery.app/docs/guide/publishing.md).

On paid plans, the link is an **App Clip** – instant access with **no app install**. Open it from a **QR code or NFC tag** for the smoothest entry, since that skips the browser. A plain browser link instead shows an "open App Clip" prompt (Safari, non-private browsing only), which is why a QR code is recommended.

Generate and manage the link in [Experience settings](https://scenery.app/docs/editor/experience-settings#sharing-delivery). There you also set **availability** (Public / Private / Link) and whether the experience can be **featured** in Discover.

## Sharing on the web (WebXR)

Documentation source: [Publishing & Sharing](https://scenery.app/docs/guide/publishing.md).

Turn on **WebXR support** to also run the experience in a **browser** – full AR on Android, interactive 3D on desktop. See [WebXR](https://scenery.app/docs/webxr/) for what carries over and how to enable it.

## Where it runs

Documentation source: [Publishing & Sharing](https://scenery.app/docs/guide/publishing.md).

Different devices and contexts support different things – see [Compatibility](https://scenery.app/docs/guide/compatibility) for the full picture, and use [per-device anchoring](https://scenery.app/docs/editor/anchors#per-device-anchoring-device-configuration) to give each kind of device the placement that suits it.

---

Source page: Scenery on the Web (WebXR)

Source URL: https://scenery.app/docs/webxr.md

# Scenery on the Web (WebXR)&#x20;

Documentation source: [Scenery on the Web (WebXR)](https://scenery.app/docs/webxr.md).

The **WebXR Viewer** brings your experiences to the browser – no app install needed. Every experience with WebXR enabled gets a shareable link that works across devices:

* **Android** – full immersive AR in Chrome.
* **Desktop** – an interactive 3D preview in any modern browser (orbit the scene from any angle).
* **iOS** – continues to use App Clips for the best native experience.

::: warning Beta
The WebXR Viewer is in **beta**. Browser-based AR is improving quickly but isn't yet on par with the native experience, so **test before sharing** with your audience.
:::

## Enabling WebXR

Documentation source: [Scenery on the Web (WebXR)](https://scenery.app/docs/webxr.md).

WebXR is available to every creator – you opt in per experience:

1. In the editor's [Experience settings](https://scenery.app/docs/editor/experience-settings#platforms-webxr), turn on **WebXR support**.
2. A viewer URL is generated automatically (`viewer.scenery.app/{experienceId}`).
3. Share it however you like – QR code, social media, email, or embedded on your own site.

![The WebXR Support toggle in the experience settings, with the Beta badge](https://scenery.app/docs/assets/webxr-support.D9pUJHdr.jpg)
*Enable WebXR Support in the experience settings.*

On a campaign landing page, visitors see an action that matches their device: Android users get **View in AR**, desktop users get **View in 3D**, and iOS users get the full App Clip.

## What works

Documentation source: [Scenery on the Web (WebXR)](https://scenery.app/docs/webxr.md).

Most of what you build in the editor carries straight over to the web:

* **3D models** with full PBR materials and **animations** (keyframe, skeletal, morph targets / blend shapes).
* **Interactions** – tap, proximity, timers, visibility triggers, and the rest of the event system.
* **Spatial and ambient audio.**
* **Video textures** (MP4, WebM).
* **Physics** – gravity, collisions, impulses.
* **Face tracking** (Android).
* **Image tracking** (Chrome, with an experimental browser flag enabled).
* **Variables and conditional logic.**
* **Multi-segment experiences** with scene transitions.

## What works differently

Documentation source: [Scenery on the Web (WebXR)](https://scenery.app/docs/webxr.md).

A few things behave slightly differently from the native iOS / visionOS experience:

* **3D model fidelity** – most models render accurately; some advanced surface features (e.g. subdivision surfaces) may look slightly different. This improves with each update.
* **Face tracking** – uses a different tracking engine than the native depth camera. Good, but not identical.
* **Image tracking** – available in Chrome, but requires enabling an experimental browser flag (off by default).
* **Physics** – a different physics engine under the hood; very close, but not identical to the native app.

## Not yet supported

Documentation source: [Scenery on the Web (WebXR)](https://scenery.app/docs/webxr.md).

These native features don't run in the viewer yet. If your experience relies on one, it may not render as expected:

* Custom **scripting**.
* **ShaderGraph / custom shader** materials (they use platform-specific shader nodes with no web equivalent yet).
* **Particle systems.**
* **Location-based** experiences (GPS / visual positioning).
* **Play-space-bound** experiences.
* **Immersive 180° / 360° video** (renders as flat video).
* **Haptic feedback.**
* **Audio-reactive effects** (beat detection, frequency-driven animation).
* **Transparent video** (alpha channel).
* **Draw order groups.**
* **In-viewer recording** (screenshots / screen recording).
* **Post-processing effects.**

## On the roadmap

Documentation source: [Scenery on the Web (WebXR)](https://scenery.app/docs/webxr.md).

We're actively expanding the viewer: custom scripting, play-space-bound experiences, Meta Quest support, haptic feedback, immersive 180° / 360° video, transparent video, draw order groups, post-processing effects, and in-viewer recording.

## Where it runs

Documentation source: [Scenery on the Web (WebXR)](https://scenery.app/docs/webxr.md).

| | AR mode | 3D viewer |
|---|---|---|
| **Chrome (Android)** | Full AR | Full 3D |
| **Chrome (desktop)** | – | Full 3D |
| **Safari (iOS / macOS)** | Use the native Scenery app | – |
| **Firefox** | – | Limited 3D |
| **Meta Quest** | Coming soon | Coming soon |

Web and desktop correspond to the **Desktop** device category in [per-device anchoring](https://scenery.app/docs/editor/anchors#per-device-anchoring-device-configuration), so you can give web visitors a placement that suits a flat screen.

