# Face Tracking and Special Cases

Evidence: authored routing aid with attributed facts from the snapshot, not a tested support history. November 5, 2026.

Search terms: face filter; mask; selfie; front camera; blink; eyes; pupil; smile; expression; hand; body; headset; face not following.

## Face projects

Source: https://scenery.app/docs/editor/tracking-contexts.md

Face-Tracking uses the front camera and anchors to the user's face for masks, accessories and face-following effects. The source explicitly says it does not include higher-level pupil/eye-movement triggers. Do not equate a tracked face with gaze detection, emotion recognition, identity recognition, or a ready-made blink trigger.

For expression-driven animation, the guide points to blend-shape animation. Retrieve the exact Update Blendshape Weights action in 04 before suggesting it. Do not promise automatic sensor-to-blendshape wiring merely because changing a weight is documented.

First prototype: one face-following visual on a supported viewer, then one supported interaction. Confirm the device/platform before giving detailed steps. The tracking context is chosen at creation and cannot be changed later; see 02.

## Target compatibility is a separate question

Source: https://scenery.app/docs/guide/compatibility.md

The snapshot lists Face-Tracking as full on iPhone/iPad, Mac simulator preview, unsupported on Apple Vision Pro, and experimental on WebXR. These are dated documented classifications, not evidence that every specific device/build works. Use the feature's compatibility indicator and exact target test. Do not say a Mac preview proves native face-tracking on a headset or browser.

## Hands and body are not interchangeable with face tracking

Sources: https://scenery.app/docs/editor/anchors.md and https://scenery.app/docs/editor/tracking-contexts.md

The snapshot's Hand anchor is Apple Vision Pro only; per-device anchoring can provide a documented alternative on handheld viewers. Object-level Hand anchoring is separate from the experience context. Body-Tracking and Room Bound are shown as Coming Soon in this snapshot; do not recommend them as available context options.

## If it fails

Use 09's diagnostic loop: expected/actual behavior, selected context, intended viewer, one known-good object and a targeted screenshot. After two relevant failed tests, or sooner for a documented platform limit or probable build-specific bug, provide a concise Discord handoff. Do not ask the participant to rebuild the entire project before verifying the context and viewer.
