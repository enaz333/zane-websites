# Assets Media and Performance

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: USDZ; model; import; missing texture; video black background; sound; image; lag; lighting; material; physics.

## Contents

- Transparent Video
- Adding Content to a Scene
- Asset Appearances
- Asset Properties
- Materials
- Post-FX
- Environments & Lighting

---

Source page: Transparent Video

Source URL: https://scenery.app/docs/guide/transparent-video.md

# Transparent Video

Documentation source: [Transparent Video](https://scenery.app/docs/guide/transparent-video.md).

A transparent video has a see-through background, so a character, logo, or effect stands in the real world without a rectangular frame around it. Combined with the **Billboard** [alignment constraint](https://scenery.app/docs/editor/asset-appearances#transform-alignment), a filmed or animated character can face the viewer from every angle and read as if it were 3D.

The one format that carries transparency all the way to playback is HEVC with an alpha channel in a QuickTime (.mov) container.

## The format that works

Documentation source: [Transparent Video](https://scenery.app/docs/guide/transparent-video.md).

* **HEVC (H.265) with an alpha channel, in a `.mov`.** Upload it like any other video – no extra setting in the editor.
* **H.264 cannot store transparency at all.** An ordinary MP4 export will always arrive with a solid background.
* **WebM / VP9**, the transparent format used on the web, is not supported.

Once uploaded, a transparent video behaves like any other video object: it autoplays, loops, and can be triggered by [events and actions](https://scenery.app/docs/editor/triggers).

## Making one

Documentation source: [Transparent Video](https://scenery.app/docs/guide/transparent-video.md).

Most animation and editing tools cannot export this format directly, so it usually takes two steps.

**1. Export a master that keeps transparency.** Apple ProRes 4444 in a `.mov`, with the channel setting on **RGB + Alpha**. Make sure the background is genuinely empty – no black or white solid, no leftover background layer, and any keying applied before the export.

**2. Convert that master to HEVC with alpha.** The encoder for this format ships with macOS, so this step needs a Mac.

* **[Apple Compressor](https://apps.apple.com/us/app/compressor/id424390742)** – create a new setting, choose **QuickTime Movie** as the container, pick **HEVC 8-bit**, and tick **Preserve alpha**. It is off by default, and it is only offered for the QuickTime container.
* **Command line** – `ffmpeg -i master.mov -c:v hevc_videotoolbox -alpha_quality 0.9 -tag:v hvc1 transparent.mov`

::: tip After Effects and Media Encoder
Adobe's exporters can write ProRes 4444 with alpha, but not HEVC with alpha. Use one for the master and convert with one of the tools above. Dedicated converters such as [Rotato](https://rotato.app/blog/transparent-videos-for-the-web) can also do the second step.
:::

## When the background isn't transparent

Documentation source: [Transparent Video](https://scenery.app/docs/guide/transparent-video.md).

Work down this list – the cause is almost always in the export, and the file is opaque before it ever reaches Scenery:

* exported as H.264, or as MP4 rather than QuickTime
* **Preserve alpha** left unticked in [Apple Compressor](https://apps.apple.com/us/app/compressor/id424390742)
* channels set to RGB instead of **RGB + Alpha**
* the composition rendered over a solid colour, or a background layer still visible
* the key or matte not applied to the exported comp

A quick check before uploading: open the file in QuickTime Player on a Mac. If the background shows as white or black there, the transparency is not in the file.

## When the edges look dark or haloed

Documentation source: [Transparent Video](https://scenery.app/docs/guide/transparent-video.md).

That is a mismatch between **premultiplied** and **straight** alpha. Apple's format expects premultiplied, which is what most tools produce by default. If your export offers the choice, pick premultiplied.

## Keeping the file small

Documentation source: [Transparent Video](https://scenery.app/docs/guide/transparent-video.md).

Transparent video is uploaded as you supply it, without further compression, so the size you export is the size your viewers download.

* Alpha quality is controlled separately from the picture bitrate, so you can lower the picture bitrate noticeably and still keep clean cut-out edges. Both live in the conversion step – the bitrate and **Preserve alpha** fields in [Apple Compressor](https://apps.apple.com/us/app/compressor/id424390742), or `-alpha_quality` alongside the quality setting on the command line.
* 720p is often enough for a billboarded character standing a few metres away.
* Trim tightly and loop a short clip rather than shipping a long one.
* For long or high-resolution clips, consider [HLS streaming](https://scenery.app/docs/editor/adding-content)  instead of an upload.

---

Source page: Adding Content to a Scene

Source URL: https://scenery.app/docs/editor/adding-content.md

# Adding Content to a Scene

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

Add content from the **+** button. Each element you add becomes an **object** in the scene, holding its visual content inside it. You can give each object its own **[anchor](https://scenery.app/docs/editor/anchors)** (how it attaches to the world), and style it in [Asset Appearances](https://scenery.app/docs/editor/asset-appearances), [Asset Properties](https://scenery.app/docs/editor/asset-properties), and [Materials](https://scenery.app/docs/editor/materials). This page covers the **content types** themselves and their type-specific options (set in the object's **Appearance → Model** section).

![The + menu open – Add Container, Add 3D Model, Add Media, Add Primitive, Add Portal](https://scenery.app/docs/assets/insert-menu.BIR57Uwi.jpg)
*The + (Insert) menu.*

The Insert menu offers Container, 3D Model, Media, Primitive, and Portal to everyone, and User Interface on the Pro plan and up.

## Container

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

An empty grouping you fill with other content, or use to **anchor several objects together** as one unit.

## Primitive

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

A basic shape – a **horizontal or vertical plane**, a **box**, or a **sphere** – with dimensions, and a **corner radius** on planes and boxes. Good for prototyping and placeholders.

## 3D Model

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

Your own **3D model**, or a ready-made **integrated asset**.

* **Custom model** – pick a model from the asset library; the field shows a preview, file format, and size.
* **Integrated asset** – assets that ship with the editor (checkpoints, coin, star, ruby…), with optional colour tints; checkpoints can be set to **start / finish / default**. Handy starting points, especially for scavenger hunts.

![The Model section with the asset kind chosen – here an Integrated asset, with its built-in asset list](https://scenery.app/docs/assets/model-kind-picker.B11Xd5eg.jpg)
*Choosing the content kind – here an Integrated Asset and its built-in list.*

::: tip Use USDZ for 3D
Scenery runs natively on Apple platforms and the WebXR viewer, all using **USDZ**. Prepare models, ShaderGraph materials, and particle systems in Reality Composer Pro and export as USDZ – one format that runs everywhere.
:::

## Media

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

An **image** or a **video**.

* **Image** – PNG (with transparency) or JPEG.
* **Video** comes in a few flavours:
  * **Standard video** (MP4 / MOV) – a flat rectangular screen.
  * **Spatial (stereoscopic) video** – a different image per eye for depth; the depth shows on **headsets** (it plays normally on mobile).
  * **Transparent video** – alpha-channel video (MOV, HEVC / H.265). Pairs beautifully with the **Billboard** [alignment constraint](https://scenery.app/docs/editor/asset-appearances#transform-alignment) for a character that always faces the user and reads as 3D.
  * **[HTTP Live Streaming (HLS)](https://developer.apple.com/documentation/HTTP-Live-Streaming)**  – stream large or high-res video from a URL instead of uploading it (via manual input, below).
  * **Immersive video**  – 180°, 360°, and wide field-of-view video, plus Apple Immersive Video. On **Apple Vision Pro** these wrap around the viewer – a 360° clip surrounds you completely, 180° fills your forward view, and Apple Immersive Video places you inside the scene. Scenery recognizes an immersive source automatically and plays it natively. These files are very large, so Scenery does not host, stream, or accept uploads of them – you host the video on your own server (a service like [SpatialGen](https://spatialgen.com) can do this) and point at it via **manual URL input** (below). *(currently Apple Vision Pro only)*

::: tip Making a transparent video
Only HEVC with an alpha channel, in a `.mov`, keeps its transparency – an ordinary MP4 export always arrives with a solid background, and most tools do not offer the right format directly. [Transparent Video](https://scenery.app/docs/guide/transparent-video) has the export recipe and what to check when the background isn't see-through.
:::

For an immersive video to actually **surround you**, set the Scene's immersion to **Full** or **Progressive** in [Scene Settings](https://scenery.app/docs/editor/scene-settings) – otherwise it plays in a **portal** alongside your real surroundings, rather than wrapping around you. Either way, your **other objects still render in front of the video** – you can place models, primitives, and interface over it, even in full immersion. You can also switch immersion mid-experience with the **[Set Immersion Mode](https://scenery.app/docs/editor/actions/experience#set-immersion-mode)** action – for example, run it to enter Full immersion just before the video is displayed, instead of setting the Scene's immersion up front.

On devices other than Apple Vision Pro an immersive video plays as a flat screen. To tailor that, use a **[Conditional Logic](https://scenery.app/docs/editor/actions/action-ordering#conditional-logic)** action with a **Platform Is** check – for example, display the immersive object on Apple Vision Pro and a standard flat video everywhere else.

Media-specific options (in the object's **Appearance → Model** section): **Shows Loading-Placeholder** (a placeholder while a large asset loads), **Autoplays** and **Loops** (video only), **Renders Double Sided** (also draw the back face), **Renders Immersively** (blends the media softly into the surrounding space – especially nice with spatial video), a **Corner Radius** (rounds the media's corners, when not rendering immersively), and **Volume** for a video's audio.

![A video media object – media type, the source clip, and the loading placeholder, autoplay, and loops toggles](https://scenery.app/docs/assets/media-video-options.BQksNNV8.jpg)
*Media options on a video object.*

::: tip Load assets from your own URL
&#x20;Right-click an asset field → **manual input** to point at an asset **URL** on your own server. The asset is fetched at runtime (never uploaded to Scenery), sidestepping upload size limits and keeping confidential assets off our servers. The same works for **HLS** streams. (Note: file-sharing services like Drive/Dropbox block this by default; self-hosting works.)
:::

::: tip Keep experiences small
Everything in an experience downloads on first open (then caches). Aim for a small total – roughly **30–50 MB** for App Clip-delivered mobile experiences. For big or high-res video, prefer an **HLS** stream or a manual asset URL over uploading.
:::

## Gaussian Splat

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

A **scanned capture** of a real object or place – captured with a phone or a scanner, and stored
as hundreds of thousands of tiny coloured blobs rather than as a mesh. Captures look photographic
where a hand-made model would look modelled, and they carry the lighting of the moment they were
scanned.

Bring one in as an **SPZ** file from the asset library, then place and anchor it like any other
object. A capture's own options sit in its **Gaussian Splat** section:

* **Projection** – how each splat is flattened to the screen. Tangential is cheaper, but bends
  straight edges.
* **Sorting** – the order splats are blended in. Distance stays steadier as the viewer turns, at
  some cost.
* **Source Coordinates** – the axes the capture's file stores its splats in. Exports from SuperSplat, Niantic's ply\_to\_spz and other PLY-based tools often appear upside down; choose **PLY / OpenCV (Y down)** for those. Most SPZ files, Scaniverse's among them, use **Standard (Y up)**. An SPZ 4 file that declares its axes sets this for you when you pick it.
* **Opacity Threshold** – drops the faintest splats when the capture loads, from **0 to 1**. Zero
  keeps every one.

### Starting from a PLY

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

Most capture and training tools write **PLY**, the format scans are trained and archived in. The
asset library takes **SPZ**, which holds the same capture at roughly a tenth of the size – worth
having when a capture crosses a network before it renders. Scaniverse writes SPZ directly, so a
capture made there needs no conversion; anything else converts in a step:

* **SuperSplat Convert** – [superspl.at/convert](https://superspl.at/convert) runs in the browser
  and keeps the file on your machine. It can also **decimate** a capture, merging similar splats
  to bring a large scan under the per-capture limit.
* **SplatTransform** – the same conversion as a command line tool, for batches:
  `npm install -g @playcanvas/splat-transform`.

Either version of SPZ works, so whichever a converter writes by default can be uploaded as it is.

::: tip Trim the haze first
A capture's cost is mostly driven by how much of the screen its blobs cover rather than by how
many there are, so dropping the faintest ones is often the cheapest way to lighten a heavy
capture. How much of a
capture is haze varies from scan to scan, which is why it is a control rather than a fixed value.
:::

A scene can hold up to **eight** captures, and a single capture can hold up to **400,000** splats
on Apple Vision Pro. The limit is higher on other systems, but the one that applies is the one on
the device an experience is opened on. A capture above it still appears there, thinned to the limit
by dropping its faintest and smallest splats first, so nothing is ever missing – though which splats
survive is then chosen for you rather than by you.
Captures need **iOS 27, iPadOS 27, macOS 27 or visionOS 27** – on an earlier system
the editor shows a placeholder in the capture's place, and an experience viewed there shows
nothing.

### Renditions

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

Rather than let a headset thin a capture on its own, you can attach a **rendition** – the same
capture, reduced yourself in one of the tools above, stored alongside the original. Each device then
downloads whichever version fits what it can draw, so a Mac gets the full capture and Apple Vision
Pro gets the smaller one.

Renditions are managed in the asset library. Select the capture, choose **Alternate Files**, and use
**Add Rendition** in the sheet that opens. Each row shows the splat count and file size, marked with
the devices that would download it, so you can see at a glance whether a headset is covered.

A rendition has to be genuinely smaller than the capture it stands in for, and its splat count is
read from the file rather than typed, so the number a device compares against is always the file's
own. Replacing the capture itself clears its renditions, since they would otherwise describe a
different scan.

::: tip Two reductions, one goal
The **Opacity Threshold** above drops faint splats on every device. A rendition replaces the whole
file on devices that need a smaller one. They combine, and a capture that reads well after trimming
haze often needs a much gentler rendition.
:::

## User Interface&#x20;

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

Build an interactive **interface panel** – buttons, labels, images, and other controls laid out in 2D, placed in the scene or pinned as a [Screen Space](https://scenery.app/docs/editor/anchors#screen-space) overlay. Click **Edit Interface** in the object's Model section to open the UI editor. The [User Interface](https://scenery.app/docs/editor/user-interface/) section covers it in full.

## Portal&#x20;

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

A **portal world** – a framed window into a self-contained little world that the user looks through, and can step into. You build the world *inside* the portal: add objects to it like any container, and give it its own environment. It's grouped under the object's **Portal World** section.

Portal-specific options:

* **Background** – a surrounding environment for the world, from an **image** or **video**, projected as **Equirectangular** or **Cubemap** (the two common 360° layouts).
* **Lighting** – the portal world's own environment lighting, independent of the main scene.
* **Object Crossing** – let the world's contents reach *out* through a chosen boundary – **Front, Back, Left, Right, Top**, or **Bottom** (or **Disabled**) – so an object can break the frame and poke into the room.
* **Object Clipping** – clip the contents at a chosen plane (same options), to keep the world neatly bounded by the portal opening.

## Placing what you add

Documentation source: [Adding Content to a Scene](https://scenery.app/docs/editor/adding-content.md).

New content appears at the **scene origin** (where the axes meet). Move it with the gizmo by dragging an axis handle – **X** (red), **Y** (green), or **Z** (blue) – or type exact values in the object's transform.

![A selected object with the move gizmo – the X (red), Y (green), and Z (blue) axis handles](https://scenery.app/docs/assets/gizmo-placement.CfZH_WG1.jpg)
*Moving an object with the gizmo's X / Y / Z handles.*

---

Source page: Asset Appearances

Source URL: https://scenery.app/docs/editor/asset-appearances.md

# Asset Appearances

Documentation source: [Asset Appearances](https://scenery.app/docs/editor/asset-appearances.md).

Select an object and open its **Appearance** tab to control how it looks and sits in the scene. (Behaviour like gestures and physics lives in [Asset Properties](https://scenery.app/docs/editor/asset-properties).)

## Transform & alignment

Documentation source: [Asset Appearances](https://scenery.app/docs/editor/asset-appearances.md).

* **Transform** – offset (position), rotation (in degrees), and scale. Scale has a **proportional lock** (closed = scale all axes together; open = scale each axis independently). Tip: drag inside a value field to adjust it smoothly.
* **Vertical alignment** – how the object sits vertically:
  * **None** – stays exactly where you place it.
  * **Floor** – snaps to the floor, wherever it's placed.
  * **Eye level** – rises or lowers to the viewer's height. Good for accessibility – e.g. collectibles that stay reachable for both a tall adult and a small child.
* **Alignment constraints**:
  * **None** – fixed orientation.
  * **Billboard** – always faces the user (great for characters, readable UI).
  * **Look At** – faces the user *or* another object you choose, with optional **transition smoothing** for a natural, lazy follow.

Scripts and AI agents that write an object's stored settings use these values in the representation's `traits`:

* **Vertical alignment** – `verticalAlignment` is `"floor"` for Floor or `"pointOfView"` for Eye level. None leaves it out.
* **Alignment constraints** – `constraints` is `[{"identifier": "billboard"}]` for Billboard or `[{"identifier": "lookAt", "configuration": {"targetElementId": "…"}}]` for Look At, without a configuration to face the user. None leaves it out.

![Transform and alignment – offset, rotation, scale with the proportional lock, vertical alignment, and the alignment constraint](https://scenery.app/docs/assets/transform-alignment.C-BKWSAS.jpg)
*The Transform & Alignment section of the Appearance tab.*

## Model

Documentation source: [Asset Appearances](https://scenery.app/docs/editor/asset-appearances.md).

The object's **kind** – Primitive, Integrated asset, Custom model, Media, or Web view – and its core look. The kind and its type-specific options live in [Adding Content](https://scenery.app/docs/editor/adding-content); here you also set its **opacity** (0 transparent to 1 opaque).

## Render & adjustments

Documentation source: [Asset Appearances](https://scenery.app/docs/editor/asset-appearances.md).

* **Render model** – on by default; turn off to keep an object in the scene but invisible until shown by an action.
* **Size adjustment (fitting box)** – very large models are auto-fit into a 1 m³ box (preserving proportions) so an accidentally huge import doesn't fill the room. Set to **None** to use the model's real size.
* **Pivot adjustment** – which face of the object sits at its origin: None, Top, Center, Bottom,
  Left, Right, Front, or Back. It decides how content seats against whatever it is attached to –
  **Bottom** stands a model on a floor, **Back** hangs one flat against a wall. Left on its own
  origin, a model straddles the surface it is placed on, so half of anything solid ends up inside
  a wall.

## Hover effect

Documentation source: [Asset Appearances](https://scenery.app/docs/editor/asset-appearances.md).

On **Apple Vision Pro**, looking at an interactive object highlights it. Set this to **Automatically**, **Always**, or **Never** (turn it off if it clashes with your visual style). When on, choose a **Highlight**, **Spotlight**, or shader-based effect, with a custom colour, strength, and **transparency behaviour**:

* **Full** – the effect always renders at full opacity, ignoring the object's transparency.
* **Mask** – appears only where the object's opacity is above ~5% (visible parts only).
* **Blend** – the effect's opacity follows the object's, fading in and out together.

![The hover effect options – effect type, colour, strength, and transparency behaviour](https://scenery.app/docs/assets/hover-effect.BY8XqLGE.jpg)
*The Apple Vision Pro Hover Effect options.*

## Lighting & shadows

Documentation source: [Asset Appearances](https://scenery.app/docs/editor/asset-appearances.md).

* **Cast dynamic light shadows** – the object casts shadows onto the real environment (not on the web yet).
* **Bloom** – let this object glow. Only takes effect when the scene's [Bloom](https://scenery.app/docs/editor/scene-settings#bloom) is set to **Selected objects**; the switch is dimmed otherwise, since under **Whole scene** anything bright enough already blooms. The object still has to be bright enough to pass the scene's threshold – marking it opts it in, it doesn't force it to glow.
* **Cast grounding shadows** – a shadow beneath the object, as if lit from above.
* **Receive grounding shadows** – the object receives other objects' grounding shadows.
* **Fade behaviour near physical objects** – how a grounding shadow behaves where it falls close to real-world objects:
  * **Default** – the system's standard handling.
  * **Constant** – the shadow stays at full strength even right up against nearby real-world objects.
  * **Fade** – the shadow softens and fades out as it approaches detected real-world objects, so it doesn't read as painted across a surface it shouldn't touch.

![The lighting and shadows controls – cast dynamic light shadows, cast and receive grounding shadows, and the fade behaviour menu](https://scenery.app/docs/assets/lighting-shadows.DaalTKnJ.jpg)
*The Lighting & Shadows section.*

## Reveal & removal animations

Documentation source: [Asset Appearances](https://scenery.app/docs/editor/asset-appearances.md).

How the object animates in and out. Default is **fade and scale**; you can also choose **fade** only, or disable it. Each has a **duration** and **scale factor** – e.g. a playful pop-in (fade + scale from small) or a quiet, slow fade so users barely notice it appear.

![The reveal and removal animation options – kind, duration, and scale factor](https://scenery.app/docs/assets/reveal-removal.DLVbeevz.jpg)
*The Reveal and Removal Animation options.*

## Material overrides

Documentation source: [Asset Appearances](https://scenery.app/docs/editor/asset-appearances.md).

* **Face culling** – each surface of a model has an **outer** and an **inner** side, and only one is drawn by default (the other is left invisible, which saves work). This controls which:
  * **Back** (default) – draws the **outer** side; the normal choice for solid objects, whose insides you never see.
  * **Front** – draws the **inner** side instead, so the object looks hollow or inside-out – handy for seeing inside a shape.
  * **None** – draws **both** sides; use it for thin, flat, double-sided things like a plane or sheet that would otherwise vanish when seen from behind.

![The default-materials face-culling menu – Back, Front, None](https://scenery.app/docs/assets/face-culling.ukGp-dgk.jpg)
*Face Culling sits at the top of Material Overrides, above the custom-material reference.*

* **Custom material** – reference a material from the [Materials](https://scenery.app/docs/editor/materials) section. Materials are created independently there, then referenced here per object.

---

Source page: Asset Properties

Source URL: https://scenery.app/docs/editor/asset-properties.md

# Asset Properties

Documentation source: [Asset Properties](https://scenery.app/docs/editor/asset-properties.md).

Select an object and open its **Properties** tab to set how it behaves: visibility, guidance, audio & haptics, gestures, and physics. (Visual styling lives in [Asset Appearances](https://scenery.app/docs/editor/asset-appearances); how it attaches to the world is [Anchors](https://scenery.app/docs/editor/anchors).)

## General

Documentation source: [Asset Properties](https://scenery.app/docs/editor/asset-properties.md).

* **Hide by default** – the object is added to the scene but starts hidden, to be revealed later by an action. Off by default (most content is meant to show on add). See [Toggle Object](https://scenery.app/docs/editor/actions/scene-content).
* **Discovery guidance** – an on-screen arrow that points the user toward this object. **None**, **Initial** (shows until the user has seen the object, then stops), or **Permanent** (keeps pointing). Useful for guiding people through larger, location-based scenes, or directing attention to something that appears behind them.

![The Properties tab with the General section expanded – Hide By Default and Discovery Guidance, above the Audio, Gestures, and Physics sections](https://scenery.app/docs/assets/general-hide-discovery.CEgFZP3N.jpg)
*The General section of the Properties tab.*

## Audio & haptics

Documentation source: [Asset Properties](https://scenery.app/docs/editor/asset-properties.md).

Attach a sound and a haptic to the object – best for **sound effects tied to the object** (for narration or background music, use the [audio actions](https://scenery.app/docs/editor/actions/audio-haptics) instead).

* **Audio** – the sound file, with a mode: **Spatial** (3D, positioned at the object – use a **mono** source so it spatializes well), **Non-spatial** (flat, no positioning), or **Ambient** (directional but with no distance falloff). Plus **volume** and **loop**. See [Play Audio](https://scenery.app/docs/editor/actions/audio-haptics#play-audio) for how the modes differ.
* **Haptics** – attach an **AHAP** haptic file (created in external tooling, ideally alongside the sound) so interactions also have a tactile response.

![The Audio and Haptics section – an attached audio file with Spatial mode, volume and loop, plus the haptics attachment slot](https://scenery.app/docs/assets/audio-haptics-panel.C3lT8Gmo.jpg)
*The Audio and Haptics section.*

* **Emission behavior** (advanced) – fine control over how the object radiates sound: **overall volume**; the balance of **direct vs. reverb level** (less reverb sounds closer and more intimate, more sits it deeper in the room); **directivity** (the radiation pattern – equal in all directions by default, or focused more in one direction); and **distance attenuation** (how quickly the sound fades as the listener moves away, with a rolloff strength to set the rate).

![The advanced Emission Behavior controls – overall volume, direct and reverb level, directivity, and distance attenuation](https://scenery.app/docs/assets/audio-emission-behavior.BzVsnI5J.jpg)
*The advanced Emission Behavior controls.*

The emission controls map to standard spatial-audio properties. They're available on iOS 18 / macOS 15 / visionOS, not on the web.

## Gestures

Documentation source: [Asset Properties](https://scenery.app/docs/editor/asset-properties.md).

Let users manipulate the object directly.

* **Swipe to offset** – swipe to nudge the object left/right (iOS and macOS).
* **Drag**, **Rotate**, **Resize** – each can be limited to specific **axes** (X/Y/Z) and given **min/max constraints** – e.g. lock to one axis with a range to make a 3D slider, or cap resize so the object can't be made too large.
* **On Release** (Advanced Settings) – what the object does when the user lets go:
  * **Stay in Place** – it stays where it was let go. This is the default.
  * **Reset to Start** – it animates back to where the gesture started. Good for "inspect but keep things tidy" (e.g. a product on a pedestal).
  * **Keep Momentum** – it carries the motion the gesture gave it, so a flick throws it and a slow release lets it drift. Needs a physics body set to dynamic (see [Physics](#physics) below). Two extra sliders appear: **Throw Strength** scales how much of the flick's speed carries over, **Spin Strength** the same for its spin.
* **Transform target** (advanced) – the gesture can drive **another object** instead of the one being touched.

![The Gestures section – Swipe to Offset, Drag, Rotate and Resize toggles with per-axis (X/Y/Z) limits and min/max scale fields](https://scenery.app/docs/assets/gestures-panel.ZwyYbaS8.jpg)
*The Gestures section, with per-axis Drag, Rotate, and Resize limits.*

::: tip Gestures adapt to the device
Drag, Rotate, and Resize work across iPhone, iPad, Mac, and Apple Vision Pro – the input adapts to each. On a touch screen you drag an object with one finger (two fingers moves it up and down), rotate it around the upright axis, and pinch to resize. On Apple Vision Pro the same gestures work directly in 3D space. The per-axis limits and min/max scale you set apply everywhere.
:::

## Physics

Documentation source: [Asset Properties](https://scenery.app/docs/editor/asset-properties.md).

Give the object a physics body so it can collide, fall, and be pushed. (Physics also needs scene-level setup – see [Physics actions](https://scenery.app/docs/editor/actions/physics).)

* **Mode**:
  * **Static** – doesn't move; other objects collide with it (floors, walls, surfaces to land on).
  * **Dynamic** – moves and responds to gravity, impulses, and collisions.
  * **Kinematic** – moved by you (script/animation) and affects other bodies, but isn't pushed around by them.
* **Collision shape** – Box, Sphere, or Convex (match it to the object's form).
* **Material** – default, or custom **friction** (how much the surface resists sliding – static friction to start moving, dynamic friction while already moving) and **restitution** (bounciness: 0 lands with a thud, higher values bounce more).
* **Mass** – default, or a custom mass per object (heavier objects are harder to push and fall the same but resist impulses more).
* **Dynamic body options** – whether it **reacts to gravity**, plus **linear** and **angular damping** (how quickly its movement and spin slow on their own, like drag – raise them to settle sooner).
* **Translation lock / Rotation lock** – constrain movement or rotation to specific axes.

![The Physics section – Mode set to Dynamic with the collision Shape menu open on Box, Sphere, Convex, plus Mass and Dynamic Body options](https://scenery.app/docs/assets/physics-mode.DsoBNrQy.jpg)
*Physics – Mode and the Collision Shape menu.*

![Lower Physics controls – Translation and Rotation locks, Mass Properties, gravity and damping, and the Material's friction and restitution](https://scenery.app/docs/assets/physics-dynamic-body.K2qmu_rd.jpg)
*Physics – Translation/Rotation locks, Mass, Dynamic Body options, and Material.*

::: tip Starting-point values
Rough starting points – tune to taste by previewing:

| Feel | Restitution (bounce) | Friction |
|---|---|---|
| Heavy, no bounce (clay, a metal thud) | 0 | 0.6 – 1.0 |
| Wood or plastic | 0.2 – 0.4 | 0.4 – 0.6 |
| Rubber ball | 0.6 – 0.8 | 0.8 – 1.0 |
| Ice or slippery | 0 – 0.2 | 0 – 0.1 |

**Damping:** keep **linear** and **angular damping** low (around 0 – 0.1) for free, lively motion; raise them (around 0.3 – 0.8) to make objects settle and stop quickly, as if moving through something thicker than air.
:::

Modes, shapes, locks, friction, restitution, mass, damping, and starting-point values are explained from standard rigid-body physics.

---

Source page: Materials

Source URL: https://scenery.app/docs/editor/materials.md

# Materials&#x20;

Documentation source: [Materials](https://scenery.app/docs/editor/materials.md).

Custom materials change how a surface looks. You create them in the **Materials** tab (next to Events), independently of any object, then **apply them per object**. Because they're standalone, one material can be reused across many objects.

## Creating and applying

Documentation source: [Materials](https://scenery.app/docs/editor/materials.md).

1. In the **Materials** tab, choose **New material** and pick a kind (below).
2. On an object, open **Appearance → Material overrides**, then **Add reference** to apply a material (or **create a new one** from there).
3. You can apply **several** materials to one object, and remove a reference without deleting the material itself.

**Material target** – when applied, you can target **First model**, **All models**, or **selected material slots**, so a material can affect only part of a model (e.g. just the rims of a car, or the glowing ring of a suit).

![Creating a new material – the kind picker with Unlit, Video, Occlusion, Custom Shaders, and MaterialX – Shader Graph (Preset and Physically Based are coming soon)](https://scenery.app/docs/assets/material-kind-picker.DEEt3vna.jpg)
*Creating a new material – the kind picker.*

## Material kinds

Documentation source: [Materials](https://scenery.app/docs/editor/materials.md).

* **Unlit** – doesn't respond to scene lighting (no metalness/roughness). Set a **texture** or a **colour tint**, optional **tone mapping** (matches output to the scene), and **opacity** (with an optional opacity texture).
* **Video** – a video texture. Pick the video asset, adjust its **audio**, and set **loop / autoplay**. Supports stereoscopic/spatial video and [HTTP Live Streaming (HLS)](https://developer.apple.com/documentation/HTTP-Live-Streaming) (via right-click → manual URL). With UV mapping it can cover a whole model or just part of it (e.g. a curved plane that wraps around the user).
* **Occlusion** – invisible; **hides whatever is rendered behind it**. Great for walk-in portals, or for blocking out real buildings so virtual objects can collide with them (give the occluder physics). Options: receive shadows, read depth. *(On Mac it previews as black; black renders as transparent in AR.)*
* **Custom Shaders** – your own **Metal**-based shaders. Load from the **asset library**, or use **live editing** (point at a shader file on your Mac and see edits instantly – a live shader preview). Options include the **surface shader function** (a dropdown when the file has several), a **geometry modifier function**, and a **lighting model** – **Lit** (realistic shading that responds to scene lighting), **Unlit** (ignores lighting, drawing at constant brightness from its colours and textures), or **Clearcoat** (Lit plus a glossy clear top layer, like car paint) – plus options to **inherit the original material's properties** and control **opacity**.
* **MaterialX – Shader Graph** – a ShaderGraph material authored in **Reality Composer Pro** and imported. Also supports asset-library or live-editing (a USDZ on your Mac).

![An Unlit material – base colour texture and tint, tone mapping, opacity, and the shared rendering options](https://scenery.app/docs/assets/unlit-material.CPAGqp6j.jpg)
*An Unlit material.*

![A Video material with the clip playing in the viewport – video asset, autoplay, loops, and audio volume](https://scenery.app/docs/assets/video-material.CSJfY4Il.jpg)
*A Video material, playing in the viewport.*

![An Occlusion material – invisible, with receive-shadows and read-depth options](https://scenery.app/docs/assets/occlusion-material.DYLCia1v.jpg)
*An Occlusion material.*

::: warning Platform support
**Custom Shaders** run on iOS and macOS only – they're hidden for visionOS experiences. For cross-platform shaders (including Vision Pro), use **MaterialX – Shader Graph**. (**Physically Based** and **Preset** material kinds are shown as *Coming Soon*.)
:::

A custom shader file can define a **surface shader** (sets a surface's colour and properties) and a **geometry modifier** (moves vertices). The editor's **surface shader function** and **geometry modifier function** pickers choose which function in the file to use.

**Example: a custom shader (surface shader + geometry modifier).** This draws a UV gradient as the emissive colour and adds a subtle, time-based wiggle.

```cpp
#include <metal_stdlib>
#include <RealityKit/RealityKit.h>
using namespace metal;

// Surface shader: sets the surface colour and properties.
[[stitchable]]
void helloWorldSurfaceShader(realitykit::surface_parameters params) {
    float2 uv = params.geometry().uv0();
    half3 color = half3(1.0 - uv.y, 0.2, uv.y); // gradient, top to bottom
    params.surface().set_emissive_color(color);
}

// Geometry modifier: moves vertices. Here, a subtle sine-wave wiggle over time.
[[stitchable]]
void helloWorldGeometryModifier(realitykit::geometry_parameters params) {
    float3 position = params.geometry().model_position();
    float3 normal = params.geometry().normal();
    float time = params.uniforms().time();

    float amplitude = 0.02; // wiggle strength
    float frequency = 6.0;  // wave density
    float speed = 4.0;      // animation speed
    float displacement = amplitude * sin(position.x * frequency + time * speed);
    params.geometry().set_model_position_offset(position + normal * displacement);
}
```

### Choosing a material inside a file

Documentation source: [Materials](https://scenery.app/docs/editor/materials.md).

A single asset (a USDZ or ShaderGraph file) can hold several materials. Pick the one you want by its **Path** – the material prim's path inside the file (e.g. `/Root/MyMaterial`). When Scenery can list the file's materials you choose from a dropdown; otherwise paste the path, which you can copy from Reality Composer Pro via **Copy Object Path**.

## Shared rendering options

Documentation source: [Materials](https://scenery.app/docs/editor/materials.md).

Most material kinds share these:

* **Render as wireframe** – draw only the mesh's edges.
* **Read depth** – when on, the material does a depth test, so it's hidden behind closer depth-writing objects; when off, it always draws regardless of what's in front (draw-order groups still apply).
* **Write depth** – the material writes to the depth buffer, so other objects test against it.
* **Face culling** – each surface of a model has an **outer** and an **inner** side, and only one is drawn (the other is left invisible, which saves work). **Back** (default) draws the **outer** side – right for solid objects, whose insides you never see. **Front** draws the **inner** side instead, so the object looks hollow or inside-out. **None** draws **both** sides – use it for thin, flat things like a plane or sheet that should be visible from either side.

The five usable kinds are **Unlit**, **Video**, **Occlusion**, **Custom Shaders**, and **MaterialX**. **PBR** and **Preset** are Coming Soon, and **Custom Shaders** isn't available on visionOS.

**Lit** uses physically-based shading; **Unlit** applies no lighting; **Clearcoat** adds a clearcoat layer over PBR.

---

Source page: Post-FX

Source URL: https://scenery.app/docs/editor/post-fx.md

# Post-FX&#x20;

Documentation source: [Post-FX](https://scenery.app/docs/editor/post-fx.md).

Post-processing effects change the look of the whole rendered scene (the camera view). Like materials, they live in their own **Post-FX** panel, independent of the scene, and are applied separately.

::: warning Platform support
Post-FX currently works on **iOS and macOS** only – not on the web or Apple Vision Pro.
:::

## Creating an effect

Documentation source: [Post-FX](https://scenery.app/docs/editor/post-fx.md).

In the **Post-FX** panel, choose **New effect**, then **Filter** or **Shader**. (A **Preset** kind is shown as *Coming Soon*.)

![The Post-FX panel's empty state with New effect, choosing between Filter and Shader](https://scenery.app/docs/assets/new-effect-picker.w-KYNMoy.jpg)
*The Post-FX panel – New Effect, then Filter or Shader.*

### Filter

Documentation source: [Post-FX](https://scenery.app/docs/editor/post-fx.md).

A predefined effect chosen from a built-in list – bloom, blur, distortion, dot screen, photo effects, pixelate, thermal, and more. Most filters expose **parameters** (e.g. a dot screen's angle, width, sharpness). You can **stack several filters** within one effect (e.g. dot screen + bloom).

![A Dot Screen filter applied to the scene, with its angle, width, and sharpness parameters and the post-effect preview toggle](https://scenery.app/docs/assets/dot-screen-filter-applied.DilsEVCC.jpg)
*A Dot Screen Filter applied, with its parameters and the preview toggle.*

### Shader

Documentation source: [Post-FX](https://scenery.app/docs/editor/post-fx.md).

A custom **Metal**-based effect. Load from the **asset library** or use **live editing** (a shader file on your Mac, updated live). A shader can contain multiple **kernel functions** (e.g. a rain effect and an underwater effect in one file). You can also bind **object transforms** (a scene object's transform is passed into the shader) and use the scene's **depth texture**.

![A shader effect – the asset library source, a kernel function selection, object transform bindings, and the depth-texture toggle](https://scenery.app/docs/assets/shader-kernel-and-bindings.eG6oKMOP.jpg)
*A Shader effect – kernel function, object transform bindings, and depth texture.*

A post-processing shader is a compute **kernel** that reads the rendered frame (`inColor`) and writes a new one (`outColor`). One file can hold several kernels; the editor's **kernel function** picker chooses which to run.

**Example: a post-processing kernel.** This minimal kernel blends the frame with a UV gradient – a good starting point for porting effects from [Shadertoy](https://www.shadertoy.com) or [The Book of Shaders](https://thebookofshaders.com).

```cpp
#include <metal_stdlib>
using namespace metal;

[[kernel]]
void helloWorldPostProcessing(
    texture2d<half, access::read> inColor [[texture(0)]],
    texture2d<half, access::write> outColor [[texture(1)]],
    uint2 gid [[thread_position_in_grid]]
) {
    float2 resolution = float2(inColor.get_width(), inColor.get_height());
    float2 uv = float2(gid) / resolution;
    uv.y = 1 - uv.y; // flip y to match the texture coordinate system

    // stay within the frame bounds
    if (gid.x >= inColor.get_width() || gid.y >= inColor.get_height()) {
        return;
    }

    half4 fragmentColor = inColor.read(gid);
    half4 gradient = half4(uv.x, uv.y, 0, 1);
    half4 mixedColor = mix(gradient, fragmentColor, 0.5);

    outColor.write(mixedColor, gid);
}
```

## Previewing and applying

Documentation source: [Post-FX](https://scenery.app/docs/editor/post-fx.md).

* **Enable post-effect preview** – toggle this in the panel to see effects while you tweak them, without committing them to the scene.
* **Apply to the whole scene** – Scene settings → Post-processing effects → **custom effects**.
* **Apply dynamically** – the [Set Post-Processing Effect](https://scenery.app/docs/editor/actions/experience) action turns an effect on/off on a trigger. Handy for changing the whole visual style on user input (e.g. a different era's look per object the user picks).

Filter and Shader are the two author-selectable kinds; Preset (built-in) is Coming Soon; all post-FX is hidden for visionOS experiences.

---

Source page: Environments & Lighting

Source URL: https://scenery.app/docs/editor/environments-lighting.md

# Environments & Lighting

Documentation source: [Environments & Lighting](https://scenery.app/docs/editor/environments-lighting.md).

The **background & lighting** button (in the viewport) controls how your scene is lit and what sits behind it. These are creation-time controls; some pair with **Scene settings → Lighting & environment**.

## Lighting

Documentation source: [Environments & Lighting](https://scenery.app/docs/editor/environments-lighting.md).

How virtual content is lit:

* **Custom** (default) – on capable devices, the device captures the **real-world lighting** (an HDR environment light map) and applies it to objects with **PBR (physically based)** materials. Content then feels grounded in the space, and looks different depending on where and when the experience is opened. Great for realism.
* **Presets** – pick a fixed lighting environment (indoor, gallery, workshop, urban, street, plaza, …) when you want **full control** over the look regardless of the user's surroundings (e.g. an art-led experience).

Also here: a **floor grid** toggle (a creation aid) and **lighting exposure** (brighten / darken the whole scene).

![The Lighting panel – Classic and Custom, indoor presets, the floor grid toggle, lighting exposure, and the acoustic environment](https://scenery.app/docs/assets/lighting-panel.By3MgH_v.jpg)
*The Lighting panel.*

![More lighting presets – the Urban set (Park, Square, Plaza, Street)](https://scenery.app/docs/assets/lighting-presets.BjjxIBMz.jpg)
*More lighting presets – the Urban set.*

## Background

Documentation source: [Environments & Lighting](https://scenery.app/docs/editor/environments-lighting.md).

By default the real camera feed shows behind your content. Set a **background** (a 360° image, from a preset or your own) to replace the camera feed – turning an AR-tracked scene into a more **VR-like** space the user can still walk around in.

To actually show a background, set the scene's **immersion mode** (Scene settings → Lighting & environment):

* **Mixed (AR)** – default; content over the real world.
* **Progressive** – on Apple Vision Pro, the user can dial the virtual environment in and out.
* **Full VR** – uses the background image as a full virtual environment (still with AR tracking, so the user can move around).

**Environment texturing** (same section) is on by default (use real-world lighting). Turn it off to rely on your chosen custom light map instead.

![A background applied to the scene, with the Scene settings immersion mode and environment texturing controls](https://scenery.app/docs/assets/scene-lighting-rendering.MGOYMVsv.jpg)
*A background applied, with the Lighting & Rendering controls.*

## Acoustic environment

Documentation source: [Environments & Lighting](https://scenery.app/docs/editor/environments-lighting.md).

Sets the reverb used for spatial audio – Medium room (dry), Large room, Outside, Very large room, Concert hall, etc. Use the **tooltips** (the small markers next to options, found throughout the editor) for a description of each.

![The acoustic environment menu – reverb presets from Concert Hall to Anechoic](https://scenery.app/docs/assets/acoustic-environment.BOyWFI6F.jpg)
*The Acoustic Environment menu.*

Immersion mode (Mixed AR / Progressive / Full VR) and environment texturing match the editor's Lighting & Rendering controls.

