# Experience Types Anchors and Tracking

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: stuck to poster; marker; floating; drifting; not appearing; wrong size; table; floor; wall; face; location; GPS; placement.

## Contents

- Tracking Contexts
- Anchors
- Placement & Localization

---

Source page: Tracking Contexts

Source URL: https://scenery.app/docs/editor/tracking-contexts.md

# Tracking Contexts

Documentation source: [Tracking Contexts](https://scenery.app/docs/editor/tracking-contexts.md).

A **tracking context** decides how an experience understands and anchors to the world – whether it tracks the space around the user, a real-world location, a printed image, or a face. You choose it once, right at the start.

::: warning Choose it carefully – it's permanent
The context is set when you create the experience and **can't be changed afterwards**. Pick the right one before you build.
:::

Each context has its own [device compatibility](https://scenery.app/docs/guide/compatibility) – the picker shows which platforms support it as you select.

![The Set Experience Context picker – World-Tracking, Geo-Tracking, Room Bound (coming soon), Playspace, Image-Tracking, Face-Tracking, and Body-Tracking (coming soon), with the compatibility row at the bottom](https://scenery.app/docs/assets/context-picker.CXnwKqpn.jpg)
*The Set Experience Context picker, with the compatibility row at the bottom.*

## World-Tracking (default)

Documentation source: [Tracking Contexts](https://scenery.app/docs/editor/tracking-contexts.md).

The most flexible and versatile context, and the right choice for most experiences. It uses full six-degrees-of-freedom tracking and the rear camera to understand the space around the user – floors, walls, and surfaces. When someone opens a world-tracked experience, they're prompted to **place the scene** wherever they are, so the scene's origin is set by the user.

Choose World-Tracking unless you have a specific reason not to – you can build almost anything with it, and it's the most broadly compatible.

## Geo-Tracking

Documentation source: [Tracking Contexts](https://scenery.app/docs/editor/tracking-contexts.md).

Anchor a whole experience, or individual objects, to a specific **outdoor location** in the real world. Instead of placing the scene by hand, content appears pinned to its real coordinates when the user arrives. You start from a **3D representation of your chosen location** and place objects directly onto it, so you can see how they'll look on-site.

Geo-Tracking uses a **Visual Positioning System (VPS)** – far more accurate than GPS, which on its own can drift enough to make content jump around. VPS localizes the user (and the virtual content) against real-world map data, so content can sit precisely on a building facade or in a plaza.

* On **Apple Vision Pro**, a geo experience is shown as a **miniature diorama** – a 3D model of the location with all your content inside it, explorable from a bird's-eye view. Handy for previewing a location-based experience without being on-site.
* **App Clip** distribution (instant, no install) uses **Apple's** location-based positioning. The Google-based option is too large to fit in an instant App Clip, so choose the Apple method if no-install delivery matters. See [Publishing & Sharing](https://scenery.app/docs/guide/publishing).

**What a geo experience needs.** It runs **outdoors** – the map data behind VPS covers public streets and open spaces, not building interiors. The viewer's device needs an **internet connection** while localizing, because the map data is fetched at that moment rather than shipped with the experience, and **location access with Precise Location switched on**. Location access is granted per app, so the full app and the App Clip are asked for it separately.

**Check that your location is covered before you build.** Coverage is finer-grained than a country, or even a city – two streets apart can differ. When you pick the location for a geo experience, the picker reports availability for that exact coordinate, one line per positioning system, so you can see what your site supports before you commit to it. *(currently shown on iPad)*

If your location isn't covered, [Placement & Localization](https://scenery.app/docs/editor/placement#localization) has the alternatives: marker-based and manual localization, and the localization markers that act as a fallback under Automatic.

Geo-Tracking currently localizes using map data from **Google and Apple**. **Custom VPS** – localizing against your own scanned environment – is in the works, which will help indoor and private-location experiences (where public map data isn't available) and extend geo to the web.

![Geo-Tracking selected in the context picker; the Web platform shows as not yet compatible](https://scenery.app/docs/assets/context-picker-geo.Cp52vIY0.jpg)
*Geo-Tracking selected; the compatibility row updates per context (Web shows not yet supported here).*

## Image-Tracking

Documentation source: [Tracking Contexts](https://scenery.app/docs/editor/tracking-contexts.md).

Build an experience that lives **on a single image** – a poster, a postcard, an augmented business card. The whole scene anchors to that image.

Choose Image-Tracking when the experience genuinely revolves around one image and doesn't need to understand the floor or surfaces around the user. Because the system only has to find the image rather than map the whole space, tracking is **more stable and reliable**.

::: tip Image anchors vs. the Image-Tracking context
You don't need this context just to put *some* content on an image. Within a World- or Geo-Tracking experience, you can give an **image anchor** to individual objects (e.g. augment two posters in a walk-around scene). Use the Image-Tracking *context* only when the entire experience is built around one image. See [Anchors](https://scenery.app/docs/editor/anchors#image).
:::

## Face-Tracking

Documentation source: [Tracking Contexts](https://scenery.app/docs/editor/tracking-contexts.md).

Anchor an experience to the user's **face**, using the front camera. Good for virtual masks, accessories, and effects that follow the face.

Face-Tracking gives you the face as a tracking anchor – the interactive layer is up to you (for example, drive a mask with [blend-shape animation](https://scenery.app/docs/editor/actions/animations-appearance#update-blendshape-weights)). It doesn't include higher-level detection such as pupil or eye-movement triggers, so expect to build a little more of the interactivity yourself.

## Playspace

Documentation source: [Tracking Contexts](https://scenery.app/docs/editor/tracking-contexts.md).

Define a **fixed space** in which the experience takes place – a carryover from walk-around scavenger-hunt experiences. Like World-Tracking, the user still places it manually. In most cases we recommend **World-Tracking** instead, as it's more versatile and broadly compatible.

## Coming soon

Documentation source: [Tracking Contexts](https://scenery.app/docs/editor/tracking-contexts.md).

* **Room Bound** – scan a room and lay out content along its walls, ceiling, and floor, with semantic understanding of the space.
* **Body-Tracking** – attach objects to hands, legs, and other body parts.

::: info Element tracking is separate
Some tracking happens at the **object** level, not the experience level – for example, anchoring an object to a **hand** on Apple Vision Pro. That's set per object (see [Anchors](https://scenery.app/docs/editor/anchors)), not chosen here as the experience context, which is why hand tracking doesn't appear in this list.
:::

Seven contexts exist; **Room Bound** and **Body-Tracking** are shown as Coming Soon. World-Tracking is the default selection in the picker.

---

Source page: Anchors

Source URL: https://scenery.app/docs/editor/anchors.md

# Anchors

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

An **anchor** decides *where and how* your content attaches to the real world – pinned to a spot in front of the user, snapped to a detected table, following the camera, riding along on a hand, or appearing on top of a recognized image.

Anchoring is set on the **object** you select – the root node in the hierarchy, which carries the anchor and shows its current **Anchor Type**. An object holds its visual content inside it: a 3D model, visual media, a UI panel, and so on. Select the **object** (not the content nested inside it) and the **Anchoring** panel appears. To anchor several objects together, group them into a **Container** and anchor that.

::: tip Name everything you add
Give clear names to your objects, containers, and the models inside them. As scenes grow, good names are what keep everything findable and easy to reference.
:::

## Choosing an anchor

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

The available anchor types depend on the experience's **tracking context** (chosen when you create the experience). Select a context below to see which anchors it offers:

![The Anchor Type menu in a world-tracking experience](https://scenery.app/docs/assets/anchor-types.C_RGTzsd.jpg)
*The Anchor Type menu in a world-tracking experience.*

(App Clip Code appears greyed-out – it isn't author-selectable. **Screen Space** appears only for **User Interface** elements – see [Screen Space](#screen-space).)

::: tip Placing objects well

* **Anchor first, then nudge.** An anchor sets an object's **base position**. To fine-tune from there, don't fight the anchor – use the object's **Transform** (position, rotation, scale) to nudge it into place on top of its anchor.
* **Nudge the object, not its content.** The object is the root that carries the anchor; its visual content – a 3D model, media, or UI – sits inside it. To fine-tune placement, move the **object** itself rather than the content within it, since tracking comes from the object's position.
  :::

## Position

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

The default. The object has a fixed position in the scene. Drag it with the gizmo, or type the X / Y / Z values directly.

## Scene Object

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

Anchor an object to **another object in the scene**, so it tracks that object instead of having a position of its own.

* **Target** – the object to follow.
* **Lock translation / rotation / scale** – independently per axis (X, Y, Z).
* **Offset** – a transform applied relative to the target.
* **Update continuously** – when on, it keeps following the target as it moves; when off, it snaps once.
* **Transition smoothing** – see [below](#transition-smoothing).

## Horizontal & Vertical Plane

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

Place content on a real surface the device detects. Pick **Horizontal Plane** or **Vertical Plane**, and the options adapt.

![Horizontal Plane anchor with a surface type and minimum size](https://scenery.app/docs/assets/plane-classification.CZ3gsRXS.jpg)
*A Horizontal Plane anchor – surface type and minimum size.*

### Surface type

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

Instead of "any surface," require a specific *kind* of surface. The choices depend on orientation:

| Orientation | Surface types |
|---|---|
| Horizontal | Floor, Ceiling, Table, Seat |
| Vertical | Wall, Window, Door |

Surface types let content fit its setting – a character that only appears on a **Table**, signage that only appears on a **Wall**. Content with a surface type set won't appear until the device finds a matching surface.

**Surface types need a capable device.** Recognizing *what* a surface is (table vs. floor vs. wall) requires an iPhone or iPad from **2018 or later** (A12 chip or newer). On older devices the surface type can't be determined. *(A depth sensor further improves placement accuracy but is not what enables surface types.)*

### Minimum size

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

Require the surface to be at least a certain size (in metres) before content appears. For example, a scene meant to stand on a **tabletop** can require a minimum table size, so it only places on a surface actually big enough to hold it.

On iPhone and iPad, **Window** and **Door** behave like **Wall** – there is no separate
classification for them. Apple Vision Pro has both, but only uses them where the room reads
that way: a plain flush door in a plain wall is normally reported as part of the wall.

### Where it lands

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

Content appears on the surface the viewer is **pointing at**, so it lands where they are looking rather than on whichever surface the device happened to find first. Point at the near table and it goes there; point at the far one and it goes there instead.

This matters because a detected surface is only as big as the part that has been scanned. A wall the device has seen 70 cm of is a 70 cm surface as far as it knows, and choosing by size or distance would keep landing content on fragments. Where the viewer aims doesn't have that problem.

Two rules follow from the kind of surface:

* **On a wall**, the height is the viewer's own, or higher if they aimed higher. Glancing at the skirting board doesn't put a picture on the floor.
* **On a ceiling**, content hangs into the room. An object built standing on a table hangs from a ceiling the same way a lamp does.

## Camera vs. Current Point of View

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

These look similar but behave differently:

* **Camera** – content stays **attached to the camera and follows it continuously**. Good for things that should stay in view, like a heads-up element or a companion character. You can give it an offset.
* **Current Point of View** – content is placed at a **one-time snapshot** of where the user is looking *at that moment*, then stays put. You can set an offset and reset its rotation.

**Reset rotation** makes the content sit upright, facing the user, ignoring any head tilt at the moment it's placed – so the content isn't skewed by how the user happened to be looking when it appeared.

## Hand

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

Anchor content to the user's hand – a character that follows it, a panel, an object you can move or throw.

![Hand anchor options – chirality, transition smoothing, discovery hint](https://scenery.app/docs/assets/hand.wKSRSeKu.jpg)
*Hand anchor options.*

::: warning Platform support
Hand anchoring is **currently** available on Apple Vision Pro only (shown as "Limited Compatibility" in the editor). Support may expand to other platforms in future.
:::

* **Hand** – Left or Right.
* **Joint** – one of: Forearm Arm, Wrist, Thumb Tip, Index Finger Tip, Middle Finger Tip, Ring Finger Tip, Little Finger Tip.
* **Transition smoothing** – see [below](#transition-smoothing).
* **Provides discovery hint** – when on, prompts the user to look at their hand as content appears. Off by default.

## Image

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

Make content appear on top of a recognized image – a poster, a postcard, a sign, a QR code. You can combine an image anchor with other anchoring in the same experience: a walk-around scene that *also* augments specific posters when they're seen.

![Image anchor options – detection image, orientation, physical width](https://scenery.app/docs/assets/image.BrL0UrhV.jpg)
*Image anchor options.*

::: warning Measure the physical width accurately
The **physical width** tells the system how large the image is in the real world, and it uses that to judge distance – so an accurate value is **crucial**. Even a small error and everything you place lands at the wrong distance and scale. Measure the printed **image area itself**, not any surrounding border or mounting plate.
:::

* **Detection image** – the reference image, from the asset library.
* **Orientation** – Horizontal (flat, e.g. on a table) or Vertical (on a wall, content faces outward). The marker preview updates to match.
* **Physical width** – the real-world width of the image, in **centimetres** (see the warning above).
* **Provides discovery hint** – prompts the user to look for the image.
* **Tracks continuously** – when on, content keeps following the image as it moves; when off, position is set once on first detection.
* **Hide if tracking lost** – when on, content disappears if the image goes out of view; when off, it stays where it was last seen.

::: tip Choosing and printing a detection image

* **Detail everywhere, high contrast.** Spread visual detail across the whole image, not one corner. Avoid plain repeating or symmetric patterns (grids, checkerboards) – they confuse recognition. Asymmetric artwork also keeps placed content from flipping the wrong way round. Detailed posters, signs, and QR codes all work well (a QR can double as the way into the experience).
* **Matte, never glossy, and dead flat.** Reflections and glare are the biggest enemy, especially outdoors; a curved or bent surface throws placement off. For a lasting outdoor marker a rigid material like a metal plate won't warp or shrink the way paper can.
* **Size sets the range.** Bigger images detect from farther away – a small (~5 cm) marker only works up close, so print large (A3 or bigger) to place content while standing back. Always test the finished, printed marker on-site, not just the design on screen.
  :::

## Per-device anchoring (Device Configuration)

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

The same content often works best in different ways on different devices. Per-device anchoring exists for two main reasons:

* **Better presentation per device.** A user-interface panel placed in 3D space can work beautifully on a headset, while on a phone the same panel may read better as a flat **Screen Space** overlay. It's case-dependent – give each device whichever placement suits it best.
* **Working around device-limited anchors.** Some anchors are only available on certain devices – **Hand** anchoring is currently headset-only, for instance. Per-device anchoring lets you use it where it exists and fall back to something else (e.g. **Position**) where it doesn't.

The **Device Configuration** picker lets a single object use a **different anchor per kind of device**:

![The Device Configuration picker – Default, Handheld, Spatial, Desktop, Fallback](https://scenery.app/docs/assets/device-configuration.mATAL4yx.jpg)
*The Device Configuration picker.*

* **Default** – the anchor used everywhere, unless overridden below.
* **Handheld** – phones and tablets.
* **Spatial** – headsets (Apple Vision Pro and similar).
* **Desktop** – Mac.

For each device category you can choose a different anchor, or **Hidden** to leave the object out entirely on that kind of device. A common pattern: **Spatial → Hand**, **Handheld → Position** – so the same object is hand-attached on a headset and placed in front of the user on a phone.

* **Fallback** – a fallback position used only when none of the above can be resolved on the running device (for example, the chosen anchor isn't supported there). It keeps content from disappearing by giving it a sensible default placement.

## Screen Space

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

Available **only for User Interface elements** (a UI panel with no nested children). Instead of placing the panel in 3D space, Screen Space pins it as a **non-spatial overlay fixed to the screen** – a 2D HUD that stays in place as the camera moves. Use it for on-screen controls, titles, and other interface that shouldn't live in the world.

* **Alignment** – where on screen the panel sits: centre, an edge, or a corner.
* **Edge insets** – padding from the screen edges.
* **Respects safe area** – keep clear of the notch / home indicator.

Because it isn't a 3D anchor, the spatial controls (gizmo, orientation cube) are hidden while a screen-space UI is selected.

On Apple Vision Pro there is no screen to pin to, so a screen-space panel sits in a layer about 60 cm in front of the viewer that follows their head. How the panel's size and material behave on screen is covered in [Panels](https://scenery.app/docs/editor/user-interface/panels).

### Touches behind the panel

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

A screen-space panel sits above the scene, so it decides what reaches the camera behind it. The panel's **Material** makes that call:

* **Transparent** – nothing is painted, so taps and drags that miss a control pass straight through to the scene. Use it for a HUD that frames the view without capturing it – a few buttons over a live camera the user can still move.
* **System** or **Solid** – the panel is a visible surface, so it absorbs those touches, the way a card or sheet does.

Controls always receive their own taps either way. Labels, images and shapes only capture a touch when you've given them an event – otherwise they're treated as decoration and let it through.

## Transition smoothing

Documentation source: [Anchors](https://scenery.app/docs/editor/anchors.md).

Several anchors (Scene Object, Hand) offer **transition smoothing**, shown as a **percentage (0–100%)**. At **0%**, content sticks rigidly to its target. As you raise it, content follows with a gentle lag – a more natural, "lazy" follow. Tune it to taste.

---

Source page: Placement & Localization

Source URL: https://scenery.app/docs/editor/placement.md

# Placement & Localization

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

An experience needs a starting point in the real world. How it gets one depends on the experience's [tracking context](https://scenery.app/docs/editor/tracking-contexts): a world-tracked experience is **placed**, a geo-tracked one is **localized** against the map.

The experience is placed or localized once, when it opens. Every later scene continues in the same place, so viewers never have to place it again when a scene changes. The setting is shared by every scene: you can change it from any scene, with nothing selected, and it applies to the whole experience.

## Placement

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

For world-tracked scenes. Open **Scene Settings › Placement**.

### Method

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

* **Viewer Places The Scene** – the default. A placement indicator follows the viewer's aim and
  they tap to confirm. The most flexible choice, and the one to keep unless you have a reason not
  to.
* **Place Automatically** – the scene appears by itself as soon as a suitable surface is found. No
  tap, no placement UI.
* **Marker-Based** – the scene appears on a printed image the viewer points their camera at, in the
  same real spot every time and in the same spot on every device that finds it.
* **[VPS Map](#vps-map)**  – the scene appears at a fixed spot in a place you scanned
  beforehand, found through the camera.
* **Start Without Placing** – no placement step at all. The scene starts at the viewer's position.
  Choose this when a script positions the content itself.

### Surface

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

For the two placing methods, the surface the scene targets.

* **Surface** – **Horizontal Plane** for floors and tables, **Vertical Plane** for walls. Only
  surfaces of this orientation are offered to the viewer or found automatically.
* **Classification** – narrow it further to a kind of surface: Floor, Ceiling, Table or Seat for
  horizontal, Wall, Window or Door for vertical. **Any** accepts whatever the orientation allows.

**Placement moves the scene and turns it to face the surface. It never tilts it.** Content you
compose standing upright in the editor arrives standing upright, facing the viewer, whether the
scene lands on a floor or on a wall. A painting authored facing you hangs facing you, and it hangs
level however the viewer was holding their device when it was placed.

The two methods treat the classification differently:

| | |
|---|---|
| Viewer Places The Scene | A requirement. The placement indicator only settles on a matching surface, which shows the viewer where the scene is meant to go. |
| Place Automatically | A preference. Once a matching surface has been found the scene waits for it and appears there when the viewer looks at it. Only when none turns up does it accept any surface of the chosen orientation, so the experience always starts. |

**Floor is the exception when placing automatically.** It is the one surface every experience can
rely on, so it is never held out for: the scene is placed ahead of the viewer at floor height as
soon as a floor is found, and the lowest surface stands in where the kind can't be determined.

When the viewer places the scene the floor is a requirement like any other surface, because the
indicator can't hold an experience up – the viewer can always point at the floor. Where the kind of
surface can't be determined, the lowest one stands in there too.

::: warning A surface's kind is not guaranteed twice
Whether a device calls a chair a seat or a table can differ between one run and the next, and
resetting tracking re-decides it. A scene tied to a specific kind of surface may therefore land
somewhere else on a later run. If the scene only needs *a* horizontal surface, leaving Classification
at **Any** avoids the question entirely.
:::

::: tip A non-floor placement locates the floor first
Scenes keep a floor for physics and shadows even when their content sits on a wall or a table, so
the floor is found before placement starts – one extra step for the viewer. If the scene doesn't
need one, turn **Floor mesh** off in
[Scene Settings › Meshing & occlusion](https://scenery.app/docs/editor/scene-settings#meshing-occlusion) and placement
begins straight away. Only a placement that lands on the floor itself skips the step, since it
establishes the floor as it goes.
:::

::: info Window and Door fall back to Wall
Whether a device recognizes a door as a door depends on the door. A plain flush door in a plain
wall is usually reported as part of that wall, and on iPhone and iPad there is no separate door
classification at all. So both choices accept the wall behind them: on Apple Vision Pro a real door
is still preferred where the room reports one, and everywhere else the scene places on the wall
rather than waiting for a door that is never announced.

This matters most for **Place Automatically**, which works down the list in order and only settles
for the wall once no door has turned up. When the **viewer** places the scene the indicator settles
on either straight away, since it has no reason to make them wait for a distinction their room may
never report.
:::

::: tip Recognizing a surface needs a capable device
Telling a table from a floor from a wall needs an iPhone or iPad from 2018 or later (A12 chip or
newer), and isn't available on the web. Where the kind of surface can't be determined, any surface
of the chosen orientation is used.
:::

### Minimum Dimensions

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

For **Place Automatically** on a horizontal surface: how much room the scene needs, in metres
across the surface.

A table smaller than this isn't used, and the scene is kept far enough from its edges to fit – so a
glance at the near edge doesn't leave content hanging off it. On the floor, which has no meaningful
edges, it sets how far ahead of the viewer the scene starts instead.

Leave it at zero when the scene has no particular space requirement. It doesn't apply to walls: a
wall's measured size reflects how much of it the viewer has scanned rather than how big it is, so
it isn't something to hold a scene against.

### Markers

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

For **Marker-Based** only. Add the printed image the scene is anchored to, with an accurate
**physical width** in centimetres, and a **position** and **heading** to offset the scene relative
to the image.

Add more than one marker to re-localize across a larger space – they cycle in the coaching overlay.

::: warning Range limits
A marker works well near where it was scanned; as the viewer walks 50–100 m away the device
struggles to remember it and content can drift. Use markers for anchored, in-place scenes rather
than long walk-arounds.
:::

See [Choosing and printing a detection image](https://scenery.app/docs/editor/anchors#image) for what makes an image
recognizable – the same advice applies to markers.

## VPS Map

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

**VPS Map**   puts the scene at a fixed spot in a place you scanned beforehand. The viewer's device recognizes the place through the camera, and the scene appears where you put it, so viewers on different devices and visits can find it in the same spot. Choose it as the **Method**, then work down the rows in order: each one becomes available once the one above it is set.

### Creating a map

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

A map is a scan of the place, made with MultiSet before you author the scene:

* Scan the place with the [MultiSet app](https://apps.apple.com/app/id6737130008) on iPhone or iPad. The app uploads the scan to your MultiSet account, which turns it into a map.
* [Mapping Planning](https://docs.multiset.ai/fundamentals/maps/mapping-planning) shows how to walk a space, with a video.
* [Mapping Instruction](https://docs.multiset.ai/fundamentals/maps/mapping-instruction) covers distance, speed and which surfaces localize well, also with a video, and lists the supported devices.

Textured walls, furniture and signage make a map easy to recognize; blank walls, glass and mirrors make it harder. Scan the area where viewers will stand and look, since that is what their devices compare against.

### Account

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

Pick the visual positioning account that owns the map, or choose **Connect MultiSet Account…** to add one (MultiSet is currently the only provider). It asks for a **Client ID** and **Client Secret**: in the MultiSet Developer Portal, open **Credentials**, choose **Create New**, give it only the **Query** scope, and copy both values right away, since the portal shows the secret only once ([MultiSet: Credentials](https://docs.multiset.ai/fundamentals/credentials)). Viewers never see your credential. **Account Settings…** manages the connected account. An account a teammate connected shows who connected it, and only they can change it.

### Map

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

Pick one of the account's maps by name. For a map set, or a map the list doesn't show, choose **Enter Code…** and paste its code. Under the picker the editor shows the map's code and its processing status. Once the map is ready its scan appears in the viewport, so you can place content exactly where it belongs. **Show Scanned Map** and its opacity in the Editing Environment options control how the scan is drawn. In AR viewers see the real place instead; on a Mac, where there is no camera, they see the scene inside the scan. To keep a place's scan off Mac, leave Mac out of the experience's [Platforms](https://scenery.app/docs/editor/experience-settings).

### Aligning the map

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

A map's own origin is wherever its scan started, usually in mid-air and turned at random. **Align Map…** opens a mode where you drag the scan until its floor sits on the grid and it faces the way you want, while the scene stays where it is. **Snap Floor to Zero** finds the scan's floor and moves it onto the grid for you, **Reset** puts the scan back on the map's origin, and **Done** stores the alignment as one undo step. The mode opens by itself the first time a newly picked map's scan has loaded. Content already in the experience moves with the map in AR when you change the alignment, so it's easiest to align first. Viewers' devices take the aligned scene origin as the floor, for shadows and for objects resting on the ground; a map that was never aligned makes them look for the floor themselves after the place is found, so the editor reminds you to align it.

### Coaching illustration

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

Under the map, choose what the viewer is shown while their device looks for the place:

* **Any Place** – a field of dots, the default, for any kind of place.
* **Room** – a room seen from inside, for places indoors.
* **Building** – buildings, for places outdoors.

### Advanced settings

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

Under the map, two settings tune how viewers' devices find the place. Balanced, the default for both, suits most places.

* **Search Effort** – how hard viewers' devices look for the place. **Quick** gives up sooner and costs less; **Thorough** searches more deeply and keeps trying longer, for dim, large or hard places.
* **Confirmation** – how sure the app must be before content appears. **Careful** always confirms from a second spot, for places where several spots look the same, such as matching corridors or shelf rows; **Fast** shows content sooner where the place looks distinctive.

### Start spot

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

In the **Align Map** mode, **Set Start Spot** and then click or tap the scan where viewers usually start, for example an entrance. A small marker shows the spot while you align, and **Clear** removes it. Like the alignment, the start spot is stored when you press **Done**, and **Cancel** discards it. A start spot is optional. It narrows the search to the area around it, which finds the place faster and keeps a similar-looking spot elsewhere in the map from being mistaken for it. It belongs to the map, so picking another map removes it.

### What viewers see

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

While their device looks for the place, viewers see the hint with a short instruction to move their device slowly; the scene appears once the place is found. If a search fails it offers **Try Again**. When it can't find the place, markers you set up for the scene take over; without markers, viewers are told the place couldn't be found. They can't place a VPS scene by hand, since its content belongs where the map is.

VPS Map currently works on iPhone and iPad. On Apple Vision Pro the scene uses its markers, or the viewer places it.

## Localization

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

For geo-tracked scenes. Open **Scene Settings › Localization**.

### Method

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

* **Automatic** – visual localization (VPS) where it's available, which is the most precise option.
* **Marker-Based** – localize from a printed marker instead.
* **Manual** – the viewer positions themselves on a map and sets their heading.

Choose Marker-Based or Manual for places VPS doesn't cover: indoors, or somewhere the map data
doesn't reach.

### Visual Positioning Preference (VPS)

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

Shown for **Automatic**. By default Scenery picks whichever positioning system is available at the
viewer's location. If one gives better results where your experience lives, name it:

* **Automatic**
* **Apple (ARKit Location Anchors)**
* **Google (ARCore Geospatial API)**

::: info App Clips use Apple's positioning
The Google option is too large to fit in an instant App Clip, so choose Apple's if no-install
delivery matters. See [Publishing & Sharing](https://scenery.app/docs/guide/publishing).
:::

### Localization markers

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

Shown for **Automatic** and **Marker-Based**, because they serve a different purpose in each:

* Under **Marker-Based** the scene is anchored to them.
* Under **Automatic** they're a fallback – if visual localization can't place the viewer, the
  experience looks for a marker instead.

Give each an accurate physical width in centimetres, and a position and heading to offset it
relative to your content.

Under **Automatic** the experience works down the options in order: Apple's positioning where the
location supports it, then Google's, then a localization marker if the scene has one, and finally
manual localization. Markers are the last rung before the viewer is asked to position themselves on
a map, so adding one to an outdoor geo scene is worth the effort even when VPS covers the site.

## What the viewer sees

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

**A hint naming what to look for.** While a scene is being placed or localized the viewer is told
what to point at – the floor, a table, a wall, a marker. When automatic placement is holding out
for a particular kind of surface and the viewer is looking at one that's too small, the hint says
so rather than repeating the same instruction.

**A way out of a marker hunt.** A viewer who doesn't have the marker to hand can tap **Place
Manually** (world-tracked) or **Localize Manually** (geo-tracked) and position the scene themselves
instead of waiting for a marker that isn't coming.

**A confirmation when the scene has its place.** A brief message – *Placement Complete* for a scene
that was placed, *Localization Complete* for one localized from a marker or a location. Turn it off
with **Enable Placement Confirmation** in [Scene Settings › General](https://scenery.app/docs/editor/scene-settings#general)
for a scene that should begin without any interruption.

## Placement and anchors

Documentation source: [Placement & Localization](https://scenery.app/docs/editor/placement.md).

Placement decides where the *scene* starts. [Anchors](https://scenery.app/docs/editor/anchors) decide where each *object*
sits from there – so an object with a Horizontal Plane anchor still finds its own table, whatever
the scene's placement method. The two work together: placement establishes the scene's origin,
anchors position content relative to the world from there.

Written from source rather than a transcript – this documents a new editor section, so no
transcript exists to cross-reference.

