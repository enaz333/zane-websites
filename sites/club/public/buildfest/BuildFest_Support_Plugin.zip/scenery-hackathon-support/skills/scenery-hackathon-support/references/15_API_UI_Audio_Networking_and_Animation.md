# API UI Audio Networking and Animation

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: UIView; UI; HTTP; WebSocket; authorization; microphone; audio stream; animation; SharedActivity.

Audience: advanced reference. Retrieve only when code is necessary or explicitly requested. Start with the guides in 08 before using API signatures.

## Contents

- UIView beta
- AudioStream
- Microphone
- HTTPClient
- WebSocket
- WebSocketManager
- SecretsClient
- EntityAnimation
- ValueAnimation
- SharedActivity

---

Source page: UIView beta

Source URL: https://scenery.app/docs/scripting/api/uiview.md

# UIView beta

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

A view node inside a UI panel.

Reach via `representation.rootView` for the panel's root content, or `representation.findView(idOrName)` for any descendant. The same class represents every kind (label, button, slider, etc.) – `kind` reports which one, and `setProperty` / `getProperty` accept keys appropriate to that kind. Setting an unsupported key for the kind is a no-op.

Mutations apply live to the existing view (no rebuild – the panel refreshes on the next frame on iOS; on visionOS the change is picked up automatically). For input controls that are bound to a variable, `setProperty` also writes back to that variable so observers (label `${var}` templates, other reactive bindings) update – the same path the user-drag/tap valueChanged action takes. Controls set to a literal value don't write back.

**Example:**

```javascript
const rep = scene.findEntity({ name: "Settings" }).representation;
rep.findView("save-btn").setProperty("title", "Done");
rep.findView({ name: "volume" }).bind("value", "vol");
```

## Properties

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

### id

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** string
* Stable view ID set in the experience model.

### isEnabled

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** boolean
* Interactive flag. Applies to: any kind.

### isHidden

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** boolean
* Visibility flag. Applies to: any kind.

### isOn

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** boolean
* On/off state. Applies to: `toggle`.

### kind

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** string
* View kind as a string: "label", "button", "slider", "toggle", "textField", "stepper", "segmentedControl", "progressView", "image", "divider", "shape", "hStack", "vStack", "zStack", "spacer", "webView".

### name

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** string
* Optional human-readable name (mirrors `representation.name`).

### opacity

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** number
* View opacity, 0–1. Applies to: any kind.

### placeholder

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** string
* Placeholder text. Applies to: `textField`.

### progress

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** number
* Fill progress, 0–1. Applies to: `progressView`.

### selectedIndex

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** number
* Currently selected segment. Applies to: `segmentedControl`.

### text

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** string
* Text content. Applies to: `label`, `textField`.

### title

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** string
* Button title. Applies to: `button`.

### value

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

* **Type:** number
* Numeric value. Applies to: `slider`, `stepper`, `progressView`, `segmentedControl`.

## Methods

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

### animateTo()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
animateTo(properties: Object, duration: number, options?: Object): Promise
```

Animate one or more numeric view properties to target values.

**Example:**

```javascript
await label.animateTo({ opacity: 0 }, 0.3, { timingFunction: 'easeOut' });
```

**Parameters:**

* `properties` (Object) - Map of propertyName → target numeric value.
* `duration` (number) - Seconds.
* `options` (Object) *(optional)*
* `options.timingFunction` (string) *(optional)* - 'linear' | 'easeIn' | 'easeOut' | 'easeInOut'

**Returns:** Promise

### bind()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
bind(propertyName: string, variableName: string, options?: Object): JSUIView
```

Bind a property to an experience variable. Sugar for bindProperty.

**Example:**

```javascript
panel.findView({ name: 'vol' }).bind('value', 'volume');
```

**Parameters:**

* `propertyName` (string) - Property to bind ('value', 'isOn', 'text', ...). Kind-specific.
* `variableName` (string) - Variable identifier in the experience.
* `options` (Object) *(optional)* - { scope: 'segment' | 'experience' }. Defaults to 'segment'.

**Returns:** JSUIView

### bindProperty()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
bindProperty(propertyName: string, variableName: string, options?: any): void
```

Bind a property to an experience variable at runtime. Variable changes flow into the live view; for input controls, user input flows back into the variable. Calling `bindProperty` again on the same property replaces the existing binding. Does not mutate the saved model – bindings live with this proxy and dissolve when JS releases it (or when the panel rebuilds).

**Example:**

```javascript
slider.bindProperty("value", "volume");
slider.bindProperty("value", "globalVol", { scope: "experience" });
```

**Parameters:**

* `propertyName` (string) - Property to bind ("value", "isOn", "text", etc.). Kind-specific.
* `variableName` (string) - Variable identifier in the experience.
* `options` (any) *(optional)* - Optional `{ scope: "segment" | "experience" }`. Defaults to `"segment"`.

**Returns:** void

### fadeIn()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
fadeIn(duration?: number): Promise
```

Fade view to fully opaque.

**Parameters:**

* `duration` (number) *(optional)*

**Returns:** Promise

### fadeOut()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
fadeOut(duration?: number): Promise
```

Fade view to fully transparent.

**Parameters:**

* `duration` (number) *(optional)*

**Returns:** Promise

### getProperty()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
getProperty(name: string): any
```

Read a property by key

**Example:**

```javascript
var title = button.getProperty("title");
var value = slider.getProperty("value");
```

**Parameters:**

* `name` (string) - Property key (e.g. "text", "value", "isHidden"). Keys are kind-specific.

**Returns:** any

### off()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
off(subscriptionId: string): void
```

Remove an interaction listener by subscription id.

**Parameters:**

* `subscriptionId` (string)

**Returns:** void

### on()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
on(type: string, listener: function): string
```

Subscribe to a UI interaction on this view.

Supported types per kind: - 'tap'          → button - 'valueChanged' → slider, segmentedControl - 'toggled'      → toggle - 'textChanged'  → textField

The listener receives `{ uiNodeId, uiInteractionKind, uiValue? }`, matching the payload authored UI-interaction events emit.

**Example:**

```javascript
slider.on('valueChanged', function(e) { console.log('slider →', e.uiValue); });
button.on('tap', function() { console.log('clicked'); });
```

**Parameters:**

* `type` (string) - Interaction type.
* `listener` (function) - Callback receiving the event payload.

**Returns:** string

### once()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
once(type: string, listener: function): string
```

Subscribe to a single UI interaction; auto-unsubscribes after first fire.

**Parameters:**

* `type` (string)
* `listener` (function)

**Returns:** string

### setProperty()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
setProperty(name: string, value: any): void
```

Write a property by key. Live-updates the rendered view; for input controls bound via `.reference`, also writes back to the bound variable so observers see the change. No view tree rebuild.

**Example:**

```javascript
label.setProperty("text", "Hello");
slider.setProperty("value", 0.5);
view.setProperty("isHidden", true);
```

**Parameters:**

* `name` (string) - Property key (e.g. "text", "value", "isHidden"). Keys are kind-specific.
* `value` (any) - New property value. Type must match the property; mismatches are no-ops.

**Returns:** void

### unbind()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
unbind(propertyName: string): JSUIView
```

Remove a runtime binding installed via bind().

**Parameters:**

* `propertyName` (string)

**Returns:** JSUIView

### unbindProperty()

Documentation source: [UIView beta](https://scenery.app/docs/scripting/api/uiview.md).

```javascript
unbindProperty(propertyName: string): void
```

Remove a runtime binding installed via `bindProperty`. The property keeps its current displayed value but no longer reacts to the variable; user input on the property no longer writes back. No-op if no binding exists for `propertyName`.

**Example:**

```javascript
slider.unbindProperty("value");
```

**Parameters:**

* `propertyName` (string) - Property previously passed to `bindProperty`.

**Returns:** void

---

Source page: AudioStream

Source URL: https://scenery.app/docs/scripting/api/audiostream.md

# AudioStream

Documentation source: [AudioStream](https://scenery.app/docs/scripting/api/audiostream.md).

Streaming audio player for real-time audio playback Used for continuous audio streams like OpenAI Realtime API

Buffers up to 30 seconds of audio internally. For longer responses, playback drains the buffer as new audio arrives.

## Properties

Documentation source: [AudioStream](https://scenery.app/docs/scripting/api/audiostream.md).

### isDrained

Documentation source: [AudioStream](https://scenery.app/docs/scripting/api/audiostream.md).

* **Type:** boolean
* Whether the audio buffer has finished playing Use this to wait for playback to complete before resuming microphone

**Example:**

```javascript
function waitForPlayback() {
    if (!stream.isDrained) {
        setTimeout(waitForPlayback, 100);
    } else {
        scene.microphone.start();
    }
}
```

## Methods

Documentation source: [AudioStream](https://scenery.app/docs/scripting/api/audiostream.md).

### append()

Documentation source: [AudioStream](https://scenery.app/docs/scripting/api/audiostream.md).

```javascript
append(base64: string): void
```

Append base64-encoded audio data to the stream buffer

**Example:**

```javascript
ws.onmessage = function(event) {
    var msg = JSON.parse(event.data);
    if (msg.type === 'response.audio.delta') {
        stream.append(msg.delta);
    }
};
```

**Parameters:**

* `base64` (string) - Base64-encoded PCM16 audio data

**Returns:** void

### stop()

Documentation source: [AudioStream](https://scenery.app/docs/scripting/api/audiostream.md).

```javascript
stop(): void
```

Stop playback and release resources

**Example:**

```javascript
stream.stop();
```

**Returns:** void

---

Source page: Microphone

Source URL: https://scenery.app/docs/scripting/api/microphone.md

# Microphone

Documentation source: [Microphone](https://scenery.app/docs/scripting/api/microphone.md).

Microphone audio streaming Access via `scene.microphone`

**Example:**

```javascript
scene.microphone.configure({ sampleRate: 24000, silenceThreshold: 0.01 });
scene.microphone.onData = function(base64) {
    // Send to speech API
};
scene.microphone.start();
```

## Properties

Documentation source: [Microphone](https://scenery.app/docs/scripting/api/microphone.md).

### isStreaming

Documentation source: [Microphone](https://scenery.app/docs/scripting/api/microphone.md).

* **Type:** boolean
* Whether the microphone is currently streaming

### onData

Documentation source: [Microphone](https://scenery.app/docs/scripting/api/microphone.md).

* **Type:** any
* Callback for audio data chunks (base64-encoded PCM16)

### onError

Documentation source: [Microphone](https://scenery.app/docs/scripting/api/microphone.md).

* **Type:** any
* Callback for errors (permission denied, etc.)

## Methods

Documentation source: [Microphone](https://scenery.app/docs/scripting/api/microphone.md).

### configure()

Documentation source: [Microphone](https://scenery.app/docs/scripting/api/microphone.md).

```javascript
configure(options: Array<any>): void
```

Configure microphone settings

* sampleRate: Output sample rate (default: 24000)   - silenceThreshold: RMS threshold to skip quiet audio, 0 to disable (default: 0)   - highpassFrequency: Highpass filter cutoff in Hz, 0 to disable (default: 0)

**Parameters:**

* `options` (Array\<any>) - Configuration object

**Returns:** void

### start()

Documentation source: [Microphone](https://scenery.app/docs/scripting/api/microphone.md).

```javascript
start(): void
```

Start capturing audio

**Returns:** void

### stop()

Documentation source: [Microphone](https://scenery.app/docs/scripting/api/microphone.md).

```javascript
stop(): void
```

Stop capturing audio

**Returns:** void

---

Source page: HTTPClient

Source URL: https://scenery.app/docs/scripting/api/httpclient.md

# HTTPClient

Documentation source: [HTTPClient](https://scenery.app/docs/scripting/api/httpclient.md).

HTTP client for making network requests Supports GET, POST, and custom requests with authentication

## Methods

Documentation source: [HTTPClient](https://scenery.app/docs/scripting/api/httpclient.md).

### get()

Documentation source: [HTTPClient](https://scenery.app/docs/scripting/api/httpclient.md).

```javascript
get(url: string, callback: any): void
```

Make a GET request

**Example:**

```javascript
http.get('https://api.example.com/data', function(result, error) {
    if (error) { console.error(error); return; }
    console.log(result.status, result.data);
});
```

**Parameters:**

* `url` (string) - Request URL
* `callback` (any) - Callback function (result, error)

**Returns:** void

### post()

Documentation source: [HTTPClient](https://scenery.app/docs/scripting/api/httpclient.md).

```javascript
post(url: string, body: string, callback: any): void
```

Make a POST request

**Example:**

```javascript
http.post('https://api.example.com/data', JSON.stringify({ name: 'test' }), function(result, error) {
    if (error) { console.error(error); return; }
    console.log(result.status, result.data);
});
```

**Parameters:**

* `url` (string) - Request URL
* `body` (string) - Request body string
* `callback` (any) - Callback function (result, error)

**Returns:** void

### request()

Documentation source: [HTTPClient](https://scenery.app/docs/scripting/api/httpclient.md).

```javascript
request(url: string, options: Array<any>, callback: any): void
```

Make a custom HTTP request

* method: HTTP method (GET, POST, PUT, DELETE, etc.)   - headers: Dictionary of HTTP headers   - body: Request body string   - secret: Name of a credential this experience binds. Scenery sends the request and     adds the credential, so the value never reaches the device. Excludes `token`.   - token: Bearer token for Authorization header. Not for a standing API key, which a     script cannot hold secretly.   - username: Username for Basic auth   - password: Password for Basic auth   - responseType: Response format - "json" (default), "text", or "base64"

**Example:**

```javascript
// JSON response (default)
var response = await http.request('https://api.example.com/data', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query: 'test' }),
    secret: 'my-api'
});
console.log(response.data.results);

// Binary response as base64 (for audio, images, etc.)
var audio = await http.request('https://api.openai.com/v1/audio/speech', {
    method: 'POST',
    secret: 'openai',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        model: 'tts-1',
        input: 'Hello world',
        voice: 'nova',
        response_format: 'pcm'
    }),
    responseType: 'base64'
});
await entity.playAudioBuffer(audio.data, { sampleRate: 24000 });
```

**Parameters:**

* `url` (string) - Request URL
* `options` (Array\<any>) - Request options
* `callback` (any) - Callback function (result, error)

**Returns:** void

---

Source page: WebSocket

Source URL: https://scenery.app/docs/scripting/api/websocket.md

# WebSocket

Documentation source: [WebSocket](https://scenery.app/docs/scripting/api/websocket.md).

WebSocket connection for real-time communication

**Example:**

```javascript
var ws = websocket.connect('wss://api.example.com/ws', {
    headers: { 'Authorization': 'Bearer token' }
});

ws.onOpen = function() {
    console.log('Connected');
    ws.send(JSON.stringify({ type: 'hello' }));
};

ws.onMessage = function(event) {
    var data = JSON.parse(event.data);
    console.log('Received:', data);
};

ws.onError = function(event) {
    console.error('Error:', event.error);
};

ws.onClose = function() {
    console.log('Disconnected');
};

// Later...
ws.close();
```

## Properties

Documentation source: [WebSocket](https://scenery.app/docs/scripting/api/websocket.md).

### onClose

Documentation source: [WebSocket](https://scenery.app/docs/scripting/api/websocket.md).

* **Type:** any
* Called when connection closes

### onError

Documentation source: [WebSocket](https://scenery.app/docs/scripting/api/websocket.md).

* **Type:** any
* Called on error (event.error contains the Error)

### onMessage

Documentation source: [WebSocket](https://scenery.app/docs/scripting/api/websocket.md).

* **Type:** any
* Called when message received (event.data contains the message)

### onOpen

Documentation source: [WebSocket](https://scenery.app/docs/scripting/api/websocket.md).

* **Type:** any
* Called when connection opens

## Methods

Documentation source: [WebSocket](https://scenery.app/docs/scripting/api/websocket.md).

### close()

Documentation source: [WebSocket](https://scenery.app/docs/scripting/api/websocket.md).

```javascript
close(): void
```

Close the connection

**Returns:** void

### send()

Documentation source: [WebSocket](https://scenery.app/docs/scripting/api/websocket.md).

```javascript
send(message: string): void
```

Send a message

**Parameters:**

* `message` (string) - String message to send

**Returns:** void

---

Source page: WebSocketManager

Source URL: https://scenery.app/docs/scripting/api/websocketmanager.md

# WebSocketManager

Documentation source: [WebSocketManager](https://scenery.app/docs/scripting/api/websocketmanager.md).

WebSocket connection manager Access via `websocket.connect()`

## Methods

Documentation source: [WebSocketManager](https://scenery.app/docs/scripting/api/websocketmanager.md).

### connect()

Documentation source: [WebSocketManager](https://scenery.app/docs/scripting/api/websocketmanager.md).

```javascript
connect(url: string, options: Array<any>): WebSocket
```

Create a new WebSocket connection

* protocols: Array of subprotocols   - headers: HTTP headers dictionary   - reconnectInterval: Seconds between reconnect attempts (default: 2)   - maxReconnectAttempts: Maximum reconnection attempts (default: 5)

**Parameters:**

* `url` (string) - WebSocket URL (ws:// or wss://)
* `options` (Array\<any>) - Connection options

**Returns:** [WebSocket](https://scenery.app/docs/scripting/api/websocket)

---

Source page: SecretsClient

Source URL: https://scenery.app/docs/scripting/api/secretsclient.md

# SecretsClient

Documentation source: [SecretsClient](https://scenery.app/docs/scripting/api/secretsclient.md).

Mints short-lived credentials for the vendors that issue them.

## Methods

Documentation source: [SecretsClient](https://scenery.app/docs/scripting/api/secretsclient.md).

### mint()

Documentation source: [SecretsClient](https://scenery.app/docs/scripting/api/secretsclient.md).

```javascript
mint(name: string, params: Array<any>, callback: any): void
```

Mint a credential for one of this experience's secrets.

**Parameters:**

* `name` (string) - The name bound in the editor under Secrets.
* `params` (Array\<any>) - Vendor-specific mint parameters, such as an OpenAI session config.
* `callback` (any) - Callback function (result, error)

**Returns:** void

---

Source page: EntityAnimation

Source URL: https://scenery.app/docs/scripting/api/entityanimation.md

# EntityAnimation

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

Entity animation factory - create animation descriptors for use with entity.play()

## Static Methods

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

### to()

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

```javascript
EntityAnimation.to(toProperties: Object, duration: number, options?: Object): EntityAnimation
```

Animate to target properties

**Example:**

```javascript
// Animate box upward
box.play(EntityAnimation.to(
    { position: Vector3(0, 2, 0) },
    1.0,
    { timingFunction: "easeOut" }
));
```

**Parameters:**

* `toProperties` (Object) - Target properties (position, rotation, scale, opacity)
* `duration` (number) - Duration in seconds
* `options` (Object) *(optional)* - Animation options (timingFunction, delay, etc.)

**Returns:** [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)

### fromTo()

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

```javascript
EntityAnimation.fromTo(fromProperties: Object, toProperties: Object, duration: number, options?: Object): EntityAnimation
```

Animate from starting to target properties

**Parameters:**

* `fromProperties` (Object) - Starting properties
* `toProperties` (Object) - Target properties
* `duration` (number) - Duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)

### by()

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

```javascript
EntityAnimation.by(byProperties: Object, duration: number, options?: Object): EntityAnimation
```

Animate by relative values

**Parameters:**

* `byProperties` (Object) - Relative change values
* `duration` (number) - Duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)

### fromBy()

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

```javascript
EntityAnimation.fromBy(fromProperties: Object, byProperties: Object, duration: number, options?: Object): EntityAnimation
```

Animate from starting properties by relative values

**Parameters:**

* `fromProperties` (Object) - Starting properties
* `byProperties` (Object) - Relative change values
* `duration` (number) - Duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)

### spin()

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

```javascript
EntityAnimation.spin(revolutions: number, duration: number, options?: Object): EntityAnimation
```

Spin animation - rotate around local axis

**Parameters:**

* `revolutions` (number) - Number of full rotations
* `duration` (number) - Duration in seconds
* `options` (Object) *(optional)* - Animation options
* `options.axis` (Array\<number>) *(optional)* - Local rotation axis \[x, y, z]

**Returns:** [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)

### orbit()

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

```javascript
EntityAnimation.orbit(config: Object, duration: number, options?: Object): EntityAnimation
```

Orbit animation - rotate around a point

**Parameters:**

* `config` (Object) - Orbit configuration
* `config.axis` (Array\<number> | [Vector3](https://scenery.app/docs/scripting/api/vector3)) *(optional)* - Rotation axis
* `config.rotationCount` (number) *(optional)* - Number of orbits
* `config.clockwise` (boolean) *(optional)* - Spin direction
* `config.orientToPath` (boolean) *(optional)* - Face movement direction
* `config.startTransform` (Object) *(optional)* - Starting offset transform.
  `rotation` accepts a `Rotation` or a `Vector3` of euler angles (radians).
* `duration` (number) - Duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)

### keyframes()

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

```javascript
EntityAnimation.keyframes(frames: Array<Object>, duration: number, options?: Object): EntityAnimation
```

Keyframe animation - animate through multiple property states

**Parameters:**

* `frames` (Array\<Object>) - Array of property states
* `duration` (number) - Total duration in seconds
* `options` (Object) *(optional)* - Animation options
* `options.tweenMode` (string) *(optional)* - "linear" or "hold"

**Returns:** [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)

### model()

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

```javascript
EntityAnimation.model(name?: string, options?: Object): EntityAnimation
```

Play embedded model animation (USDZ animations)

**Parameters:**

* `name` (string) *(optional)* - Animation name (optional, plays default if omitted)
* `options` (Object) *(optional)* - Options
* `options.trimStart` (number) *(optional)* - Trim from start (seconds)
* `options.trimEnd` (number) *(optional)* - Trim from end (seconds)
* `options.duration` (number) *(optional)* - Override duration

**Returns:** [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)

### group()

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

```javascript
EntityAnimation.group(animations: Array<EntityAnimation>, options?: Object): EntityAnimation
```

Group multiple animations to play together

**Parameters:**

* `animations` (Array<[EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)>) - Array of EntityAnimation objects
* `options` (Object) *(optional)* - Animation options (applied to group)

**Returns:** [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)

### emphasize()

Documentation source: [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation.md).

```javascript
EntityAnimation.emphasize(style: string, duration: number, options?: Object): EntityAnimation
```

Emphasize animation - attention-grabbing effect

**Parameters:**

* `style` (string) - "bounce", "pulse", "wiggle", etc.
* `duration` (number) - Duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** [EntityAnimation](https://scenery.app/docs/scripting/api/entityanimation)

---

Source page: ValueAnimation

Source URL: https://scenery.app/docs/scripting/api/valueanimation.md

# ValueAnimation

Documentation source: [ValueAnimation](https://scenery.app/docs/scripting/api/valueanimation.md).

Value animations with spring and curve timing

Supports animating floats, vectors, colors, transforms, and rotations with automatic type detection and appropriate interpolation (lerp for most types, slerp for rotations).

**Example:**

```javascript
// Animate opacity
animateValue({
    from: 0,
    to: 1,
    duration: 0.5,
    onUpdate: function(value) {
        entity.opacity = value;
    }
});

// Spring animation on position
animateValue({
    from: Vector3(0, 0, 0),
    to: Vector3(0, 2, 0),
    spring: { duration: 0.6, bounce: 0.3 },
    onUpdate: function(pos) {
        entity.position = pos;
    }
});

// Transform animation (position + rotation + scale in one)
animateValue({
    from: entity.transform,
    to: Transform({
        position: Vector3(0, 0.3, 0),
        rotation: Rotation(0, Math.PI, 0),
        scale: Vector3(1, 1, 1)
    }),
    spring: { duration: 0.8, bounce: 0.5 },
    onUpdate: function(t) {
        entity.transform = t;
    }
});

// Color transition
animateValue({
    from: Color.red(),
    to: Color.blue(),
    duration: 1,
    curve: 'easeInOut',
    onUpdate: function(color) {
        // apply color
    }
});

// Rotation with automatic slerp
animateValue({
    from: Rotation(0, 0, 0),
    to: Rotation(0, Math.PI, 0),
    duration: 0.8,
    onUpdate: function(rot) {
        entity.rotation = rot;
    }
});
```

## Properties

Documentation source: [ValueAnimation](https://scenery.app/docs/scripting/api/valueanimation.md).

### isPlaying

Documentation source: [ValueAnimation](https://scenery.app/docs/scripting/api/valueanimation.md).

* **Type:** boolean
* Whether the animation is currently playing

## Methods

Documentation source: [ValueAnimation](https://scenery.app/docs/scripting/api/valueanimation.md).

### destroy()

Documentation source: [ValueAnimation](https://scenery.app/docs/scripting/api/valueanimation.md).

```javascript
destroy(): void
```

Stop and clean up the animation permanently

Animations clean up automatically when they complete. Call destroy() only for infinite animations or early termination.

**Returns:** void

### start()

Documentation source: [ValueAnimation](https://scenery.app/docs/scripting/api/valueanimation.md).

```javascript
start(): void
```

Start or resume the animation

**Returns:** void

### stop()

Documentation source: [ValueAnimation](https://scenery.app/docs/scripting/api/valueanimation.md).

```javascript
stop(): void
```

Pause the animation (can be resumed with start())

**Returns:** void

---

Source page: SharedActivity

Source URL: https://scenery.app/docs/scripting/api/sharedactivity.md

# SharedActivity

Documentation source: [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity.md).

Shared activity state for multi-user sessions (SharePlay, WebSocket, etc.)

Always present on `experience.sharedActivity`. When no session is active, `isActive` and `isOwner` return `false`, `participantCount` returns `0`.

**Example:**

```javascript
if (experience.sharedActivity.isActive && experience.sharedActivity.isOwner) {
    // Only the owner connects to external services
    openai.connect();
}

experience.sharedActivity.onOwnershipChanged = function(isOwner) {
    if (isOwner) {
        openai.connect();
    } else {
        openai.disconnect();
    }
};
```

## Properties

Documentation source: [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity.md).

### isActive

Documentation source: [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity.md).

* **Type:** boolean
* Whether a shared activity session is currently active

### isOwner

Documentation source: [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity.md).

* **Type:** boolean
* Whether the local participant is the session owner (presenter)

### onMessage

Documentation source: [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity.md).

* **Type:** any
* Called when a script message is received from another participant

**Example:**

```javascript
experience.sharedActivity.onMessage = function(data) {
    console.log('Received:', data.type);
};
```

### onOwnershipChanged

Documentation source: [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity.md).

* **Type:** any
* Called when session ownership changes (session start, transfer, owner leaves, session end)

**Example:**

```javascript
experience.sharedActivity.onOwnershipChanged = function(isOwner) {
    if (isOwner) { startAI(); } else { stopAI(); }
};
```

### participantCount

Documentation source: [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity.md).

* **Type:** number
* Number of remote participants (excludes local participant)

## Methods

Documentation source: [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity.md).

### send()

Documentation source: [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity.md).

```javascript
send(data: any): true
```

Send data to all participants (reliable delivery).

object or array; primitives are rejected).

per-message cap, and enqueued for transmission. `false` on any   validation failure – check the console for the specific reason.   Existing callers that ignore the return value continue to work.

**Example:**

```javascript
experience.sharedActivity.send({ type: 'orb_state', state: 'speaking' });
```

**Parameters:**

* `data` (any) - JSON-serializable data to send (must be a plain

**Returns:** true

### sendFrequent()

Documentation source: [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity.md).

```javascript
sendFrequent(data: any): true
```

Send data to all participants (unreliable delivery, suitable for high-frequency updates).

for the full validation contract.

**Example:**

```javascript
experience.sharedActivity.sendFrequent({ type: 'audio_level', level: 0.7 });
```

**Parameters:**

* `data` (any) - JSON-serializable data to send.

**Returns:** true

