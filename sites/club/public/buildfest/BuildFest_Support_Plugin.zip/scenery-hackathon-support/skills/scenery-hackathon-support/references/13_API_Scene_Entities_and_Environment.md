# API Scene Entities and Environment

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: findEntity; null; descriptor versus live object; scene; representation; nested entity; location; raycast.

Audience: advanced reference. Retrieve only when code is necessary or explicitly requested. Start with the guides in 08 before using API signatures.

## Contents

- Scene
- ObjectEntity
- RepresentationEntity
- Entity
- Experience
- Environment
- EnvironmentFeatures
- Location beta
- AnchorData
- CollisionCastHit
- ARRaycastResult

---

Source page: Scene

Source URL: https://scenery.app/docs/scripting/api/scene.md

# Scene

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

## Properties

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

### cameraTransform

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* Current camera transform in world space

### id

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

* **Type:** string
* Scene identifier

### microphone

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

* **Type:** [Microphone](https://scenery.app/docs/scripting/api/microphone)
* Microphone audio streaming

### time

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

* **Type:** number
* Time elapsed since scene started (seconds)

### viewportSize

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

* **Type:** [Vector2](https://scenery.app/docs/scripting/api/vector2)
* Viewport size in points (iOS only)

## Methods

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

### animateBy()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
animateBy(objectOrId: string | ObjectEntity, properties: Object, duration: number, options?: Object): Promise<void>
```

Animate object by relative values

**Parameters:**

* `objectOrId` (string | [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity)) - ObjectEntity or entity ID
* `properties` (Object) - Relative change values
* `duration` (number) - Animation duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** Promise\<void>

### animateFromTo()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
animateFromTo(objectOrId: string | ObjectEntity, fromProperties: Object, toProperties: Object, duration: number, options?: Object): Promise<void>
```

Animate object from starting to target properties

**Parameters:**

* `objectOrId` (string | [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity)) - ObjectEntity or entity ID
* `fromProperties` (Object) - Starting properties
* `toProperties` (Object) - Target properties
* `duration` (number) - Animation duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** Promise\<void>

### animateTo()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
animateTo(objectOrId: string | ObjectEntity, properties: Object, duration: number, options?: Object): Promise<void>
```

Animate object to target properties

**Parameters:**

* `objectOrId` (string | [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity)) - ObjectEntity or entity ID
* `properties` (Object) - Target properties (position, rotation, scale, opacity)
* `duration` (number) - Animation duration in seconds
* `options` (Object) *(optional)* - Animation options (timingFunction, delay, repeatCount, etc.)

**Returns:** Promise\<void>

### createAudioStream()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
createAudioStream(options: Array<any>): AudioStream
```

Create a streaming audio player

**Parameters:**

* `options` (Array\<any>) - Stream configuration (sampleRate, channels, format, elementId, representationId)

**Returns:** [AudioStream](https://scenery.app/docs/scripting/api/audiostream)

### createEntity()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
createEntity(descriptor: ObjectDescriptor): Promise<ObjectEntity>
```

Create an object in the scene.

**Example:**

```javascript
const box = createBox(0.3, 0.3, 0.3)
    .anchor(Anchor.position(0, 0, -1))
    .name('hero-box');
const entity = await scene.createEntity(box);
```

**Parameters:**

* `descriptor` ([ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)) - Object descriptor from createBox, createSphere, createModel, createPlane, createMesh, etc.
  Configure the object via the descriptor's chainable builder methods (`.anchor(...)`, `.name(...)`,
  `.physics(...)`, `.material(...)`, `.shadow(...)`, `.gestures(...)`, …), not as a second argument.

**Returns:** Promise\<ObjectEntity>

### createPath() beta

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
createPath(options: { points: [[x,y,z] | {x,y,z} | Vector3, …], closed?: boolean }): Path
```

Create a catmull-rom path from control points.

Returns a runtime path handle (not persisted): query it with `point(t)`, `pointAtDistance(d)`, `tangent(t)`, `length`, or drive an entity along it with `entity.followPath(path, { duration, constantSpeed, alignsToTangent, timing, repeat })`.

**Parameters:**

* `options` ({ points: \[\[x,y,z] | {x,y,z} | Vector3, …], closed?: boolean }) - (≥ 2 points).

**Returns:** [Path](https://scenery.app/docs/scripting/api/path)

### createSurfaceInput() beta

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
createSurfaceInput(options: Object): any
```

Platform-adaptive surface interaction. Returns a live input source that yields interaction points on a surface, in that surface's LOCAL frame, using whatever input the platform offers – fingertips on Apple Vision Pro (hand tracking), screen taps / drags on iPhone / iPad / Mac. Your logic reads the same points either way and never branches on platform.

Read `input.points` once per frame inside `scene.on('render', ...)`, and call `input.stop()` when done (it tears down the gesture subscriptions).

**Example:**

```javascript
const input = scene.createSurfaceInput({ target: water.representation, plane: { axis: 'y', offset: 1.25 } });
scene.on('render', function () {
    for (const p of input.points) {
        // p.x / p.y / p.z are in the surface's local frame – feed straight into your sim
    }
});
// later: input.stop();
```

**Parameters:**

* `options` (Object)
* `options.target` ([RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity)) - The surface: the representation whose
  local frame the points are returned in – typically `entity.representation`. Passing an
  ObjectEntity uses its primary representation (fine for a simple object; for a composed
  object with nested representations, pass the specific representation holding the surface).
* `options.project` (string) *(optional)* - How a screen ray maps to the surface:
  `'plane'` (fast closed-form intersection with a flat plane – no collision needed, ideal for
  water / tables / deforming compute meshes) or `'collision'` (`scene.raycast` against the
  target's collision geometry – for solid models; a deforming mesh without live collision falls
  back to its base shape). The hand path is proximity-based and works on any shape regardless.
* `options.plane` (Object) *(optional)* - Plane definition for `project: 'plane'`.
* `options.plane.axis` (string) *(optional)* - Plane normal axis in local space: `'x'` | `'y'` | `'z'`.
* `options.plane.offset` (number) *(optional)* - Plane position along that axis, in local metres.
* `options.maxDistance` (number) *(optional)* - Hand path only: a fingertip is an active touch when
  within this distance (metres) of the plane. Crossing in = `began`, leaving = `ended`.

**Returns:** any

### emitHaptic()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
emitHaptic(feedback?: string | Object): Promise<void>
```

Play haptic feedback on the viewer's device.

Haptics are device-level rather than positional – they play on the device no matter which object triggered them – so this lives on the scene rather than on an entity. Devices without a haptic engine ignore it.

**Example:**

```javascript
// Thud when the ball knocks a can over.
can.on('collision', function() {
    scene.emitHaptic('impactHeavy');
});
```

**Parameters:**

* `feedback` (string | Object) *(optional)* - `"impactLight"`,
  `"impactMedium"`, `"impactHeavy"`, `"impactSoft"`, `"impactRigid"`,
  `"selection"`, or `{ asset: urlOrId }` for a custom haptic pattern file.

**Returns:** Promise\<void>

### findEntity()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
findEntity(query: any): ObjectEntity
```

Find an entity by ID or name

**Example:**

```javascript
// By ID
var entity = scene.findEntity("ABC123");

// By ID (explicit)
var entity = scene.findEntity({ id: "ABC123" });

// By name
var entity = scene.findEntity({ name: "My Cool Box" });
```

**Parameters:**

* `query` (any) - Entity ID string, or object with { id: "..." } or { name: "..." }

**Returns:** [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity)

### getAnchors()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
getAnchors(kind?: string): Array<any>
```

Get detected AR anchors

**Parameters:**

* `kind` (string) *(optional)* - Filter by anchor type ("plane", "image", "face", etc.), or nil for all

**Returns:** Array\<any>

### getCustomEvents()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
getCustomEvents(): Array<any>
```

List custom-trigger scene events on the current segment. Useful for debug panels that enumerate triggerable events at runtime. Each entry has the event's `id`, optional `name` (omitted when unset), and `isEnabled` flag. System events (tap, render, screenTap, schedule, etc.) are not included – those are handled by the engine, not scripted.

**Example:**

```javascript
scene.getCustomEvents().forEach(function(evt) {
    console.log(evt.id, evt.name, evt.isEnabled);
});
```

**Returns:** Array\<any>

### getMaterial()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
getMaterial(id: string): Material
```

Fetch a material from the experience's material library by id, hydrated into a live `Material` you can inspect, `.clone()`, and edit. Use the get → `.clone()` → tweak → apply pattern to override a library material on a single object without mutating the library entry.

**Parameters:**

* `id` (string) - The library material's id.

**Returns:** [Material](https://scenery.app/docs/scripting/api/material)

### getObjectDescriptor()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
getObjectDescriptor(nameOrId: string | Object): ObjectDescriptor | any
```

Read an authored object's descriptor so a script can adjust it before it is displayed. Returns an editable {@link ObjectDescriptor} (the recipe) – distinct from `findEntity`, which returns the live entity once it's in the scene. Edit it with the usual chainable methods (`.material`, `.gestures`, `.asset`, `.representation`, …), then either `scene.setObjectDescriptor(...)` to update it in place, or `.clone()` + `scene.createEntity(...)` to spawn a variant.

Ordering: run the edit + set BEFORE the object's Display Element action, in the same event (top level or a Sequence – not inside a Group, which runs concurrently), and keep the set synchronous (no `await` before it).

**Parameters:**

* `nameOrId` (string | Object) - An id string, or `{ id }` / `{ name }`.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor) | any

### getVariable()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
getVariable(id: string): any
```

Get a scene-scoped variable

**Parameters:**

* `id` (string) - Variable identifier

**Returns:** any

### off()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
off(eventId: string): void
```

Remove a scene event listener

**Example:**

```javascript
var eventId = scene.on('render', function() {});
// Later...
scene.off(eventId);
```

**Parameters:**

* `eventId` (string) - Event ID returned from on()

**Returns:** void

### on()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
on(type: string, options?: Object | function, listener?: function): string
```

Register a scene event listener

**Example:**

```javascript
scene.on('start', function() {
    console.log('Scene started!');
});
```

**Parameters:**

* `type` (string) - Event type: "start", "render", "screenTap", "pan", "pinch", "rotate", "variableChange", "schedule"
* `options` (Object | function) *(optional)* - Event options or callback
* `listener` (function) *(optional)* - Callback if options provided

**Returns:** string

### once()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
once(type: string, options?: Object | function, listener?: function): string
```

Register a one-time scene event listener

**Example:**

```javascript
scene.once('start', function() {
    console.log('Scene started (once)!');
});
```

**Parameters:**

* `type` (string) - Event type
* `options` (Object | function) *(optional)* - Event options or callback
* `listener` (function) *(optional)* - Callback if options provided

**Returns:** string

### playAnimation()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
playAnimation(objectOrId: string | ObjectEntity, animation: Object, representationId?: string): Promise<void>
```

Play animation on object

**Parameters:**

* `objectOrId` (string | [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity)) - ObjectEntity or entity ID
* `animation` (Object) - Animation data
* `representationId` (string) *(optional)* - Optional representation ID

**Returns:** Promise\<void>

### playAudioBuffer()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
playAudioBuffer(base64: string, options?: Object): Promise<void>
```

Play audio from PCM buffer data

**Example:**

```javascript
// Play at user's position (non-spatial)
await scene.playAudioBuffer(base64Data, { sampleRate: 24000 });

// Play spatially on an entity
await scene.playAudioBuffer(base64Data, { 
    sampleRate: 24000, 
    elementId: box.id 
});
```

**Parameters:**

* `base64` (string) - Base64-encoded PCM audio data
* `options` (Object) *(optional)* - Buffer and playback options
* `options.sampleRate` (number) *(optional)* - Sample rate in Hz
* `options.channels` (number) *(optional)* - Number of channels (1 = mono, 2 = stereo)
* `options.format` (string) *(optional)* - Sample format: "pcm16" or "float32"
* `options.gain` (number) *(optional)* - Volume gain (0.0 to 4.0, default 1.0)
* `options.elementId` (string) *(optional)* - Target element ID (optional, uses POV if omitted)
* `options.representationId` (string) *(optional)* - Target representation ID (optional)

**Returns:** Promise\<void>

### preload()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
preload(sources: string | Array<string>, options?: Object): Promise<void>
```

Warm one or more assets so their first use doesn't hitch – the decode / GPU upload happens now (e.g. during scene setup) instead of on the frame you first play or show them.

**Example:**

```javascript
// Warm the impact sounds during setup so the first hit doesn't drop a frame.
await scene.preload(['48D3…','12F9…'], { type: 'audio' });
```

**Parameters:**

* `sources` (string | Array\<string>) - Asset id(s) or `https://` URL(s). For `type: 'entity'` or
  `'material'`, pass the element / material id instead of an asset reference.
* `options` (Object) *(optional)*
* `options.type` (string) *(optional)* - How to warm it: `'audio'` (decode + buffer),
  `'model'` (parse + GPU upload), `'entity'` (an element and everything it pulls in),
  `'material'`, `'shader'`, or `'file'` (just download the bytes).

**Returns:** Promise\<void>

### projectToScreen()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
projectToScreen(worldPosition: Vector3): Vector2
```

Convert world position to normalized screen coordinates (iOS only)

**Parameters:**

* `worldPosition` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Position in world space

**Returns:** [Vector2](https://scenery.app/docs/scripting/api/vector2)

### raycast()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
raycast(origin: Vector3, direction: Vector3): Array<any>
```

Cast ray through scene entities and scene mesh

**Parameters:**

* `origin` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Ray origin in world space
* `direction` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Ray direction (will be normalized)

**Returns:** Array\<any>

### raycastAR()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
raycastAR(origin: Vector3, direction: Vector3, target: string, alignment: string): Array<any>
```

Cast ray against AR planes (iOS only)

**Parameters:**

* `origin` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Ray origin in world space
* `direction` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Ray direction (will be normalized)
* `target` (string) - Target type - "plane", "planeExtended", "surface"
* `alignment` (string) - Surface alignment - "horizontal", "vertical", "any"

**Returns:** Array\<any>

### runAction()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
runAction(action: Action): Promise<void>
```

Run an action and wait for completion.

**Parameters:**

* `action` ([Action](https://scenery.app/docs/scripting/api/action)) - Action to run.

**Returns:** Promise\<void>

### screenToRay()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
screenToRay(normalizedPosition: Vector2): Ray
```

Convert normalized screen coordinates to a ray for raycasting (iOS only)

**Parameters:**

* `normalizedPosition` ([Vector2](https://scenery.app/docs/scripting/api/vector2)) - Screen position in normalized coordinates (0-1)

**Returns:** [Ray](https://scenery.app/docs/scripting/api/ray)

### setBloom()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
setBloom(options: { strength, threshold, blurRadius, scope }): void
```

Make bright pixels glow. Pass `null` to switch it off.

is the luminance a pixel must exceed to contribute, so raising it dims the   faint emitters first; `blurRadius` is a percentage of viewport height;   `scope` is `'selectedObjects'` (the default, only objects that opt in) or   `'wholeScene'`. Omitted keys keep their current value.

Needs `environment.features.has('bloom')`: it wants both a new enough OS and an Apple-7-family GPU, and on visionOS it only appears in an immersive space.

**Example:**

```javascript
if (environment.features.has('bloom')) {
    scene.setBloom({ strength: 0.4, threshold: 1.2, scope: 'wholeScene' });
}
```

**Parameters:**

* `options` ({ strength, threshold, blurRadius, scope }) - . `threshold`

**Returns:** void

### setObjectDescriptor()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
setObjectDescriptor(descriptor: ObjectDescriptor): boolean
```

Write an edited descriptor back into the current scene, keyed by its id. Takes effect the next time the object is displayed (edit before its first Display Element for the clean path). If the object is already displayed, the change lands but `displayElement` won't re-apply it – remove and re-display to see it.

**Parameters:**

* `descriptor` ([ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor))

**Returns:** boolean

### setToneMapping()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
setToneMapping(options: any): void
```

Set the scene's tone curve – how brightness is mapped onto the display. Pass `null` to return to the platform default.

shoulderLength, shoulderAngle }\`. The toe governs the shadows, the shoulder   the highlights, and exposure shifts everything. Omitted keys keep their   current value.

Needs `environment.features.has('toneMapping')`.

**Example:**

```javascript
// Lift the whole scene a stop and roll the highlights off harder.
scene.setToneMapping({ exposure: 1, shoulderStrength: 1.4 });
```

**Parameters:**

* `options` (any) - \`{ exposure, toeStrength, toeLength, shoulderStrength,

**Returns:** void

### setVariable()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
setVariable(id: string, value: any, options: any): void
```

Set a scene-scoped variable (cleared on scene transition)

**Parameters:**

* `id` (string) - Variable identifier
* `value` (any) - Value to store (number, string, boolean, Vector3, Color, etc.)
* `options` (any) - Optional type hint { type: "vector3" | "color" | ... }

**Returns:** void

### toggle()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
toggle(entities: Array<ObjectEntity>, isEnabled: boolean): Promise<void>
```

Reveal or hide a batch of objects in a single frame.

Calling `entity.toggle(true)` in a loop enables each object on its own frame – so physics bodies start at different times and a stack settles against its half-built self. This runs one grouped action instead, so every object reveals and every physics body starts together.

Pairs with cloning a disabled template: clone the batch (each copy stays hidden, physics off), then `scene.toggle(copies, true)` to bring them all up at once.

**Example:**

```javascript
const cans = [];
for (const slot of layout) {
    cans.push(await template.clone({ position: slot }));  // hidden, deferred
}
await scene.toggle(cans, true);                           // all appear together
```

**Parameters:**

* `entities` (Array<[ObjectEntity](https://scenery.app/docs/scripting/api/objectentity)>) - Objects to toggle.
* `isEnabled` (boolean) - Reveal (`true`) or hide (`false`).

**Returns:** Promise\<void>

### triggerCustomEvent()

Documentation source: [Scene](https://scenery.app/docs/scripting/api/scene.md).

```javascript
triggerCustomEvent(query: any): void
```

Trigger one or more custom-trigger events.

or `{ name: "..." }`. Multiple events can share a name –   passing `{ name: ... }` fires all matches.

**Example:**

```javascript
scene.triggerCustomEvent("evt-abc");                 // by ID
scene.triggerCustomEvent({ id: "evt-abc" });         // by ID, explicit
scene.triggerCustomEvent({ name: "spawn-box" });     // by name (fires all matches)
```

**Parameters:**

* `query` (any) - Lookup form. Pass a string ID, `{ id: "..." }`,

**Returns:** void

---

Source page: ObjectEntity

Source URL: https://scenery.app/docs/scripting/api/objectentity.md

# ObjectEntity

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

Entity in the scene

Access properties and representations, listen to events.

**Example:**

```javascript
var entity = scene.findEntity({ name: "My Box" });
entity.position = Vector3(0, 1, 0);
entity.on('tap', function() {
    console.log('Tapped!');
});
```

## Properties

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

### boundingBox

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox)
* Local bounding box

### eulerAngles

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Rotation on top of the authored rotation, as euler angles in radians.

### id

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** string
* Unique entity identifier

### isEnabled

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** boolean
* Whether this representation is enabled/visible

### opacity

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** number
* Opacity (0-1)

### position

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Offset from the placement authored in the editor, in metres, in the object's authored frame. Reads zero until a script, physics or a gesture moves the object; `worldPosition` is where the object is.

### representation

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity)
* Primary representation (visual/model)

### rotation

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [Rotation](https://scenery.app/docs/scripting/api/rotation)
* Rotation on top of the authored rotation, as a quaternion; identity until something turns the object, and `worldRotation` is its orientation in the scene. Assign a whole `Rotation`; per-component quaternion mutation is not meaningful, so use `rotation`/`eulerAngles` assignment or animateTo.

### scale

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Scale on top of the authored scale; one until something scales the object, and `worldScale` is its scale in the scene.

### transform

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* Position, rotation and scale on top of the authored placement, combined.

### worldBoundingBox

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox)
* World-space bounding box

### worldEulerAngles

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* World-space rotation as euler angles (radians)

### worldPosition

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* World-space position

### worldRotation

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [Rotation](https://scenery.app/docs/scripting/api/rotation)
* World-space rotation as quaternion

### worldScale

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* World-space scale

### worldTransform

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* World-space transform

## Methods

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

### animateBy()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
animateBy(properties: Object, duration: number, options?: Object): Promise<void>
```

Animate this entity's representation by relative values (additive animation)

**Parameters:**

* `properties` (Object) - Relative change values
* `duration` (number) - Animation duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** Promise\<void>

### animateFromTo()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
animateFromTo(fromProperties: Object, toProperties: Object, duration: number, options?: Object): Promise<void>
```

Animate this entity's representation from starting to target properties

**Parameters:**

* `fromProperties` (Object) - Starting property values
* `toProperties` (Object) - Target property values
* `duration` (number) - Animation duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** Promise\<void>

### animateTo()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
animateTo(properties: Object, duration: number, options?: Object): Promise<void>
```

Animate this entity's representation to target properties

**Parameters:**

* `properties` (Object) - Target properties to animate to
* `properties.position` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) *(optional)* - Target position
* `properties.rotation` ([Rotation](https://scenery.app/docs/scripting/api/rotation)) *(optional)* - Target rotation
* `properties.scale` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) *(optional)* - Target scale
* `properties.transform` ([Transform](https://scenery.app/docs/scripting/api/transform)) *(optional)* - Target transform (overrides position/rotation/scale)
* `properties.opacity` (number) *(optional)* - Target opacity (0-1)
* `duration` (number) - Animation duration in seconds
* `options` (Object) *(optional)* - Animation options
* `options.timingFunction` (string | Object) *(optional)* - Easing: "linear", "easeIn", "easeOut", "easeInOut", or custom
* `options.delay` (number) *(optional)* - Delay before animation starts (seconds)
* `options.repeatCount` (number) *(optional)* - Number of times to repeat (-1 for infinite)
* `options.repeatMode` (string) *(optional)* - "default", "autoReverse", or "cumulative"

**Returns:** Promise\<void>

### applyAngularImpulse()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
applyAngularImpulse(impulse: Vector3, options?: Object): Promise<void>
```

Spin this object with a one-off rotational force. Proxies to the primary representation.

**Parameters:**

* `impulse` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Rotational force around each axis.
* `options` (Object) *(optional)* - See `RepresentationEntity.applyAngularImpulse`.

**Returns:** Promise\<void>

### applyImpulse()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
applyImpulse(impulse: Vector3, options?: Object): Promise<void>
```

Push this object with a one-off force. Proxies to the primary representation.

**Parameters:**

* `impulse` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Force along each axis, in newton-seconds.
* `options` (Object) *(optional)* - See `RepresentationEntity.applyImpulse`.

**Returns:** Promise\<void>

### clearInstances()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
clearInstances(): void
```

Remove instancing from this object, reverting to the single base mesh. Proxies to the primary representation.

**Returns:** void

### clone()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
clone(options?: Object): Promise<ObjectEntity>
```

Deep-copy this object and add the copy to the scene.

The copy carries fresh ids, so it behaves like any other object – attach events, move it, remove it independently. Pose overrides merge into the copy's transform, so an omitted field keeps this object's value.

If this object was authored "disabled by default" (a common template pattern), the copy is added hidden with its physics body off until you `toggle(true)` it – so a batch can be revealed together on one frame.

Cloning rejects past 512 live copies of one source object. That ceiling exists only to stop a runaway loop (`while (true) clone()`) from exhausting memory – reaching it means a bug, not a budget. Remove copies you no longer need with `entity.remove()`.

**Example:**

```javascript
// Scatter ten copies of an editor-authored template.
const template = scene.findEntity('coin');
for (let i = 0; i < 10; i++) {
    await template.clone({ position: Vector3(i * 0.2, 0, -1), enabled: true });
}
```

**Parameters:**

* `options` (Object) *(optional)*
* `options.position` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) *(optional)* - World position for the copy.
* `options.rotation` ([Rotation](https://scenery.app/docs/scripting/api/rotation)) *(optional)* - Rotation for the copy.
* `options.scale` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) *(optional)* - Scale for the copy.
* `options.anchor` (Object) *(optional)* - An `Anchor.*` descriptor, replacing the anchor.
* `options.enabled` (boolean) *(optional)* - Reveal immediately (`true`) or keep
  deferred (`false`). Omit to inherit the source's disabled-by-default state.
* `options.id` (string) *(optional)* - Explicit id for the copy; generated otherwise.

**Returns:** Promise\<ObjectEntity>

### createAudioStream()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
createAudioStream(options?: Object): AudioStream
```

Create a streaming audio player on this entity

**Parameters:**

* `options` (Object) *(optional)* - Stream options

**Returns:** [AudioStream](https://scenery.app/docs/scripting/api/audiostream)

### findRepresentation()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
findRepresentation(query: any): RepresentationEntity
```

Find a representation by ID or name

**Example:**

```javascript
// By ID
var rep = entity.findRepresentation("ABC123");

// By name
var rep = entity.findRepresentation({ name: "Main Model" });
```

**Parameters:**

* `query` (any) - Representation ID string, or object with { id: "..." } or { name: "..." }

**Returns:** [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity)

### followPath() beta

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
followPath(path: Path, options?: Object): void
```

Move this entity along a path from scene.createPath(...).

**Parameters:**

* `path` ([Path](https://scenery.app/docs/scripting/api/path)) - Path handle from scene.createPath(...)
* `options` (Object) *(optional)* - { duration?: number, constantSpeed?: boolean, alignsToTangent?: boolean, timing?: "linear"|"easeIn"|"easeOut"|"easeInOut", repeat?: boolean|number }
* `options.repeat` (boolean | number) *(optional)* - true or -1 loops forever; a positive number loops that many times; false/0/omitted plays once.

**Returns:** void

### off()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
off(eventId: string): void
```

Remove an entity event listener

**Example:**

```javascript
var eventId = entity.on('tap', function() {});
// Later...
entity.off(eventId);
```

**Parameters:**

* `eventId` (string) - Event ID returned from on()

**Returns:** void

### on()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
on(type: string, options?: Object | function, listener?: function): string
```

Register an entity event listener

**Example:**

```javascript
entity.on('tap', function(event) {
    console.log('Entity tapped!');
});
```

**Parameters:**

* `type` (string) - Event type: "tap", "doubleTap", "longPress", "add", "collision", "distance", "lookAt", "mediaPlayback", "gesture"
* `options` (Object | function) *(optional)* - Event options or callback. For "longPress", `minimumDuration` (seconds) is optional.
* `listener` (function) *(optional)* - Callback if options provided

**Returns:** string

### once()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
once(type: string, options?: Object | function, listener?: function): string
```

Register a one-time entity event listener

**Example:**

```javascript
entity.once('tap', function(event) {
    console.log('First tap only!');
});
```

**Parameters:**

* `type` (string) - Event type
* `options` (Object | function) *(optional)* - Event options or callback
* `listener` (function) *(optional)* - Callback if options provided

**Returns:** string

### play()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
play(animation: Animation): Promise<void>
```

Play an animation on this entity's representation

**Parameters:**

* `animation` (Animation) - Animation object from Animation.to(), Animation.spin(), etc.

**Returns:** Promise\<void>

### playAudio()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
playAudio(source: string, options?: Object): Promise<void>
```

Play audio asset on this entity

**Example:**

```javascript
await entity.playAudio('assetId123', { loops: true, gain: 1.5 });
```

**Parameters:**

* `source` (string) - HTTPS URL or asset ID from project
* `options` (Object) *(optional)* - Playback options
* `options.gain` (number) *(optional)* - Volume gain (0.0 to 4.0, default 1.0)
* `options.loops` (boolean) *(optional)* - Loop playback
* `options.inputMode` (string) *(optional)* - "spatial", "nonSpatial", or "ambient"

**Returns:** Promise\<void>

### playAudioBuffer()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
playAudioBuffer(base64: string, options?: Object): Promise<void>
```

Play audio buffer on this entity

**Example:**

```javascript
await entity.playAudioBuffer(base64Data, { sampleRate: 24000 });
```

**Parameters:**

* `base64` (string) - Base64-encoded PCM audio data
* `options` (Object) *(optional)* - Buffer and playback options
* `options.sampleRate` (number) *(optional)* - Sample rate in Hz
* `options.channels` (number) *(optional)* - Number of channels (1 = mono, 2 = stereo)
* `options.format` (string) *(optional)* - Sample format: "pcm16" or "float32"
* `options.gain` (number) *(optional)* - Volume gain (0.0 to 4.0, default 1.0)

**Returns:** Promise\<void>

### remove()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
remove(): Promise<void>
```

Remove this entity from the scene

**Returns:** Promise\<void>

### setAngularVelocity()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
setAngularVelocity(angularVelocity: Vector3): void
```

Set the world-space angular velocity of this object's physics body (axis-angle, radians per second). Proxies to the primary representation.

**Parameters:**

* `angularVelocity` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - World-space angular velocity, axis-angle in rad/s.

**Returns:** void

### setInstances() beta

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
setInstances(transforms: Object | Array): void
```

GPU-instance this object's mesh – draw one copy per transform. Proxies to the primary representation. Pass `Instances.transforms([...])` or a bare array of `Transform` / `Vector3`. Rendering-only; gate with `environment.features.has('instancing')`.

**Parameters:**

* `transforms` (Object | Array) - An `Instances.*` handle, or a bare transforms array.

**Returns:** void

### setMaterial()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
setMaterial(options?: Object): Promise<void>
```

Set material on this entity's representation

**Parameters:**

* `options` (Object) *(optional)* - Material options, omit to clear

**Returns:** Promise\<void>

### setMaterials()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
setMaterials(materials: Array<Object>): Promise<void>
```

Set materials on this entity's representation

**Parameters:**

* `materials` (Array\<Object>) - Array of material options

**Returns:** Promise\<void>

### setPhysicsMode()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
setPhysicsMode(mode: string): void
```

Set the physics body mode at runtime. Proxies to the primary representation.

**Parameters:**

* `mode` (string) - `"static"`, `"kinematic"`, or `"dynamic"`.

**Returns:** void

### setVelocity()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
setVelocity(velocity: Vector3): void
```

Set the world-space linear velocity of this object's physics body. Proxies to the primary representation.

**Parameters:**

* `velocity` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - World-space velocity, in metres per second.

**Returns:** void

### stopAnimations()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
stopAnimations(options?: Object): Promise<void>
```

Stop and remove animations from this entity's representation

**Parameters:**

* `options` (Object) *(optional)* - Options
* `options.transitionDuration` (number) *(optional)* - Fade out duration in seconds

**Returns:** Promise\<void>

### stopAudio()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
stopAudio(): Promise<void>
```

Stop audio playback on this entity

**Returns:** Promise\<void>

### toggle()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
toggle(enabled: boolean): Promise<void>
```

Enable or disable this entity's representation

**Parameters:**

* `enabled` (boolean) - Enable (true) or disable (false)

**Returns:** Promise\<void>

### toggleAnimations()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
toggleAnimations(options?: Object): Promise<void>
```

Toggle (pause/resume) animations on this entity's representation

**Parameters:**

* `options` (Object) *(optional)* - Options
* `options.play` (boolean) *(optional)* - Explicit play (true) or pause (false), toggles if omitted
* `options.animationIds` (Array\<string>) *(optional)* - Specific animation IDs to toggle

**Returns:** Promise\<void>

### waitUntilReady()

Documentation source: [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity.md).

```javascript
waitUntilReady(): Promise<void>
```

Wait until this entity's primary representation has finished loading.

Convenience that proxies to `entity.representation.waitUntilReady()`. Resolves immediately if there's no primary representation.

**Returns:** Promise\<void>

---

Source page: RepresentationEntity

Source URL: https://scenery.app/docs/scripting/api/representationentity.md

# RepresentationEntity

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

Visual representation of an entity (model, shape, etc.)

Access via `entity.representation` or `entity.findRepresentation()`. Controls visual properties like opacity, transform, and material parameters.

**Example:**

```javascript
var rep = entity.representation;
rep.opacity = 0.5;
rep.position = Vector3(0, 1, 0);
rep.bindMaterialParameter("baseColor", "myColor");
```

## Properties

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

### boundingBox

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox)
* Local bounding box

### entity

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [ObjectEntity](https://scenery.app/docs/scripting/api/objectentity)
* Parent entity

### eulerAngles

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Rotation on top of the authored rotation, as euler angles in radians.

### id

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** string
* Unique representation identifier

### instances

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [InstanceData](https://scenery.app/docs/scripting/api/instancedata)
* The instance transform buffer, for handing to a compute kernel.

### isEnabled

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** boolean
* Whether this representation is enabled/visible

### light

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Light](https://scenery.app/docs/scripting/api/light)
* Light handle for this representation. Nil unless the kind is `.light`. Reads and writes go to the running scene, not the saved experience.

**Example:**

```javascript
var lamp = scene.findEntity({ name: 'Lamp' }).representation.light;
lamp.intensity = 4000;
lamp.color = Color.hex('#FFD9A0');
lamp.outerAngle = 50;
```

### mesh

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Mesh](https://scenery.app/docs/scripting/api/mesh)
* Dynamic mesh handle for this representation. Nil unless the kind is `.dynamicMesh`. Use this to write vertex/index buffers and update per-part bounds from a script. Bulk-copy semantics – one call moves many vertices, no per-element overhead.

**Example:**

```javascript
var mesh = entity.representation.mesh;
mesh.writeVertices("position", 0, new Float32Array([
    -0.25, 0.0, 0.0,
     0.25, 0.0, 0.0,
     0.0,  0.4, 0.0
]));
mesh.writeIndices(0, new Uint32Array([0, 1, 2]));
mesh.drawCount = 3;            // sugar for updatePart(0, { indexCount: 3 })
mesh.setBounds({ min: [-1,-1,-1], max: [1,1,1] });
```

### opacity

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** number
* Opacity (0-1)

### position

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Offset from the placement authored in the editor, in metres, in the object's authored frame. Reads zero until a script, physics or a gesture moves the object; `worldPosition` is where the object is.

### rootView

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [UIView](https://scenery.app/docs/scripting/api/uiview)
* Root view of the panel content. Nil unless this representation's kind is `.userInterface`.

**Example:**

```javascript
var root = rep.rootView;
root.setProperty("isHidden", true);
```

### rotation

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Rotation](https://scenery.app/docs/scripting/api/rotation)
* Rotation on top of the authored rotation, as a quaternion; identity until something turns the object, and `worldRotation` is its orientation in the scene. Assign a whole `Rotation`; per-component quaternion mutation is not meaningful, so use `rotation`/`eulerAngles` assignment or animateTo.

### scale

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Scale on top of the authored scale; one until something scales the object, and `worldScale` is its scale in the scene.

### splat

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Splat](https://scenery.app/docs/scripting/api/splat)
* Gaussian splat handle for this representation. Nil unless the kind is `.gaussianSplat`. Vends `count` and a read / write token per GPU attribute, for compute kernels.

**Example:**

```javascript
var splat = scene.findEntity({ name: 'Statue' }).representation.splat;
kernel.run({
    uniforms: new Float32Array([scene.time, splat.count]),
    inputBuffers:  { src: splat.position.read },
    outputBuffers: { dst: splat.position.write },
    threadGroups: [Math.ceil(splat.count / 64), 1, 1],
    threadsPerThreadgroup: [64, 1, 1]
});
```

### transform

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* Position, rotation and scale on top of the authored placement, combined.

### worldBoundingBox

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox)
* World-space bounding box

### worldEulerAngles

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* World-space rotation as euler angles (radians)

### worldPosition

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* World-space position

### worldRotation

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Rotation](https://scenery.app/docs/scripting/api/rotation)
* World-space rotation as quaternion

### worldScale

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* World-space scale

### worldTransform

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* World-space transform

## Methods

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

### animateBy()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
animateBy(properties: Object, duration: number, options?: Object): Promise<void>
```

Animate this representation by relative values

**Parameters:**

* `properties` (Object) - Relative change properties
* `duration` (number) - Animation duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** Promise\<void>

### animateFromTo()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
animateFromTo(fromProperties: Object, toProperties: Object, duration: number, options?: Object): Promise<void>
```

Animate this representation from starting to target properties

**Parameters:**

* `fromProperties` (Object) - Starting properties
* `toProperties` (Object) - Target properties
* `duration` (number) - Animation duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** Promise\<void>

### animateTo()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
animateTo(properties: Object, duration: number, options?: Object): Promise<void>
```

Animate this representation to target properties

**Parameters:**

* `properties` (Object) - Target properties (position, rotation, scale, opacity)
* `duration` (number) - Animation duration in seconds
* `options` (Object) *(optional)* - Animation options

**Returns:** Promise\<void>

### applyAngularImpulse()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
applyAngularImpulse(impulse: Vector3, options?: Object): Promise<void>
```

Spin this representation with a one-off rotational force.

The rotational counterpart of `applyImpulse`. There is no application point – an angular impulse acts on the body as a whole.

**Example:**

```javascript
// Put backspin on a thrown ball.
ball.applyAngularImpulse(Vector3(-0.02, 0, 0), { space: 'pointOfView' });
```

**Parameters:**

* `impulse` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Rotational force around each axis.
* `options` (Object) *(optional)*
* `options.space` (string | Object) *(optional)* - Coordinate frame. Same values as `applyImpulse`.

**Returns:** Promise\<void>

### applyImpulse()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
applyImpulse(impulse: Vector3, options?: Object): Promise<void>
```

Push this representation with a one-off force.

The object needs a dynamic physics body – see `t.physics({ mode: 'dynamic' })`.

**Example:**

```javascript
// Throw a ball away from the camera.
ball.applyImpulse(Vector3(0, 1, -6), { space: 'pointOfView' });
```

**Parameters:**

* `impulse` ([Vector3](https://scenery.app/docs/scripting/api/vector3)) - Force along each axis, in newton-seconds.
* `options` (Object) *(optional)*
* `options.space` (string | Object) *(optional)* - Coordinate frame for the impulse:
  `"local"` (the object's own orientation), `"world"` (absolute scene axes),
  `"pointOfView"` (relative to the camera), or `{ sceneObject }`.
* `options.at` ([Vector3](https://scenery.app/docs/scripting/api/vector3) | string) *(optional)* - Where the force is applied. A point in the
  chosen space, or `"userInteraction"` to use the point the user touched. Omit to
  push through the centre of mass (no resulting spin).

**Returns:** Promise\<void>

### bindMaterialParameter()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
bindMaterialParameter(parameterName: string, variableId: string, options?: any): void
```

Bind a material parameter to a variable for automatic updates

* scope: Variable scope - "segment" (default) or "experience"   - materialId: Target specific material by ID (optional, applies to all if omitted)   - slots: Target specific material slots as array of integers (optional)   - model: Target a single mesh by path ("/Root/…/foo") or name ("foo").     Omitted → bind every mesh that exposes the parameter. Call once per     mesh to target several.

**Example:**

```javascript
// Initialize variable
scene.setVariable("tintColor", Color.red());

// Bind parameter to variable
rep.bindMaterialParameter("baseColor", "tintColor");

// Now changing the variable updates the material automatically
scene.setVariable("tintColor", Color.blue());

// With experience scope
rep.bindMaterialParameter("intensity", "globalIntensity", { scope: "experience" });

// Target specific material
rep.bindMaterialParameter("emission", "glowAmount", {
    materialId: "glowMaterial",
    slots: [0]
});

// Target a single mesh (by name or path) – bind only that one, even if
// other meshes share the material.
rep.bindMaterialParameter("revealProgress", "reveal", { model: "_01_exterior_walls" });
```

**Parameters:**

* `parameterName` (string) - Name of the material parameter (must match the name the material exposes)
* `variableId` (string) - ID of the variable to bind
* `options` (any) *(optional)* - Configuration object (optional)

**Returns:** void

### clearInstances()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
clearInstances(): void
```

Remove instancing from this representation, reverting to the single base mesh.

**Returns:** void

### createAudioStream()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
createAudioStream(options?: Object): AudioStream
```

Create a streaming audio player on this representation

**Example:**

```javascript
var stream = entity.createAudioStream({ sampleRate: 24000 });
stream.append(base64Data);
stream.stop();
```

**Parameters:**

* `options` (Object) *(optional)* - Stream options
* `options.sampleRate` (number) *(optional)* - Input sample rate in Hz
* `options.channels` (number) *(optional)* - Number of channels (1 = mono, 2 = stereo)
* `options.format` (string) *(optional)* - Sample format: "pcm16" or "float32"

**Returns:** [AudioStream](https://scenery.app/docs/scripting/api/audiostream)

### findChild()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
findChild(name: string, recursive?: any): Entity
```

Find a nested entity by name within the model hierarchy

**Example:**

```javascript
var bone = rep.findChild("thumb_1");
bone.transform = hand.joints.thumbKnuckle.localTransform;
```

**Parameters:**

* `name` (string) - Entity name to find
* `recursive` (any) *(optional)* - Search all descendants (default: true)

**Returns:** [Entity](https://scenery.app/docs/scripting/api/entity)

### findRepresentation()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
findRepresentation(query: any): RepresentationEntity
```

Find a child representation by ID or name

**Example:**

```javascript
var child = rep.findRepresentation({ name: "wheel" });
child.rotation = Rotation(0, Math.PI, 0);
```

**Parameters:**

* `query` (any) - Representation ID string, or object with { id: "..." } or { name: "..." }

**Returns:** [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity)

### findView()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
findView(query: any): UIView
```

Find a view in this representation's UI tree by ID or name

**Example:**

```javascript
// By ID
var btn = rep.findView("save-btn");

// By name
var btn = rep.findView({ name: "Submit" });
```

**Parameters:**

* `query` (any) - View ID string, or object with `{ id: "..." }` or `{ name: "..." }`

**Returns:** [UIView](https://scenery.app/docs/scripting/api/uiview)

### followPath()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
followPath(path: Path, options: any): void
```

Move this entity along a path (from `scene.createPath`).

(default true), alignsToTangent?: boolean (default false), timing?: "linear" |   "easeIn" | "easeOut" | "easeInOut", repeat?: boolean | number }`.   `repeat`: `true`or`-1`loops forever; a positive number loops that many times;  `false`/`0\` / omitted plays once.

**Example:**

```javascript
var path = scene.createPath({ points: [[0,0,-1],[0.5,0.3,-1.5],[1,0,-2]] });
entity.followPath(path, { duration: 3, alignsToTangent: true, repeat: true });
```

**Parameters:**

* `path` ([Path](https://scenery.app/docs/scripting/api/path)) - A `Path` handle.
* `options` (any) - \`{ duration?: number (s, default 1), constantSpeed?: boolean

**Returns:** void

### getChildNames()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
getChildNames(): Array<any>
```

List all nested entity names (for discovery)

**Example:**

```javascript
var names = rep.getChildNames();
console.log(names); // ["wrist", "thumb_1", "thumb_2", ...]
```

**Returns:** Array\<any>

### off()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
off(eventId: string): void
```

Remove an event listener from this representation

**Parameters:**

* `eventId` (string) - Event ID returned from on()

**Returns:** void

### on()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
on(type: string, options?: Object | function, listener?: function): string
```

Register an event listener on this representation

**Example:**

```javascript
entity.representation.on('tap', function(event) {
    console.log('This representation tapped!');
});
```

**Parameters:**

* `type` (string) - Event type: "tap", "collision", "distance", etc.
* `options` (Object | function) *(optional)* - Event options or callback
* `listener` (function) *(optional)* - Callback if options provided

**Returns:** string

### once()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
once(type: string, options?: Object | function, listener?: function): string
```

Register a one-time event listener on this representation

**Example:**

```javascript
entity.representation.once('tap', function(event) {
    console.log('First tap on this representation!');
});
```

**Parameters:**

* `type` (string) - Event type
* `options` (Object | function) *(optional)* - Event options or callback
* `listener` (function) *(optional)* - Callback if options provided

**Returns:** string

### play()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
play(animation: Animation): Promise<void>
```

Play an animation on this representation

**Parameters:**

* `animation` (Animation) - Animation object from Animation.to(), Animation.spin(), etc.

**Returns:** Promise\<void>

### playAudio()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
playAudio(source: string, options?: Object): Promise<void>
```

Play audio asset on this representation

**Example:**

```javascript
await entity.playAudio('https://example.com/sound.mp3');
await entity.playAudio('assetId123', { loops: true, gain: 1.5 });
```

**Parameters:**

* `source` (string) - HTTPS URL or asset ID from project
* `options` (Object) *(optional)* - Playback options
* `options.gain` (number) *(optional)* - Volume gain (0.0 to 4.0, default 1.0)
* `options.loops` (boolean) *(optional)* - Loop playback
* `options.inputMode` (string) *(optional)* - "spatial", "nonSpatial", or "ambient"

**Returns:** Promise\<void>

### playAudioBuffer()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
playAudioBuffer(base64: string, options?: Object): Promise<void>
```

Play audio buffer spatially on this representation

**Example:**

```javascript
await entity.playAudioBuffer(base64Data, { sampleRate: 24000 });
```

**Parameters:**

* `base64` (string) - Base64-encoded PCM audio data
* `options` (Object) *(optional)* - Buffer and playback options
* `options.sampleRate` (number) *(optional)* - Sample rate in Hz
* `options.channels` (number) *(optional)* - Number of channels (1 = mono, 2 = stereo)
* `options.format` (string) *(optional)* - Sample format: "pcm16" or "float32"
* `options.gain` (number) *(optional)* - Volume gain (0.0 to 4.0, default 1.0)

**Returns:** Promise\<void>

### resetBlendShapeWeights()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
resetBlendShapeWeights(options?: Object): void
```

Reset all blend shape weights to zero

**Parameters:**

* `options` (Object) *(optional)* - Options (modelName, weightSetIndex, weightSetId)

**Returns:** void

### setAngularVelocity()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
setAngularVelocity(angularVelocity: Vector3): void
```

Set the world-space angular velocity of this representation's physics body (axis-angle, radians per second). The linear velocity is preserved. The rotational counterpart of `setVelocity` – e.g. give a thrown object spin.

**Parameters:**

* `angularVelocity` ([Vector3](https://scenery.app/docs/scripting/api/vector3))

**Returns:** void

### setBlendShapeWeights()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
setBlendShapeWeights(weights: Object | number, options?: Object): void
```

Update blend shape weights on this representation (for models with morph targets/blend shapes)

**Example:**

```javascript
// Make a character smile
representation.setBlendShapeWeights({ mouthSmileLeft: 1, mouthSmileRight: 1 });

// Animate a blink
representation.setBlendShapeWeights({ eyeBlinkLeft: 1, eyeBlinkRight: 1 });
await wait(0.15);
representation.setBlendShapeWeights({ eyeBlinkLeft: 0, eyeBlinkRight: 0 });

// Reset all weights to zero
representation.setBlendShapeWeights(0);
```

**Parameters:**

* `weights` (Object | number) - Blend shape name-value pairs, or a single number to set all weights
* `options` (Object) *(optional)* - Options
* `options.modelName` (string) *(optional)* - Target specific model by name (optional)
* `options.weightSetIndex` (number) *(optional)* - Weight set index to update
* `options.weightSetId` (string) *(optional)* - Weight set ID to update (alternative to index)

**Returns:** void

### setInstances()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
setInstances(transforms: any): void
```

GPU-instance this representation's mesh – draw one copy per transform, at a fraction of the cost of real entities. Pass `Instances.transforms([...])` (or a bare array of `Transform` / `Vector3`, where a `Vector3` places a copy at that position). Applies to every mesh in the representation.

Instances are **rendering-only** – no physics, collision, tap, or per-instance identity. Use them for pure visual repetition (a field of grass, a crowd, a particle-like scatter); keep real objects (`clone()`) for anything the user interacts with.

Gate with `environment.features.has('instancing')` – currently iOS 26 / visionOS 26 / macOS 26+; a no-op with a console warning below that floor.

A dense field of small copies aliases the directional light's shared shadow map into streaks. If you see that, author the object so it doesn't cast the projected shadow – add `.shadow({ directional: false })` to the descriptor you pass to `scene.createEntity(...)` (grounding and received shadows are unaffected).

* Note: needs a single mesh. A primitive always is one; a model is once its **Flatten**   adjustment is on. Otherwise nothing is instanced and the console says which meshes it   found; `rep.instances` stays `null`, which is how a script can tell. To instance one   node instead, `rep.findChild(name).setInstances(...)` takes that node's own space.

**Example:**

```javascript
const spots = [];
for (let i = 0; i < 200; i++) {
    spots.push(new Vector3((i % 20) * 0.2, 0, Math.floor(i / 20) * 0.2));
}
rep.setInstances(Instances.transforms(spots));
```

**Parameters:**

* `transforms` (any)

**Returns:** void

### setMaterial()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
setMaterial(options?: Object): Promise<void>
```

Set material on this representation

**Example:**

```javascript
// Apply material to all models
entity.representation.setMaterial({ id: 'redMaterial' });

// Apply to first model only
entity.representation.setMaterial({ 
    id: 'redMaterial',
    target: { type: 'firstModel' }
});

// Clear custom materials (restore originals)
entity.representation.setMaterial();
```

**Parameters:**

* `options` (Object) *(optional)* - Material options, omit to clear custom materials
* `options.id` (string) - Material reference ID from scene
* `options.target` (Object) *(optional)* - Target configuration
* `options.target.type` (string) *(optional)* - "allModels", "firstModel", or "selectedModels"
* `options.target.models` (Array\<string>) *(optional)* - Model names for selectedModels
* `options.target.materialSlots` (Array\<number>) *(optional)* - Material slot indices

**Returns:** Promise\<void>

### setMaterials()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
setMaterials(materials: Array<Object>): Promise<void>
```

Set materials on this representation

**Example:**

```javascript
// Apply multiple materials
entity.representation.setMaterials([
    { id: 'redMaterial', target: { type: 'firstModel' } },
    { id: 'blueMaterial', target: { type: 'selectedModels', models: ['body'] } }
]);

// Clear all custom materials (restore originals)
entity.representation.setMaterials([]);
```

**Parameters:**

* `materials` (Array\<Object>) - Array of material options
* `materials[].id` (string) - Material reference ID from scene
* `materials[].target` (Object) *(optional)* - Target configuration
* `materials[].target.type` (string) *(optional)* - "allModels", "firstModel", or "selectedModels"
* `materials[].target.models` (Array\<string>) *(optional)* - Model names for selectedModels
* `materials[].target.materialSlots` (Array\<number>) *(optional)* - Material slot indices

**Returns:** Promise\<void>

### setPhysicsMode()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
setPhysicsMode(mode: string): void
```

Set the physics body mode at runtime: `"static"`, `"kinematic"`, or `"dynamic"`.

A general-purpose primitive for composing mechanics in a script – e.g. hold an object by switching it to `kinematic` and driving it by position, then release it to `dynamic` so the simulation takes over. No-op if the representation has no physics body configured or the string isn't a valid mode.

**Example:**

```javascript
ball.setPhysicsMode('kinematic'); // hold: position-driven, ignores forces
ball.setPhysicsMode('dynamic');   // release: physics simulates it again
```

**Parameters:**

* `mode` (string)

**Returns:** void

### setVelocity()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
setVelocity(velocity: Vector3): void
```

Set the world-space linear velocity of this representation's physics body.

Only integrated while the body is `dynamic`; the current angular velocity is preserved. Use it to throw or launch an object with a velocity you computed yourself – for example the speed of a gesture flick.

**Example:**

```javascript
ball.setPhysicsMode('dynamic');
ball.setVelocity(Vector3(0, 2, -5)); // hurl it forward and up
```

**Parameters:**

* `velocity` ([Vector3](https://scenery.app/docs/scripting/api/vector3))

**Returns:** void

### stopAnimations()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
stopAnimations(options?: Object): Promise<void>
```

Stop and remove animations from this representation

**Parameters:**

* `options` (Object) *(optional)* - Options
* `options.transitionDuration` (number) *(optional)* - Fade out duration in seconds

**Returns:** Promise\<void>

### stopAudio()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
stopAudio(): Promise<void>
```

Stop audio playback on this representation

**Example:**

```javascript
entity.representation.stopAudio();
```

**Returns:** Promise\<void>

### toggle()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
toggle(enabled: boolean): Promise<void>
```

Enable or disable this representation

**Parameters:**

* `enabled` (boolean) - Enable (true) or disable (false)

**Returns:** Promise\<void>

### toggleAnimations()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
toggleAnimations(options?: Object): Promise<void>
```

Toggle (pause/resume) animations on this representation

**Parameters:**

* `options` (Object) *(optional)* - Options
* `options.play` (boolean) *(optional)* - Explicit play (true) or pause (false), toggles if omitted
* `options.animationIds` (Array\<string>) *(optional)* - Specific animation IDs to toggle (optional, toggles all if omitted)

**Returns:** Promise\<void>

### toggleWithAnimation()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
toggleWithAnimation(enable: boolean): void
```

Toggle visibility with fade animation

**Example:**

```javascript
rep.toggleWithAnimation(false); // Fade out
rep.toggleWithAnimation(true);  // Fade in
```

**Parameters:**

* `enable` (boolean) - Whether to show or hide

**Returns:** void

### unbindMaterialParameter()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
unbindMaterialParameter(parameterName: string, options?: any): void
```

Remove a variable binding from a material parameter

* materialId: Target specific material by ID (optional)   - slots: Target specific material slots (optional)   - model: Unbind only on a single mesh by path ("/Root/…/foo") or name     ("foo"). Omitted → unbind everywhere the parameter is bound. Mirrors     `bindMaterialParameter`.

**Example:**

```javascript
rep.unbindMaterialParameter("baseColor");
rep.unbindMaterialParameter("emission", { materialId: "glowMaterial" });
rep.unbindMaterialParameter("revealProgress", { model: "_01_exterior_walls" });
```

**Parameters:**

* `parameterName` (string) - Name of the material parameter to unbind
* `options` (any) *(optional)* - Configuration object (optional)

**Returns:** void

### waitUntilReady()

Documentation source: [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity.md).

```javascript
waitUntilReady(): Promise<void>
```

Wait until this representation's model assets have finished loading and been attached to the scene.

Many setup calls – `bindMaterialParameter`, transform reads, animation triggers – depend on the model being present. On `onWillAppear` the representation proxy exists but the model itself usually hasn't been attached yet, and calling those methods too early silently no-ops. Await this before any model-dependent setup.

**Example:**

```javascript
// On Cover Will Appear
var cover = scriptContext.sourceEvent.objectEntity.findRepresentation({ name: 'Cover' });
await cover.waitUntilReady();
cover.bindMaterialParameter('hueColor', 'myHue');
```

**Returns:** Promise\<void>

---

Source page: Entity

Source URL: https://scenery.app/docs/scripting/api/entity.md

# Entity

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

Generic entity within a model hierarchy (bones, groups, nested models)

Access via `representation.findChild()`. Allows manipulation of nested entities within loaded USDZ models.

**Example:**

```javascript
var bone = rep.findChild("thumb_1");
bone.rotation = hand.joints.thumbKnuckle.localTransform.rotation;

// Iterate children
rep.findChild("wrist").children.forEach(function(child) {
    console.log(child.name);
});
```

## Properties

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

### children

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** Array\<any>
* Direct child entities

### instances

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** [InstanceData](https://scenery.app/docs/scripting/api/instancedata)
* The instance transform buffer, for handing to a compute kernel. `null` until `setInstances(...)` has run, and on any OS below the instancing requirement.

### isEnabled

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** boolean
* Whether this entity is enabled/visible

### jointNames

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** Array\<any>
* Joint names for skeletal animation (empty if not a skeletal model)

### jointTransforms

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** Array\<any>
* Joint transforms array (parallel to jointNames)

### name

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** string
* Entity name

### opacity

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** number
* Opacity (0-1)

### position

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Local position relative to parent

### rotation

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** [Rotation](https://scenery.app/docs/scripting/api/rotation)
* Local rotation as quaternion

### scale

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Local scale

### transform

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* Local transform (position, rotation, scale combined)

### worldPosition

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* World-space position

### worldRotation

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** [Rotation](https://scenery.app/docs/scripting/api/rotation)
* World-space rotation

### worldTransform

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* World-space transform

## Methods

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

### clearInstances()

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

```javascript
clearInstances(): void
```

Remove instancing from this node, reverting to the single base mesh.

**Returns:** void

### findChild()

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

```javascript
findChild(name: string, recursive?: any): Entity
```

Find a child entity by name

**Example:**

```javascript
var bone = entity.findChild("thumb_1");          // recursive
var direct = entity.findChild("arm", false);     // immediate only
```

**Parameters:**

* `name` (string) - Entity name to find
* `recursive` (any) *(optional)* - Search all descendants (default: true)

**Returns:** [Entity](https://scenery.app/docs/scripting/api/entity)

### setInstances()

Documentation source: [Entity](https://scenery.app/docs/scripting/api/entity.md).

```javascript
setInstances(transforms: any): void
```

GPU-instance this node's mesh – draw one copy per transform. Pass `Instances.transforms([...])` (or a bare array of `Transform` / `Vector3`). Rendering-only (no physics / collision / identity). Gate with `environment.features.has('instancing')` (iOS 26 / visionOS 26 / macOS 26+).

**Parameters:**

* `transforms` (any)

**Returns:** void

---

Source page: Experience

Source URL: https://scenery.app/docs/scripting/api/experience.md

# Experience

Documentation source: [Experience](https://scenery.app/docs/scripting/api/experience.md).

## Properties

Documentation source: [Experience](https://scenery.app/docs/scripting/api/experience.md).

### currentScene

Documentation source: [Experience](https://scenery.app/docs/scripting/api/experience.md).

* **Type:** [Scene](https://scenery.app/docs/scripting/api/scene)
* The current scene

### environment

Documentation source: [Experience](https://scenery.app/docs/scripting/api/experience.md).

* **Type:** [Environment](https://scenery.app/docs/scripting/api/environment)
* Environment information (platform, OS version, locale)

### sharedActivity

Documentation source: [Experience](https://scenery.app/docs/scripting/api/experience.md).

* **Type:** [SharedActivity](https://scenery.app/docs/scripting/api/sharedactivity)
* Shared activity state (SharePlay, WebSocket, or other shared session protocols)

## Methods

Documentation source: [Experience](https://scenery.app/docs/scripting/api/experience.md).

### getVariable()

Documentation source: [Experience](https://scenery.app/docs/scripting/api/experience.md).

```javascript
getVariable(id: string): any
```

Get an experience-scoped variable

**Example:**

```javascript
var count = experience.getVariable('visitCount');
var name = experience.getVariable('userName');
```

**Parameters:**

* `id` (string) - Variable identifier

**Returns:** any

### setVariable()

Documentation source: [Experience](https://scenery.app/docs/scripting/api/experience.md).

```javascript
setVariable(id: string, value: any, options: any): void
```

Set an experience-scoped variable (persists across scene transitions)

**Example:**

```javascript
experience.setVariable('visitCount', 3);
experience.setVariable('userName', 'Alice');
experience.setVariable('lastPosition', Vector3(0, 1, 0), { type: 'vector3' });
```

**Parameters:**

* `id` (string) - Variable identifier
* `value` (any) - Value to store (number, string, boolean, Vector3, Color, etc.)
* `options` (any) - Optional type hint { type: "vector3" | "color" | ... }

**Returns:** void

### transitionToScene()

Documentation source: [Experience](https://scenery.app/docs/scripting/api/experience.md).

```javascript
transitionToScene(id: string): void
```

Transition to another scene

**Example:**

```javascript
experience.transitionToScene('chapter-2');
```

**Parameters:**

* `id` (string) - Scene identifier

**Returns:** void

---

Source page: Environment

Source URL: https://scenery.app/docs/scripting/api/environment.md

# Environment

Documentation source: [Environment](https://scenery.app/docs/scripting/api/environment.md).

## Properties

Documentation source: [Environment](https://scenery.app/docs/scripting/api/environment.md).

### deviceCategory

Documentation source: [Environment](https://scenery.app/docs/scripting/api/environment.md).

* **Type:** string
* The device form factor: "handheld" (iPhone, iPad), "spatial" (Apple Vision Pro and other headsets), or "desktop" (Mac, desktop web). Prefer this over `hostingPlatform` when branching on the *interaction model* rather than the exact OS – e.g. screen gestures exist on handheld and desktop but not spatial, where input is the user's eyes and hands.

**Example:**

```javascript
if (environment.deviceCategory === 'spatial') {
    showControlPanel();   // drive interaction from UI, not screen gestures
}
```

### features

Documentation source: [Environment](https://scenery.app/docs/scripting/api/environment.md).

* **Type:** [EnvironmentFeatures](https://scenery.app/docs/scripting/api/environmentfeatures)
* Runtime + device capability registry. Authors query by string – `environment.features.has('compute')` – to branch on whether the current platform supports a given feature. Mirrors WebGPU's `adapter.features.has(...)` shape so portable scripts read the same on both backends.

**Example:**

```javascript
if (environment.features.has('compute')) {
    mesh.runCompute('advect', { uniforms });
}
```

### hostingPlatform

Documentation source: [Environment](https://scenery.app/docs/scripting/api/environment.md).

* **Type:** string
* The platform running the experience: "iOS", "macOS", "visionOS", or "web"

### isEditing

Documentation source: [Environment](https://scenery.app/docs/scripting/api/environment.md).

* **Type:** boolean
* `true` when the experience is running inside the Scenery editor's scene preview, `false` during normal playback. Lets scripts gate debug overlays, skip intros, or auto-fill placeholder state while the author is iterating.

**Example:**

```javascript
// Show a debug HUD only while editing.
if (environment.isEditing) {
    scene.findEntity('debug-hud').isEnabled = true;
}
```

### locale

Documentation source: [Environment](https://scenery.app/docs/scripting/api/environment.md).

* **Type:** string
* User's locale in BCP 47 format, e.g. "en-US", "de-DE"

### location

Documentation source: [Environment](https://scenery.app/docs/scripting/api/environment.md).

* **Type:** [Location](https://scenery.app/docs/scripting/api/location)
* The user's device location. Coarse reads ride the base grant; the precise tier is opted into explicitly. See `Location`.

**Example:**

```javascript
await environment.location.requestAccess();
const here = await environment.location.current();
```

### systemOSVersion

Documentation source: [Environment](https://scenery.app/docs/scripting/api/environment.md).

* **Type:** string
* Operating system version string, e.g. "18.0" or "2.0"

---

Source page: EnvironmentFeatures

Source URL: https://scenery.app/docs/scripting/api/environmentfeatures.md

# EnvironmentFeatures

Documentation source: [EnvironmentFeatures](https://scenery.app/docs/scripting/api/environmentfeatures.md).

Capability registry exposed at `environment.features`.

Set-style membership semantics: `has(name)` returns `false` for any name it doesn't recognise, so forward-looking scripts can query features that may land in a later runtime version without crashing on today's runtime. See the Available Features table below for the queryable strings and what each gates, and the Feature Detection guide for the full per-platform matrix. Use `list()` for the live set on the current device / runtime.

## Available Features

Documentation source: [EnvironmentFeatures](https://scenery.app/docs/scripting/api/environmentfeatures.md).

Every string you can pass to `has()` (and that `list()` may return). Support varies by platform and runtime version – see the [Feature Detection](https://scenery.app/docs/scripting/guide/feature-detection) guide for the full per-platform matrix.

| Feature | Availability |
| --- | --- |
| `'compute'` | GPU compute-kernel dispatch on dynamic meshes via `Kernel.fromSource(...)` + `mesh.runCompute(...)`. Currently Apple-GPU only, on iOS 18 / visionOS 2 / macOS 15+ with an Apple-7-family GPU or later (A14 / M1 and newer – A13 is `apple6`); `false` on older devices and unsupported simulators. Web / WebXR support is planned. |
| `'dynamicMesh'` | Scriptable dynamic mesh creation via `createMesh(...)` + `entity.representation.mesh`. Gated only by the OS floor (iOS 18 / visionOS 2 / macOS 15+). |
| `'sharedActivities'` | Multi-user / SharePlay session support. `true` when the app build includes it; `false` in the App Clip and builds where it isn't included. |
| `'cameraFeed'` | Live camera-feed texture (via `Texture.cameraFeed()`). Currently iPhone / iPad only – not Mac, and visionOS uses a different passthrough surface. |
| `'screenGestures'` | Screen-space drag / pinch / rotate gestures – `scene.on('pan'\|'pinch'\|'rotate')` and the `consume` camera claim. Wired on iPhone / iPad / Mac (a flat screen with a one-finger pan). On Apple Vision Pro input is spatial (eyes + pinch), so these screen gestures aren't delivered – drive interaction from UI panels / buttons there instead. Gate a portable script on this and fall back accordingly. |
| `'instancing'` | GPU mesh instancing via `rep.setInstances(...)` – render hundreds of copies of a mesh with per-instance transforms at a fraction of the cost of real entities. Rendering-only (no physics / collision / per-instance identity). Requires iOS 26 / visionOS 26 / macOS 26+. |
| `'softShadows'` | Blurred shadow edges on a spot light – `shadow: { edges: 'soft' \| 'softer' }` on `createSpotLight(...)`. Where this is false the light still casts, with a hard edge, and `lightSize` does nothing. Point lights cast no shadow at all on any OS, which is a model fact rather than a platform one. |
| `'shadowCascades'` | Splitting a directional light's shadow across several maps – `shadow: { cascades }`. Where this is false the light uses one map, which is what every OS below the flag does. |
| `'projectedLightTexture'` | A texture a spot light projects through its cone – `projectedTexture` on `createSpotLight(...)`, and `light.projectedTextureRotation`. Where this is false the light projects a plain cone and the texture is ignored. |
| `'surroundingsLight'` | Letting a spot or point light spill onto real surfaces rather than only onto virtual objects. Apple declares this unavailable on iOS and Mac Catalyst outright, so of the platforms this app ships it exists on Apple Vision Pro alone – a portable script must not assume a lit room. |
| `'bloom'` | Scene-wide bloom via `scene.setBloom(...)`. Needs both a new enough OS and an Apple-7-family GPU (A14 / M1 and newer), so it is false on hardware where the rest of the scene renders fine. On visionOS it additionally needs an immersive space, which nothing outside the running app can report. |
| `'toneMapping'` | A custom tone curve via `scene.setToneMapping(...)`. Where this is false the scene keeps the platform's default curve. |
| `'handTracking'` | Articulated hand-joint tracking via `scene.tracking.hands` – opt into the hand-tracking provider and read (or script-drive) per-joint transforms without planting a hand-anchored element. Currently Apple Vision Pro only; the hand-tracking data provider is a visionOS capability. `false` on iOS / iPadOS / Mac. |
| `'splats'` | Gaussian splat captures via `createSplat(...)` and `entity.representation.splat`. Needs iOS 27 / visionOS 27 / macOS 27 on a device; neither simulator can render them. Where this is false, `entity.representation.splat` is `null`. |

## Methods

Documentation source: [EnvironmentFeatures](https://scenery.app/docs/scripting/api/environmentfeatures.md).

### has()

Documentation source: [EnvironmentFeatures](https://scenery.app/docs/scripting/api/environmentfeatures.md).

```javascript
has(name: string): boolean
```

Whether the named feature is supported on the current platform and runtime version. Unknown names return `false` (WebGPU `Set.has` semantic).

**Example:**

```javascript
if (environment.features.has('compute')) {
    mesh.runCompute('advect', { uniforms });
} else {
    stepOnCPU();
}
```

**Parameters:**

* `name` (string) - Feature identifier; call `list()` for the set supported on this device/runtime.

**Returns:** boolean

### list()

Documentation source: [EnvironmentFeatures](https://scenery.app/docs/scripting/api/environmentfeatures.md).

```javascript
list(): string[]
```

Every feature string currently supported on this device/runtime. Useful for debugging ("why isn't my branch firing?") and for reflecting the capability set into telemetry.

**Example:**

```javascript
console.log(environment.features.list());
// → ['sharedActivities']
```

**Returns:** string\[]

---

Source page: Location beta

Source URL: https://scenery.app/docs/scripting/api/location.md

# Location beta

Documentation source: [Location beta](https://scenery.app/docs/scripting/api/location.md).

The user's device location, exposed to scripting as `environment.location`. Coarse reads ride the base grant; precise accuracy is an explicit opt-in.

## Properties

Documentation source: [Location beta](https://scenery.app/docs/scripting/api/location.md).

### accuracyAuthorization beta

Documentation source: [Location beta](https://scenery.app/docs/scripting/api/location.md).

* **Type:** string
* Current accuracy authorization: "full" | "reduced" | "unknown".

### authorizationStatus beta

Documentation source: [Location beta](https://scenery.app/docs/scripting/api/location.md).

* **Type:** string
* Current authorization: "notDetermined" | "denied" | "restricted" | "granted".

## Methods

Documentation source: [Location beta](https://scenery.app/docs/scripting/api/location.md).

### current() beta

Documentation source: [Location beta](https://scenery.app/docs/scripting/api/location.md).

```javascript
current(options?: Object): Promise<GeoCoordinate>
```

Read the current location once.

**Example:**

```javascript
await environment.location.requestAccess();
const here = await environment.location.current();
console.log(here.latitude, here.longitude, '±' + here.horizontalAccuracy + 'm');
```

**Parameters:**

* `options` (Object) *(optional)* - { timeout?: number (seconds), maximumAge?: number }

**Returns:** Promise\<GeoCoordinate>

### on() beta

Documentation source: [Location beta](https://scenery.app/docs/scripting/api/location.md).

```javascript
on(event: string, callback: function): any
```

Subscribe to a location event. Supported: 'authorizationchange' → callback(status).

**Parameters:**

* `event` (string)
* `callback` (function)

**Returns:** any

### requestAccess() beta

Documentation source: [Location beta](https://scenery.app/docs/scripting/api/location.md).

```javascript
requestAccess(): Promise<string>
```

Request base location access. Prompts once if undetermined; resolves the resulting authorization status. Reads never prompt on their own.

**Returns:** Promise\<string>

### requestPreciseAccess() beta

Documentation source: [Location beta](https://scenery.app/docs/scripting/api/location.md).

```javascript
requestPreciseAccess(options?: Object): Promise<boolean>
```

Request precise (full) accuracy. Shows a confirmation carrying `options.reason` (once per run), then the OS accuracy prompt. Resolves whether precise is now active.

**Example:**

```javascript
const precise = await environment.location.requestPreciseAccess({ reason: 'to guide you to nearby places' });
if (precise) { const here = await environment.location.current(); }
```

**Parameters:**

* `options` (Object) *(optional)* - { reason?: string }

**Returns:** Promise\<boolean>

### watch() beta

Documentation source: [Location beta](https://scenery.app/docs/scripting/api/location.md).

```javascript
watch(onPosition: any, options?: Object): any
```

Observe location continuously. `onPosition` receives a GeoCoordinate.

**Example:**

```javascript
// Geofence: report distance to a target, act once within 50 m, then stop watching.
const target = new GeoCoordinate(48.1372, 11.5756);
const sub = environment.location.watch(here => {
    const metres = here.distanceTo(target);
    console.log('distance to target', Math.round(metres), 'm');
    if (metres < 50) { sub.stop(); scene.setVariable('arrived', true); }
});
```

**Parameters:**

* `onPosition` (any)
* `options` (Object) *(optional)* - { onError?: function(string) }: called with "denied" when location access is withdrawn, or "unavailable" when Core Location fails.

**Returns:** any

---

Source page: AnchorData

Source URL: https://scenery.app/docs/scripting/api/anchordata.md

# AnchorData

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

## Properties

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

### alignment

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** string
* Plane alignment: "horizontal" or "vertical" (plane anchors only)

### altitude

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** number
* Altitude in meters (geo anchors only, iOS)

### blendShapes

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** Array\<any>
* Blend shape coefficients for facial expressions

**Example:**

```javascript
var faces = scene.getAnchors("face");
if (faces.length > 0) {
    var face = faces[0];
    var smile = (face.blendShapes.mouthSmileLeft + face.blendShapes.mouthSmileRight) / 2;
    var blink = face.blendShapes.eyeBlinkLeft;
    console.log("Smile:", smile, "Blink:", blink);
}
```

### chirality

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** string
* Hand chirality: "left" or "right" (hand anchors only, visionOS)

### classification

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** string
* Plane classification: "floor", "ceiling", "wall", "table", "seat", "window", "door" (plane anchors only)

### estimatedScaleFactor

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** number
* Estimated scale factor of detected image (image anchors only)

### height

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** number
* Plane height in meters (plane anchors only)

### id

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** string
* Unique identifier for this anchor

### isTracked

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** boolean
* Whether this anchor is currently being tracked (image, face, hand anchors)

### joints

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** Array\<any>
* Hand joint transforms by name

**Example:**

```javascript
var hand = scene.getAnchors("hand")[0];
if (hand.chirality === "left") {
    var indexTip = hand.joints.indexFingerTip.worldTransform;
    console.log("Index finger at:", indexTip.position);
}
```

### kind

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** string
* Anchor type: "plane", "hand", "face", "image", "world", "geo", "mesh"

### latitude

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** number
* Geographic latitude in degrees (geo anchors only, iOS)

### leftEyeTransform

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* Left eye transform in face coordinate space (face anchors only)

### longitude

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** number
* Geographic longitude in degrees (geo anchors only, iOS)

### lookAtPoint

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Estimated gaze direction point in face coordinate space (face anchors only)

**Example:**

```javascript
var face = scene.getAnchors("face")[0];
var lookAt = face.lookAtPoint;
// Position object where user is looking
object.position = Vector3(
    face.worldTransform.position.x + lookAt.x,
    face.worldTransform.position.y + lookAt.y,
    face.worldTransform.position.z - 0.5
);
```

### name

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** string
* Optional name for this anchor

### orderedJointTransforms

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** Array\<any>
* Ordered joint transforms for skeletal animation (hand anchors only)

**Example:**

```javascript
var model = rep.findChild("locator1");
var hand = scene.getAnchors("hand")[0];

var transforms = model.jointTransforms;
hand.orderedJointTransforms.forEach(function(t, index) {
    transforms[index].rotation = t.rotation;
});
model.jointTransforms = transforms;
```

### referenceImageName

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** string
* Reference image name from ARReferenceImage (image anchors only)

### rightEyeTransform

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* Right eye transform in face coordinate space (face anchors only)

### width

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** number
* Plane width in meters (plane anchors only)

### worldTransform

Documentation source: [AnchorData](https://scenery.app/docs/scripting/api/anchordata.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* World-space transform matrix for anchor position and orientation

---

Source page: CollisionCastHit

Source URL: https://scenery.app/docs/scripting/api/collisioncasthit.md

# CollisionCastHit

Documentation source: [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit.md).

Result from scene.raycast() when ray intersects an entity or scene mesh

## Properties

Documentation source: [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit.md).

### distance

Documentation source: [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit.md).

* **Type:** number
* Distance from ray origin to hit point

### faceIndex

Documentation source: [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit.md).

* **Type:** number | null
* Index of the triangle face that was hit (iOS 18+, mesh collisions only)

### normal

Documentation source: [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* Surface normal at hit point

### position

Documentation source: [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit.md).

* **Type:** [Vector3](https://scenery.app/docs/scripting/api/vector3)
* World-space position where ray hit the entity

### representation

Documentation source: [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit.md).

* **Type:** [RepresentationEntity](https://scenery.app/docs/scripting/api/representationentity)
* The entity that was hit (nil for scene mesh hits)

### shapeIndex

Documentation source: [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit.md).

* **Type:** number | null
* Index of the shape within the entity that was hit (iOS 18+)

### type

Documentation source: [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit.md).

* **Type:** string
* Hit type - "representation" or "sceneMesh"

### uv

Documentation source: [CollisionCastHit](https://scenery.app/docs/scripting/api/collisioncasthit.md).

* **Type:** [Vector2](https://scenery.app/docs/scripting/api/vector2)
* Barycentric UV coordinate on the triangle (iOS 18+, mesh collisions only)

---

Source page: ARRaycastResult

Source URL: https://scenery.app/docs/scripting/api/arraycastresult.md

# ARRaycastResult

Documentation source: [ARRaycastResult](https://scenery.app/docs/scripting/api/arraycastresult.md).

Result from scene.raycastAR() when ray intersects real-world surfaces

## Properties

Documentation source: [ARRaycastResult](https://scenery.app/docs/scripting/api/arraycastresult.md).

### anchor

Documentation source: [ARRaycastResult](https://scenery.app/docs/scripting/api/arraycastresult.md).

* **Type:** [AnchorData](https://scenery.app/docs/scripting/api/anchordata)
* Associated plane anchor if hit was on a tracked plane (nil for estimated surfaces)

### target

Documentation source: [ARRaycastResult](https://scenery.app/docs/scripting/api/arraycastresult.md).

* **Type:** string
* Type of target that was hit: "existingPlaneGeometry", "existingPlaneInfinite", "estimatedPlane"

### targetAlignment

Documentation source: [ARRaycastResult](https://scenery.app/docs/scripting/api/arraycastresult.md).

* **Type:** string
* Surface alignment: "horizontal", "vertical", "any"

### worldTransform

Documentation source: [ARRaycastResult](https://scenery.app/docs/scripting/api/arraycastresult.md).

* **Type:** [Transform](https://scenery.app/docs/scripting/api/transform)
* World transform matrix at hit location

