# FAQ and Release History

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: FAQ; bug; support; release; changelog; old API; deprecated.

## Contents

- Changelog
- FAQ
- Changelog

---

Source page: Changelog

Source URL: https://scenery.app/docs/guide/changelog.md

# Changelog

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

What changed in each version of Scenery, newest first.

Looking for the scripting runtime instead? See the
[scripting changelog](https://scenery.app/docs/scripting/guide/changelog).

## 1.3.0 – November 2026&#x20;

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

::: info In testing
This version is on TestFlight and has not reached the App Store yet.
:::

Call any API from your scripts without giving away your key, debug live on any device, and see what your experience holds before you share it.

### Added

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Secrets let your scripts use any API without giving away your key.** Store the key once on your account and call the API by name. Viewers can open and read your experience, but never your key. Available on the Pro and Agency plans.
* **Debug live on any device with the console.** See what your scripts log and try JavaScript on the running experience on Mac, iPad, iPhone and Apple Vision Pro, docked or in its own window.
* **See what your experience holds before you share it.** The Summary tab in the bottom drawer shows its scenes, content and logic, how much a viewer downloads, its largest files, and anything missing.

### Improved

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Google 3D surroundings start at ground level.** You see the real place around your scene in the editor, with the floor already set close to the ground, and fine-tune it only when you need to.
* **The runtime picker lists every released scripting runtime.**
* **Smoother scrolling and animations on Mac** when an experience is open on an external display.

### Fixed

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **"Use 2D Tiles" after a 3D tile error keeps the editor open.**
* **Objects you preload appear right away.**
* **A repeating Physics Event fires once per collision.**
* **Post-processing effects stack in the order you set.**
* **Audio analysis events react only to their own sound.**
* **Custom shader materials look right on every part of an object.**
* **An object anchored to another element keeps its height** when its Y position and Y scale are locked.
* **Scripts hear when a viewer takes a photo or video.** `scene.on('snapshot')` fires after a photo is taken during playback and `scene.on('recording')` after a video recording ends, on iPhone and iPad.
* **Gaussian splats from PLY-based tools can be turned the right way up.** Set **Source Coordinates** to **PLY / OpenCV (Y down)** in a capture's Gaussian Splat section when an export from SuperSplat, ply\_to\_spz or a similar tool appears upside down. Files that record their orientation set it for you.
* **The hierarchy sidebar hides on iPad in portrait.** The sidebar button in the top left toolbar hides and shows it in every orientation again.

## 1.2.3 – October 2026

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

Scripting and the UI editor for Pro and Agency plans, and fixes for UI panels.

### Added

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Scripting and the UI editor are available on the Pro and Agency plans.** They used to be unlocked by hand. On a free account, Run Script, the scripting triggers and Add User Interface are marked Pro and open the plan offer.

### Fixed

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Images in UI panels react to taps.** The editor offers the tap event for image views, as it does for buttons.
* **Labels, images and shapes without a tap event let touches through** to the scene behind a panel, instead of blocking them.
* **No more "Asset Error: invalid URL" for something you never set,** such as a post-processing effect, texture or object anchor added without a file.
* **A model inside a container keeps its "Autoplay Model Animations" setting.** With autoplay off, its animation no longer loops on its own when the container is anchored to a hand, an image or another tracked target.

## 1.2.2 – October 2026

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

Fixes across the App Clip, the editor and scripting: experiences restricted to a place, private links, the direction arrow, colours, text fields and Live Refresh.

### Fixed

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Opening an experience restricted to a place no longer loads forever** in the App Clip when you allow location for the first time. It tells you how far away you are and offers directions, and cancelling or choosing a maps app closes the experience instead of leaving it on screen.
* **A link to a private experience says so straight away** instead of showing a technical error after several seconds.
* **The direction arrow points the right way** when what it guides you to is behind you, and stops pointing at an object once that object has been removed (Scavengar/scenery-ios-macos\_-bugs#407).
* **Loading spinners animate** when the App Clip first opens, instead of standing still.
* **⌘F frames the selected object in the editor again.** It stopped working in 1.2.1, and it is listed in the Viewport menu now.
* **Material colours keep their value after you close the editor,** instead of coming back black when you picked a vivid colour (Scavengar/scenery-ios-macos\_-bugs#353). The same fix covers the surroundings tint and the editor's other colour pickers (#320).
* **The direction arrow animates in** instead of popping up, and guidance set to Initial stops once you have seen the object. The arrow appears as soon as the object leaves the screen, rather than only after you turn well past it, and an object counts as in view while any part of it is on screen.
* **Live Refresh restarts the scene you are editing** instead of the first scene (#325).
* **Buttons on a light brand colour get dark text** instead of white (#295).
* **Reset Element Physics keeps the object you pick** (#319), and old Set Opacity actions no longer open an empty panel (#280).
* **Descriptions, intro and outro texts keep spaces, punctuation and accented letters** while you type (#266).
* **A spin, emphasis or path animation inside a group plays** instead of being skipped (#269).
* **The App Clip explains that it needs the camera** when access is denied, instead of showing "Unknown error" (#258).
* **The script editor no longer shows "Failed to save"** while you type (#386).
* **An asset name longer than the limit can be shortened** (#315), and a shader effect with a blank name shows its default name (#352).

## 1.2.1 – September 2026

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

Experiences that only start where they belong, your own brand on captures, and a UI editor that works like the main editor.

### Added

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Restrict an experience to a place.** Experience Settings › Information & Discovery has a switch that binds an experience to a spot on the map with a radius, and it only starts inside that area. Anyone further away is offered directions. Pick the place by address or on the map, with the area drawn around it. You and your team can still start it from anywhere, so you can check it without standing at it. Requires Pro.
* **Keep Scenery's branding out of your experiences.** With Advanced Branding, Experience Settings › Branding has a switch that hides the Scenery branding, and new experiences on that plan start with it on. Shared captures now carry the author's logo alone, sized to fit, and no logo at all when the experience has none.
* **Icon-only buttons.** A button with an icon can drop its title.
* **Keep a panel out of photos and videos.** A screen-anchored UI panel has a Hide in Captures switch, and it disappears while someone takes a photo or records a video, so a shared capture shows the scene without your HUD over it. A panel placed in the world is part of the scene and stays in the capture.
* **Tab moves to the next field** in the inspector and the UI editor, row by row, and Shift-Tab moves back.
* **The UI editor opens at the size of the editor window** and resizes with it. Its navigator and inspector sit side by side with the canvas and can be resized, the same as in the main editor.

### Fixed

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **In the App Clip, scanning a new code replaces the running experience without asking,** and nothing from the previous experience fires into the new one. Finishing an experience no longer takes over the screen with a full-screen pitch.
* **Screen-space panels fade in and out** instead of popping, and images on them are as sharp as in the web viewer. Panel images no longer show a grey photo placeholder while they load.
* **Animations set to auto-reverse loop** instead of playing once.
* **The camera moves at the same speed on every display** outside AR.
* **Replace With… in the UI editor** no longer leaves an empty label behind.
* **The placement message in the App Clip** reads "Placement Complete" instead of an internal key.
* **⌘S saves again in the editor.** It moved the camera instead, as did ⌘W, ⌘A and ⌘D, and the number and arrow shortcuts went the same way.
* **When you are too far from an experience,** the message says how far away you are, in the units your device uses. If the app cannot get your location it says so and offers Settings, rather than reporting an unknown error.
* **Tooltips are as tall as their text** instead of always standing at their maximum height.
* **Images and buttons on a screen-space panel keep their size** when tracking resets, instead of jumping to their full resolution (Scavengar/scenery-ios-macos\_-bugs#405).

## 1.2.0 – September 2026

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

Gaussian splats, experiences that run offline, large scenes that open in seconds, and Quit and Close that work while a panel is open on Mac.

### Added

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Gaussian splats.** Import a scanned capture as an SPZ file and place it like any other object. Needs iOS 27, iPadOS 27, macOS 27 or visionOS 27.
* **Take an experience offline.** Right-click an experience and choose **Download for Offline Use**,
  or use **Save Offline** on its detail card, and it runs with no network at all – models, audio,
  video and scripts included. A ring fills in the card's corner while it downloads, tap it to stop,
  and downloaded experiences carry an **Offline** badge. They gather under a **Downloaded** filter in
  your experience library and in a section of Discover, both of which keep working when the device
  has no connection. When the author changes an experience you have downloaded, the badge reads
  **Update Available** and the menu offers **Update Download**; nothing is ever re-downloaded behind
  your back, so a device set up for a fair or an event stays exactly as you left it. Your own
  experiences and your team's are always downloadable, whatever your role on the team. For anyone
  else's, the author decides: **Allow Offline Download** in Experience Settings, beside Allow
  Featuring. It is off by default, because a downloaded copy keeps working after an experience is
  withdrawn.

### Fixed

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **⌘Q and ⌘W work on Mac while a panel like Settings is open.**
* **Lights react to taps and physics when an experience plays.**
* **The Scenery logo on a shared photo is the right size again.** It was rendering at roughly half
  the size it was designed for, small enough to be easy to miss, on every capture shared from the
  app.
* **A toast that has been swiped away comes back.** Dismissing a notification banner with a swipe
  left it in place invisibly, and every later banner was silently refused. Banners also lost their
  background from the second one onwards, and stopped responding to taps once dismissed.
* **Experiences with large models open in seconds instead of minutes.** A scene whose models carry a
  lot of separate parts could sit on the loading screen for well over a minute on Mac. The same scene
  now loads in a few seconds. Placing one model several times in a scene no longer costs anything
  extra either, where before each copy was loaded from scratch.
* **The app no longer freezes after opening a few experiences in a row.** Quitting an experience
  while it was still settling left the whole session in memory, so the third or fourth one you
  opened could stall on a single frame, and sound from an experience you had left kept playing.

## 1.1.21 – August 2026

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

Bloom, scenes that can start on a wall or a table rather than only on the floor, objects are named
when you create them, plus fixes for interface panels on Apple Vision Pro and for panels that size
themselves.

### Added

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Seat an object against a wall, not through it.** Pivot Adjustment now offers all six faces –
  Left, Right, Front and Back alongside Top, Center and Bottom. **Back** hangs a model flat against
  an upright surface the way **Bottom** stands one on a floor. Without it a solid object placed on a
  wall sits on its own centre, so half of it ends up inside the wall.

* **Choose where a scene starts.** A new **Placement** section in Scene Settings decides how a
  scene finds its place in the real world: the viewer places it, the experience places it
  automatically, or it's anchored to a printed marker. Pick the surface it targets – a horizontal
  one for floors and tables, a vertical one for walls – and narrow that to a kind of surface if you
  want a scene that only ever appears on a table, or only on a wall. Existing experiences keep
  behaving exactly as they did: the viewer places them on the floor. Placement moves the scene and
  turns it to face the surface, never tilting it, so what you compose standing upright arrives
  standing upright, on a wall as on a floor.

* **Tell an experience how much room it needs.** Automatic placement takes a minimum size in
  metres, so a scene won't land on a surface too small to hold it, and won't sit so close to the
  edge of a table that it hangs off. On the floor it sets how far ahead of the viewer the scene
  starts.

* **Markers as a placement method.** A printed image that anchors the whole scene is now one of the
  placement methods rather than a separate setting, so it's clear which one is establishing the
  scene's position.

* **Choose how a location-based experience localizes.** Geo experiences can now be set to
  **Marker-Based** or **Manual** instead of automatic visual positioning – for places the map data
  doesn't reach, or indoors.

* **A way out of a marker hunt.** A viewer who doesn't have the marker with them can tap **Place
  Manually** – or **Localize Manually** in a location-based experience – and position the scene
  themselves, instead of waiting for a marker that isn't coming.

* **Hide and show from the context menu.** Right-click or long-press an object or its content to
  hide it while you work. Previously this was only reachable by hovering the row, which meant it
  couldn't be reached at all on iPad.

* **Turn off the placement confirmation.** The brief message shown once a scene has its place can
  be switched off in Scene Settings, for an experience that should begin without interruption.

* **Hide the pause and capture controls per scene.** Two new switches in Scene Settings › General.
  Pause controls covers every platform at once: the button in the top left corner on iPhone, iPad
  and Mac, the one on your hands on Apple Vision Pro. Turn the capture button off for scenes where
  taking a photo would give viewers the wrong idea about what the experience does. The pause menu
  is the only way to leave an experience, so if you hide it, give viewers another route in with the
  Pause Experience action.

* **Objects are named when you create them.** A new object arrives as "Object 1", "Object 2" and
  so on – a real name you can see in the inspector, rename, and use from a script straight away.
  Previously the hierarchy showed a label that was only a stand-in: the Name field looked empty,
  and `scene.findEntity({ name: 'Object 1' })` found nothing. Names also stay put now, where the
  old labels renumbered themselves whenever you reordered the scene. Objects in existing
  experiences are left exactly as they are.

* **Copy Name** – right-click an object or its content to copy its name, ready to paste into a
  script. It stays visible but dimmed when nothing has been named yet.

* **Lights.** Add a light the way you add anything else, from the Add menu: a spot for a cone of
  light you aim, a point light that glows in every direction, or a directional light that acts as
  the sun. Each has its own colour, brightness, reach and falloff, and you place and aim it with
  the usual gizmo. Spot and directional lights can cast shadows, with a choice of hard or soft
  edges, and a spot can project an image through its cone so it throws a pattern rather than a
  plain circle. Soft edges, projected images and the shadow-detail setting need iOS 27, iPadOS 27,
  macOS 27 or visionOS 27; below that the light still works and simply casts a hard-edged shadow.

* **Built-in Dynamic Light.** Every scene has always had a light of its own, and it now has a
  switch, in Scene Settings under Lighting & Rendering. In AR it only casts the shadows objects
  drop; with the camera off it also brightens them, on top of the scene's environment lighting.
  Turn it off when you want only the lights you placed.

* **Lights from a script.** `createSpotLight`, `createPointLight` and `createDirectionalLight`
  build lights at runtime, and `entity.representation.light` changes one while the scene is
  running, so a lamp can pulse or a projected pattern can turn. `scene.setBloom` and
  `scene.setToneMapping` set the scene's look from a script too. Scripting runtime 0.3.0; see the
  [scripting changelog](https://scenery.app/docs/scripting/guide/changelog).

* **Bloom.** Bright things now bleed light into what's around them – a soft halo on emissive
  materials, screens and light sources. Find it in Scene Settings under Post-processing. By default
  only objects you mark bloom, which you do with the new Bloom switch in an object's Lighting &
  Shadows section; switch it to Whole Scene if bright areas can appear anywhere, bearing in mind it
  costs more. Strength, threshold and blur radius are yours to tune. Bloom needs iOS 27, iPadOS 27,
  macOS 27 or visionOS 27, which are still in beta – until those ship publicly you'll only see it on
  a device running the beta, and it also needs an iPhone 12, an A14 or M-series iPad, an Apple
  silicon Mac, or Apple Vision Pro. Everywhere else the scene renders normally, so an experience
  using bloom still opens and plays for everyone. On Apple Vision Pro it appears in an immersive
  space only.

* **Say which OS version an experience needs.** A new **Minimum OS Version** setting sits under
  Platforms in Experience Settings. Leave it unrestricted, or require version 26 or newer, and
  viewers on anything older are told the experience is unavailable rather than opening it and
  finding parts of it missing. One setting covers iOS, macOS and visionOS. Gaussian splats need
  version 27, so a scene containing one now says so beside the setting, explains that on older
  systems the splat will not appear, and offers to set the requirement in one tap.

### Fixed

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Hiding the content inside an object works.** The eye button on an object's own row hid it, but
  the same button on the model, media or interface row nested inside it did nothing. Both rows now
  behave the same way, as they already did for content inside a container or a portal.
* **Typing a large number into a field no longer changes it.** In a locale that separates thousands
  with a period, 1000 was shown as "1.000" and then read back as 1 when committed, so a light set to
  a plausible intensity ended up at almost nothing. Numbers are no longer grouped while being
  edited, so what a field shows is what it reads back.
* **A scene that needs a particular surface can no longer wait forever for it.** Once the kind of
  surface an experience asked for had been seen even briefly, it was insisted on for the rest of
  the run, so if the device stopped recognizing that surface the experience never started. It now
  gives the surface a few seconds to come back and otherwise places the scene anyway.
* **The floor is found before the scene is placed, not after.** A scene set to appear on a table or
  a seat had its floor located afterwards, so the viewer was sent looking for a second surface once
  the scene had already appeared, which read as the placement going wrong. The floor step also
  declines to settle on a table or a chair now, rather than accepting whichever surface happened to
  be in view.
* **The placement indicator no longer hangs around during the experience.** A scene placed on a
  table leaves the floor still to be found, and the floor search asks for an indicator of its own.
  The one used for placement was left in the scene at that point rather than taken down, so it sat
  in mid-air for the rest of the session.
* **An object's Minimum Dimensions works on walls again.** A plane anchor with a required size
  stopped honouring it on vertical surfaces, and on floors, in an earlier 1.1.21 build: the element
  search had been pointed at the equivalent check scene placement uses, which deliberately only
  applies to tables. Content anchored to a wall now waits for a wall big enough, as it did before
  and as the documentation describes.
* **A scene set to Window or Door can be placed again.** Whether a device recognizes a door as a
  door turns out to depend on the door: a plain flush one in a plain wall is reported as part of
  that wall, and iPhone and iPad have no separate door classification at all. So a scene asking for
  one waited for a surface that never arrived and the placement indicator never settled. Both
  choices now accept the wall behind them, with a real door still preferred on Apple Vision Pro
  where the room reports one.
* **"Place Manually" starts from the floor.** Stepping out of a marker hunt used to hand the viewer
  whichever surface the author last had selected in a different placement method, so they could be
  asked to aim at a wall for a scene that had nothing to do with one.
* **Scripted value animations are smooth again.** They were driven by a clock separate from the one
  the scene renders on, which on Mac ran at a third of the frame rate and made anything animated
  from a script visibly coarse. They now advance once per rendered frame, start from their first
  value rather than a frame or two along, and pause with the experience instead of jumping ahead
  when it resumes.
* **Automatic placement no longer settles for the wrong spot.** It waits for the kind of surface
  the experience asked for as long as one is in the room, rather than giving up after a few seconds
  and using whatever the viewer happened to be looking at. It also waits for the viewer to settle
  before committing, so glancing past the edge of a table no longer places the scene there.
* **A scene on a wall is no longer placed at the viewer's feet.** Looking at the bottom of a wall
  used to put content half into the floor; wall placements now sit at the viewer's own height.
* **Turning off auto-start didn't survive saving.** The setting was written correctly but read back
  from the wrong place, so it reverted every time the experience was reopened.
* **Interface panels on Apple Vision Pro would not respond to input.** A panel whose object had a
  tap event or a gesture highlighted as a whole when you looked at it, and its buttons received no
  taps at all – the controls were effectively dead. Looking at a control now highlights that
  control, and taps reach it.
* **A panel's corner radius was ignored on Apple Vision Pro.** Whatever radius you set, every panel
  rendered with the same rounding. Panels now take the radius you give them.
* **Text no longer truncates when a panel sizes itself to its content.** A label filled in later –
  from a variable, a script or fetched data – was cut off with an ellipsis because the panel had
  already measured itself around the placeholder. Automatically sized panels now grow to fit. The
  previous advice to give such panels a fixed size is no longer necessary.
* **Sound kept playing after you left an experience.** Leaving while a sound was still playing did
  not stop it – it carried on to the end of the clip. Opening several experiences in one session
  could then slow the app down or leave it on a frozen frame. Leaving an experience now stops it
  straight away.
* **An experience made from a template keeps its scripts.** Starting from a template whose original
  used scripting produced an experience where every Run Script action pointed at a script that was
  not there, so nothing ran. Scripts are stored alongside an experience rather than inside it, and
  only the document was being copied.
* **The keyboard works in the Create Experience screens on Mac.** Return did nothing and the Mac
  played its error sound, the arrow keys did not move the selection, and Escape did not cancel. All
  three now behave, and the category list keeps its own arrow key navigation.
* **A save that was replaced by a newer one no longer reports itself as a failure.** Editing quickly
  could raise a red "Experience saving error" over the editor even though nothing had gone wrong and
  the work was saved a moment later.

## 1.1.20 – July 2026

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

Spatial user interfaces, Apple Immersive Video on Apple Vision Pro, direct screen gestures,
and a much larger scripting runtime.

### Added

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Spatial user interfaces** – build interface panels and place them in a scene or fix them to
  the screen. Labels, buttons, toggles, sliders, text fields, images, shapes, stacks and web
  views, with a style system covering fonts, colours, borders, shadows, corner radii and frosted
  glass panel materials. Styles can differ per state, so a button can look different while
  pressed or disabled. Labels interpolate scene variables live – write `${score}` and it updates
  itself – with formatting filters for percentages, times and signed numbers. Panels are built in
  a dedicated editor with its own inspector, undo and preview.
* **Apple Immersive Video** – play Apple Immersive Video and spatial media on Apple Vision Pro.
  Objects and interface panels stay visible over a fully immersive video, and the new
  **Set Immersion Mode** action moves an experience between mixed and full immersion while it
  runs. On iPhone and iPad the camera stays visible while placing a virtual-immersion experience.
* **Screen gestures** – pan, pinch and rotate anywhere on screen, plus double tap and long press
  on an object, on iPhone, iPad and Mac. A new **On Gesture** trigger fires through the drag with
  its phase and movement, so an object can react while it is being moved rather than only at the
  end.
* **Throw and momentum** – objects with a drag gesture can now keep the motion they were released
  with. Choose whether an object stays where it was dropped, springs back, or carries its momentum
  so a flick throws it.
* **Per-device anchoring** – give an object a different anchor per device category, so one
  experience can anchor to a plane on iPhone, to the screen on Mac and to a hand on Apple Vision
  Pro. Includes a screen-space anchor, an option to hide an object entirely on a given device, and
  a fallback transform with its own gizmo for devices without tracking.
* **Copy and paste in the editor** – copy objects and their visual content and paste them
  elsewhere in the same experience, including pasting as a sibling or wrapping into a container.
  Container rows gained an **Insert** submenu, and dragging across the hierarchy keeps the
  selection.
* **Cycle action** – one trigger steps through any number of states, animations or behaviours, so a
  single tap can advance a sequence rather than always doing the same thing.
* **Platform condition** – Conditional Logic can branch on the device an experience is running on,
  so one experience can behave differently on Apple Vision Pro than on a phone.
* **Scripting 0.2.0**  – a large, mostly additive runtime release: paths and splines, mesh
  instancing, GPU compute kernels, runtime meshes, device location, screen gestures, physics
  primitives, object cloning, hand and face tracking, inline materials, and script-built interface
  panels. See the [scripting changelog](https://scenery.app/docs/scripting/guide/changelog) for the
  full list.
* **Ask what the device can do, not just what it is.** The Conditional Logic action gained two
  questions beside Platform Is. **Device Is** asks whether this is a handheld, a headset or a
  desktop, the same vocabulary the anchor Device Configuration picker uses, so it keeps working as
  new devices arrive. **Feature Is Supported** asks whether a capability is actually available
  here, which nothing else could answer: bloom needs a recent OS, capable hardware, and on Apple
  Vision Pro an immersive space. Put the fallback in the else branch.
* **Documentation** – <https://scenery.app/docs/> is new: a written guide to the editor, anchors,
  triggers, actions, materials, post-processing and the scripting API.

### Changed

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* The **Add** submenu on containers is now called **Insert**, which better describes what it does.
* Drag, Rotate and Resize no longer show a "Vision Pro only" badge. They have always worked on
  every platform – the input adapts to the device – and the badge was simply wrong.

### Fixed

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **macOS 27 compatibility** – the app would not launch at all on macOS 27, and the editor sidebars
  would not scroll. Both are fixed.
* Discover no longer shows "An error occurred" and an empty feed when a single experience cannot be
  read. One unreadable experience is now skipped instead of emptying the whole list.
* An experience created with a newer version of Scenery no longer disappears from your library. It
  stays in place and explains that the app needs updating to open it – nothing was ever lost, but it
  looked exactly as if it had been.
* Rotation no longer flips onto a different axis after using the rotate gizmo.
* Moving several selected objects at once now moves them together, in the direction you dragged.
* The add-object menu is no longer empty on Macs running macOS 15 and earlier.
* Replacing an asset keeps it in its folder, and the asset library search field survives switching
  tabs.
* Duplicating an experience now gives you your own copy rather than one still tied to the original.
* The first tap on an object is no longer occasionally swallowed.
* Preview sessions no longer leak, and placing an object in a non-tracked scene no longer crashes.

## 1.1.19 – April 2026

Documentation source: [Changelog](https://scenery.app/docs/guide/changelog.md).

* **Folders** – organise assets and experiences into folders, and drag items to file them.
* **SharePlay** – view experiences together over FaceTime, with interactions and events kept in
  sync.
* **Volume mode** – launch experiences in a volume on Apple Vision Pro so they sit alongside other
  apps and windows.

Changes before 1.1.19 are not covered by this changelog.

---

Source page: FAQ

Source URL: https://scenery.app/docs/guide/faq.md

# FAQ

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

Common questions about building and sharing with Scenery. For anything not covered here, reach us at <hello@scavengar.world> or on [Discord](https://discord.com/invite/KJCK4d8F9y).

## Which devices and platforms are supported?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

You **build** on **Mac and iPad** (the editor is made for larger screens), and experiences **play** on **iPhone and iPad** (iOS 18+), **Apple Vision Pro**, and in the **browser** via WebXR. See [Compatibility](https://scenery.app/docs/guide/compatibility) for the full per-feature, per-device breakdown.

## Do viewers need to install an app?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

No. On paid plans, an experience is shared as an **App Clip** – it opens instantly from a **QR code, NFC tag, or link**, with no app download. See [Publishing & Sharing](https://scenery.app/docs/guide/publishing).

## Does Scenery work on the web or Android?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

Yes – through the **WebXR Viewer** (beta): full immersive AR on **Android Chrome**, and an interactive 3D preview on **desktop**. iOS keeps using App Clips for the best native experience. See [Scenery on the Web (WebXR)](https://scenery.app/docs/webxr/).

## What 3D and media formats can I use?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

* **3D models** – USDZ (Apple's AR-ready format: model, materials, and animations in one file).
* **Video** – MP4 / MOV, including transparent and spatial video.
* **Images** – PNG / JPEG, plus HDR / EXR for environments.
* **Audio** – MP3 / WAV / M4A, spatial or ambient.

Large media can be streamed (HLS) or pointed at your own URL instead of uploaded. See [Adding Content](https://scenery.app/docs/editor/adding-content).

## Why is my transparent video not transparent?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

Transparency survives in only one video format: HEVC with an alpha channel, in a `.mov`. H.264 cannot store it, and most tools need a two-step export to produce it. [Transparent Video](https://scenery.app/docs/guide/transparent-video) walks through the export and the usual causes of a solid background.

## How do I share an experience?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

Turn on sharing in [Experience settings](https://scenery.app/docs/editor/experience-settings) to generate a link. On Apple devices that's an **App Clip** (QR, NFC, or link); on the web it's a **WebXR** link. Full details in [Publishing & Sharing](https://scenery.app/docs/guide/publishing).

## Can I add custom logic or code?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

Most interactivity is **no-code** – a visual [events and actions](https://scenery.app/docs/editor/triggers) system. When you need more, there's a **JavaScript [Scripting API](https://scenery.app/docs/scripting/)** (beta) with access to the scene, entities, materials, audio, networking, and more.

## Can I use my own branding?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

Yes – branding options (logos, colors, custom App Clip displays) are part of the **Agency** plan. Reach out at <hello@scavengar.world> to discuss what you need.

## I'm coming from Adobe Aero – can I migrate?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

In most cases, yes – Scenery covers the bulk of what Aero did. Convert your 3D assets to **USDZ** (e.g. with Apple's Reality Converter) and your videos to **MP4**, then rebuild the experience in the editor. If you get stuck, email <hello@scavengar.world>.

## What plans are there?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

Scenery has **Free**, **Pro**, and **Agency** tiers that progressively unlock more – Pro adds things like App Clip sharing, custom materials, portals, post-processing, and unlimited experiences; Agency adds commercial use and full branding. The current plans and exactly what each includes live in the app.

## How do I get help?

Documentation source: [FAQ](https://scenery.app/docs/guide/faq.md).

Email <hello@scavengar.world>, or join the community on **[Discord](https://discord.com/invite/KJCK4d8F9y)** – the fastest way to get answers and share what you're building.

---

Source page: Changelog

Source URL: https://scenery.app/docs/scripting/guide/changelog.md

# Changelog

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

What changed between runtime versions. Scripts pin to the version they were written against,
so older experiences keep running unchanged. See the [Migration Guide](https://scenery.app/docs/scripting/guide/migration) when
you move an experience forward.

## 0.4.0&#x20;

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

Calling an API that needs a key, without the key being in the experience.

### New APIs

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

* **`secret`** – an option on [`http.request`](https://scenery.app/docs/scripting/api/httpclient). Name a credential the
  experience binds and Scenery makes the request itself, adding the key on the way out, so it
  never reaches a viewer's device. The key is stored on your account and tied to the API's
  address, so it is only ever sent there and you can replace it without touching a script. Works
  with any API that takes its key in a header. Add one in the editor under Secrets. Cannot be
  combined with `token` or `username`.
* **`coordinateSystem`** – an option on [`createSplat`](https://scenery.app/docs/scripting/api/functions): the axes the file stores its splats in. Pass `'rdf'` for an export from SuperSplat, Niantic's ply\_to\_spz or another PLY-based tool that appears upside down. Defaults to `'rub'`, the axes the SPZ format specifies.

### Errors worth branching on

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

A rejected call carries `code` and `reason`. Two share the code `resource-exhausted` and want
opposite handling: `owner_busy` is transient and worth retrying shortly, while `ceiling_reached`
means the secret has spent its daily limit and carries `details.limit` and `details.resetAt`.

The vendor's own refusal is not an error. An API returning 429 or 400 arrives as an ordinary
response with that `status`, so a script that only wraps the call in `try` will miss it. See
[handling a failed call](https://scenery.app/docs/scripting/guide/examples#when-an-api-call-fails).

## 0.3.0&#x20;

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

Lights, the two scene-wide looks that go with them, and GPU access to splat captures and mesh
instances. Additive: nothing in 0.2.0 changed.

### New APIs

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

* **[Splat](https://scenery.app/docs/scripting/api/splat)** – `entity.representation.splat` reaches a
  [Gaussian splat](https://scenery.app/docs/scripting/guide/splats) capture's per-splat data: `count`, `boundingBox`,
  `sphericalHarmonicDegree`, and the five attributes. Each attribute vends `.read` and `.write`
  tokens for a compute kernel, so reveals, dissolves and interactive effects run on the GPU
  rather than being rebuilt in JavaScript. `null` on any other representation and wherever
  captures are unavailable.
* **[InstanceData](https://scenery.app/docs/scripting/api/instancedata)** – `entity.instances` and `rep.instances` hand
  the [mesh instancing](https://scenery.app/docs/scripting/guide/instancing) transform buffer to a kernel, so thousands
  of copies can move per frame without rebuilding the transform list.
* **[EngineBufferBinding](https://scenery.app/docs/scripting/api/enginebufferbinding)** – the token type both of those
  return, alongside the existing [TextureBinding](https://scenery.app/docs/scripting/api/texturebinding).
* **Lights** – `createSpotLight(...)`, `createPointLight(...)` and `createDirectionalLight(...)`
  build light objects the same way `createBox` builds a shape, so they take `name`, `anchor`
  and `transform` like anything else. Colour, intensity, cone angles, attenuation, shadows and
  a projected texture are set at creation. `projectedTexture` takes an asset id, a URL, or a
  handle from [Texture](https://scenery.app/docs/scripting/api/texture), so a spot can project a video, the camera feed
  or a compute kernel's output as easily as a stored image.
* **[Light](https://scenery.app/docs/scripting/api/light)** – the live handle, `entity.representation.light`. Reading and
  writing `intensity`, `color`, `innerAngle`, `outerAngle`, `attenuationRadius`,
  `falloffExponent`, `projectedTextureOffset`, `projectedTextureScale` and
  `projectedTextureRotation` takes effect on the next frame, which makes a pulsing lamp or a
  drifting pattern one `animateValue` away. Writes are runtime state and do not change the saved
  experience.
* **`scene.setBloom(...)`** – make bright pixels glow, scoped to the whole scene or to objects
  that opt in. `null` switches it off.
* **`scene.setToneMapping(...)`** – set the scene's tone curve (exposure, toe, shoulder).
  `null` returns to the platform default.
* **`.revealAnimation(...)` / `.removalAnimation(...)`** – choose how a created object animates in and out, using
  the same four styles as the editor's Reveal and Removal Animation pickers: `'default'`,
  `'disabled'`, `'fade'`, `'fadeAndScale'`. `.revealAnimation(false)` is shorthand for no animation, which
  is what a script that runs its own reveal wants. Previously reachable only through the untyped
  `t.set('modelAdjustments.revealAnimation', …)`.
* **`instances.meshToLocal` / `instances.localToMesh`** – the conversion between the instance
  buffer's units and metres, as 16 numbers in column-major order for a kernel's uniforms. The
  buffer holds the instanced mesh's own units, which are rarely metres: a model scaled to a
  fitting box measured 407 buffer units to the metre, so a copy placed at 0.82 m sits in the
  buffer at 335. A kernel that adds a fixed offset has to convert, or it moves things by the
  wrong amount and usually looks frozen. Identity for a primitive.
* **`.hideByDefault(...)`** – create an object hidden, so a script can prepare it before anyone
  sees it, then bring it up with `scene.toggle([entity], true)`. Mirrors the editor's Hide By
  Default toggle. It still loads: the representation is built and the physics body precomputed,
  the object is simply not shown and its physics stays paused.

### Feature flags

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

Seven additions to `environment.features`, each with a support condition a script can actually
hit: `softShadows`, `shadowCascades`, `projectedLightTexture`, `surroundingsLight`, `bloom`,
`toneMapping`, `splats`. Bloom wants a capable GPU as well as a recent OS, the surroundings light
exists on Apple Vision Pro alone, and splats render on devices only, never in a simulator. Gate on them and a portable script degrades instead of
looking broken.

### Changed

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

* **Value animations run in step with rendering.** `animateValue` used to be driven by its own
  display refresh clock, separate from the one the scene renders on. That clock could be served
  at a fraction of the frame rate, giving a visibly coarse animation, or at twice it, computing
  values no frame ever painted. It now ticks once per rendered frame, so `onUpdate` and
  `scene.on('render')` see the same frames. An animation also starts at its `from` value rather
  than a frame or two along.

  Two consequences worth knowing. A value animation now **pauses with the experience** and
  resumes where it froze, instead of running on through a pause and jumping. And on Apple Vision
  Pro it pauses while the headset has no position, such as while an immersive space is opening
  or tracking is interrupted.

  `wait()` is unchanged and still runs on a timer, so it keeps counting through a pause. A
  `wait` and an animation completion started together can therefore finish in the other order if
  the experience is paused in between.

* **`traits.pivot` takes all six faces.** Alongside `"top"`, `"center"` and `"bottom"` it now
  accepts `"left"`, `"right"`, `"front"` and `"back"`. `"back"` seats a model flat against an
  upright surface the way `"bottom"` stands one on a floor, which is what content placed on a wall
  needs: left on its own origin it straddles the surface, so half of anything solid ends up inside
  the wall. Existing values are unchanged.

* **`rep.setInstances` needs a single mesh.** A primitive always is one; a model is once its
  **Flatten** adjustment is on, which loads it collapsed the way every other engine expects for
  instancing. An unflattened model with several meshes is now refused, with the console naming
  them, instead of quietly writing a separate buffer per mesh that no kernel could read back as
  one. Flattened models also place their copies correctly now: the transform the mesh file used
  to position its geometry was being discarded, which drew every copy at the raw size.

* **Kernel bindings keep the order you wrote them.** Entries in `inputBuffers`, `outputBuffers`,
  `inputTextures` and `outputTextures` take kernel slots in the order they appear in the object.
  They previously came out in an unspecified order, which only ever looked right because no
  example bound more than one entry per map. One caveat is JavaScript's, not ours: keys that look
  like integers (`{ 2: …, 0: … }`) sort numerically ahead of everything else, so name your slots.

* **A binding that cannot be honoured now cancels the dispatch** instead of skipping the entry.
  Skipping left its slot unclaimed, which slid every later buffer into the wrong one, so a single
  destroyed handle silently corrupted the whole pass. Binding past the GPU's 31-slot limit now
  says so as well.

### Fixed

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

* **`buffer.readSync()` waits for the GPU.** It read shared memory without waiting for the
  dispatch that was writing it, so the marching-cubes pattern of dispatching and then reading the
  triangle counter got the previous frame's value. `buffer.writeSync(...)` waits too, so
  reseeding a counter between passes cannot land under a running kernel.
* A partial transform in a declarative options object (`transform: { rotation: … }`) no longer
  throws on the fields it omits.
* **`environment.location.watch`'s `onError` fires.** It never did, so a withdrawn permission or a Core Location failure went unnoticed. It now receives `"denied"` or `"unavailable"` (Scenery 1.2.2).

## 0.2.0&#x20;

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

A large, mostly additive release. Highlights:

### New APIs

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

* **Location** – read the device location from a script via `environment.location`
  (`requestAccess`, `current`, `watch`, precise-accuracy opt-in) with a `GeoCoordinate` type
  carrying `distanceTo` / `bearingTo` helpers.
* **Paths / splines** – `scene.createPath({ points })` builds a runtime spline; drive an object
  along it with `entity.followPath(path, { duration, constantSpeed, alignsToTangent })`.
* **Mesh instancing** – render thousands of copies of one object with
  `rep.setInstances(Instances.transforms([...]))` (rendering-only; far cheaper than cloning).
* **Compute kernels** – run GPU compute from a script: `Kernel.fromSource` / `Kernel.fromAsset`,
  `Buffer` handles, `Texture.compute`, and `mesh.runCompute(...)`.
* **Dynamic meshes** – build and update geometry at runtime with `createMesh(...)`,
  `writeVertices` / `writeIndices`, and per-frame draw-range updates.
* **User interface** – author panels from a script with `createPanel(...)` and the `UI.*`
  builders (label, slider, stacks, …), live `${var}` label interpolation, `findView`, and
  property binding. (Beta.)
* **Materials** – inline material factories: `Material.pbr(...)`, `Material.unlit(...)`,
  `Material.occlusion(...)`, `Material.customShader(...)`, `Material.materialX(...)`,
  `Material.video(...)`, with web-standard property names and texture maps.
* **Screen gestures** – `scene.on('pan' | 'pinch' | 'rotate')` with `velocity` (the raw input
  for mechanics like flick-to-launch), `entity.on('doubleTap' | 'longPress')`, per-object
  camera-claim arbitration, and `environment.deviceCategory`. iPhone / iPad / Mac only – gate
  with `environment.features.has('screenGestures')`.
* **Physics primitives** – `entity.applyImpulse`, `applyAngularImpulse`, `setVelocity` /
  `setAngularVelocity`, and the `.physics({...})` trait for giving an object a body.
* **Gestures trait** – the typed `.gestures({...})` API, including `releaseBehavior`
  (`stay` / `reset` / `momentum`) for drag-and-release mechanics.
* **Live value views** – write through vector components directly, e.g. `entity.position.x = 2`.
* **Tracking providers** – opt into hand tracking and read articulated joint transforms without
  planting a hand-anchored element: `scene.tracking.hands` (`enable`, `left` / `right`,
  `anchors`), plus `scene.tracking.face` for blendshapes / eye transforms. Gate with
  `environment.features.has('handTracking')`. (Apple Vision Pro.)
* **Cross-platform surface input** – `scene.createSurfaceInput({ target })` yields interaction
  points on a surface in its own local frame, using fingertips on Apple Vision Pro and screen
  taps / drags elsewhere – the same points either way, so your logic never branches on platform.
* **Authored object descriptors** – read and adjust an object you built in the editor *before*
  it's shown: `scene.getObjectDescriptor(nameOrId)` → edit with the trait methods / `.asset(...)`
  (swap a model or video source) / `.representation(...)` (swap the whole visual) →
  `scene.setObjectDescriptor(...)`. Plus `descriptor.clone()` (fresh-id copy for spawning
  variants) and read-only `descriptor.id` / `descriptor.kind`.

### Changed

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

* **Traits flattened onto the descriptor.** The trait configurators are now direct chainable
  methods – `createSphere(0.05).physics({...}).material(...).shadow({...})` – instead of the
  `.traits(t => …)` callback. `.traits(fn)` still works but is **deprecated**; see the
  [Migration Guide](https://scenery.app/docs/scripting/guide/migration).
* **Options-object substrate** for primitive factories, e.g.
  `createBox(w, h, d, r, { physics, material, … })`.

## 0.1.0

Documentation source: [Changelog](https://scenery.app/docs/scripting/guide/changelog.md).

Initial scripting runtime.

