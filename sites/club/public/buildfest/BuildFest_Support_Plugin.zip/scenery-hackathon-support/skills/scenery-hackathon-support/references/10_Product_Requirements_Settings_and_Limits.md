# Product Requirements Settings and Limits

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: plan; Pro; beta; locked; settings; secrets; API key; performance; capability; missing feature.

## Contents

- Best Practices
- Scene Settings
- Experience Settings
- Secrets

---

Source page: Best Practices

Source URL: https://scenery.app/docs/guide/best-practices.md

# Best Practices

Documentation source: [Best Practices](https://scenery.app/docs/guide/best-practices.md).

A short set of habits that make experiences track reliably, run smoothly, and travel well
across devices. Each points to the page with the full detail.

## Organize your experience

Documentation source: [Best Practices](https://scenery.app/docs/guide/best-practices.md).

* **Name your Objects and Anchors.** Clear names keep a busy hierarchy legible, and they let
  scripts find things by name. Double-click an item to rename it. A few habits help:
  * Prefer descriptive names (`Ball`, `InfoPanel`) over the defaults (`Object 1`).
  * **Be consistent.** Pick one style – e.g. `camelCase` (`infoPanel`), `PascalCase`
    (`InfoPanel`), or `kebab-case` (`info-panel`) – and use it throughout, so names stay
    predictable in the hierarchy and in scripts (where matching is case-sensitive). Giving
    related items a shared prefix (`ui-title`, `ui-slider`; `audio-intro`) also keeps a long
    list scannable.
  * Keep names **unique** for anything a script references. `scene.findEntity({ name })` matches
    the name **exactly** – capitalisation included – and returns one match, so duplicates are
    ambiguous.
  * Settle on a name before you script against it: renaming an Object later breaks any script
    that looks it up by the old name.
* **Use Scenes to chapter your experience.** A Scene is a self-contained stage; larger
  experiences use several and move between them at runtime. See
  [Experiences, Scenes & Objects](https://scenery.app/docs/editor/concepts) and the
  [Transition to Scene](https://scenery.app/docs/editor/actions/experience) action.

## Anchor for tracking, nudge with Transform

Documentation source: [Best Practices](https://scenery.app/docs/guide/best-practices.md).

Place content with an **Anchor** by default – the anchor is what the device tracks, so it gives
the most stable placement. To fine-tune from there, don't move the anchor; nudge the Object's
**Transform** (position, rotation, scale) on top of it. The full pattern, and every anchor type,
is in [Anchors](https://scenery.app/docs/editor/anchors).

For **image markers**, the printed size and the image itself matter as much as the software –
see the guidance in [Anchors → Image](https://scenery.app/docs/editor/anchors#image) (measure the physical width
accurately, print with high contrast on a matte flat surface, size the marker for the distance
you want to detect from).

## Keep it light

Documentation source: [Best Practices](https://scenery.app/docs/guide/best-practices.md).

Everything in an experience downloads the first time it's opened, then caches – so total size
is what the first-load experience feels like.

* **Aim for a small total.** Roughly **30–50 MB** works well for App Clip-delivered mobile
  experiences. See [Adding Content](https://scenery.app/docs/editor/adding-content).
* **Lean by default, but you have room.** Favor the lightest asset that still looks good – it
  loads faster, runs cooler, and ports to the web. Modern devices have real headroom, so
  right-size rather than starve; there's no single number, since a hero centrepiece, a simple
  prop, and a scan each warrant very different budgets.
* **Textures:** 2K (2048 px) is a comfortable default on current devices; drop to 1024 for the
  web or when you have many objects. Bake fine detail into normal maps instead of geometry.
* **Big or high-resolution video:** stream it rather than embedding it – point at an **HLS**
  stream or a manual asset URL. Keeps the whole experience light. See
  [Adding Content](https://scenery.app/docs/editor/adding-content).
* **Transparent video:** export as **HEVC with an alpha channel**. A tool like **Apple
  Compressor** compresses transparent HEVC well (and spatial / stereo video too), keeping the
  file small. See [Materials](https://scenery.app/docs/editor/materials).

## Adapt to the device

Documentation source: [Best Practices](https://scenery.app/docs/guide/best-practices.md).

The same experience can run on a phone, a headset, the desktop, and the web – design for the
differences.

* **Branch per device with Conditional Logic.** The **Platform Is** condition runs different
  actions depending on the device – show different content, or route to a different Scene, on a
  headset versus a phone versus the web. See [Actions](https://scenery.app/docs/editor/actions).
* **In scripts,** read `environment.deviceCategory` to do the same in code (see the scripting
  [Feature Detection](https://scenery.app/docs/scripting/guide/feature-detection) guide).
* **Design the lightest target first.** Web budgets are tighter than native, so an asset that's
  fine on a phone can be too heavy in the browser – size down and compress for web delivery.

## Reuse state with the Cycle action

Documentation source: [Best Practices](https://scenery.app/docs/guide/best-practices.md).

To swap between a few states – change which Object is shown, toggle a look or a button's
appearance – reach for the **Cycle** action. It steps through a set of action sets on each
trigger (Loop, Ping Pong, or One Shot), so you don't need a variable and branching per state.
See [Actions](https://scenery.app/docs/editor/actions).

## Design for comfort and safety

Documentation source: [Best Practices](https://scenery.app/docs/guide/best-practices.md).

Match session length to the device. Handheld AR is tiring to hold up, so keep those interactions
brief or let users set the phone down for stationary viewing. Headset experiences are hands-free
and comfortable, so they can run much longer. Either way, design for the physical space and guide
the user into position.

For **location-based experiences**, keep the covered area bounded. A route spanning kilometres
means near-continuous walking and tracking – which drains battery, heats the device, and taxes
tracking and processing – and it raises real safety concerns when people watch a screen while
moving. Favour shorter, contained routes over sprawling ones.

When an area is genuinely large, split it into **several smaller experiences – one per
location** – instead of one sprawling experience. Then give each its own **entry point** so
people start fresh at each spot rather than staying in AR the whole way:

* A **QR code or NFC tag at the location** is the smoothest entry – scanning it opens that
  location's experience directly. See [Publishing & Sharing](https://scenery.app/docs/guide/publishing).
* An interactive **map or website** that links to each experience lets people choose where to go
  from an overview, out of AR.

If you do want to move straight from one experience into the next without leaving AR, the
[Open Link](https://scenery.app/docs/editor/actions/experience#open-link) action pointing at another experience's share
link opens it **in place** – the app confirms first, offering to restart the same experience or
replace the current one.

## Test on the real thing

Documentation source: [Best Practices](https://scenery.app/docs/guide/best-practices.md).

AR depends on the device and the space it runs in – tracking, lighting, scale, and how warm the
device gets all differ from the editor preview. Test on an actual device, and on-site for placed
or geo experiences, early and throughout – not just at the end. The editor makes this quick:

* **Preview in AR on the device you're editing on** – on an iPad you can jump straight into AR
  (or use the simulator on a Mac). Preview the whole experience or just a selected object to
  iterate on one element fast.
* **Send to Devices – the workflow to reach for.** Keep the experience open in the editor, then
  open the *same* experience on another Apple device signed in to the same Scenery account. It
  appears as a connected device, and from then on your edits stream to it **live** as you make
  them – no re-export, no re-opening. It works across Apple devices (iPhone, iPad, Vision Pro),
  but not the web (WebXR). It's especially valuable for headset work, where you otherwise can't
  edit and wear the device at the same time.

See [Editor Overview](https://scenery.app/docs/editor/overview) for both.

---

Source page: Scene Settings

Source URL: https://scenery.app/docs/editor/scene-settings.md

# Scene Settings

Documentation source: [Scene Settings](https://scenery.app/docs/editor/scene-settings.md).

Settings that apply to the whole scene. Open them with nothing selected (sections can be collapsed with their arrows to keep things tidy).

## General

Documentation source: [Scene Settings](https://scenery.app/docs/editor/scene-settings.md).

* **Name** – a clear scene name; the foundation of a manageable, larger experience.
* **Tracking coaching overlay** – on by default; prompts the user to move their device so it can establish solid tracking.
* **Pause controls** – on by default; how viewers pause. The button in the top left corner during playback on iPhone, iPad and Mac, and a button on their hands on Apple Vision Pro. There, pinching and holding anywhere in their surroundings opens the pause menu whatever this is set to.
* **Capture button** – on by default; the camera button next to it, which lets viewers take a photo or record their session. Turn it off for scenes where capturing would confuse people about what the experience does.
* **Placement confirmation** – on by default; a brief message once the scene has its place in the world. Turn it off for a scene that should begin without any interruption.
* **SharePlay participation mode** – in a shared session, **Presenter only** (only the host interacts) or **All participants** (everyone can interact, simultaneously). Pick by whether the experience is about watching together or interacting together.

::: tip Leave a way out when you hide the pause controls
The pause menu is the only way to leave an experience, so a scene without pause controls needs another route in: any event can run the **Pause Experience** action to open the same menu, for example from a UI button you place yourself.
:::

![The General scene settings – tracking coaching overlay, pause and capture controls, and the SharePlay participation mode menu](https://scenery.app/docs/assets/general.C13xBpZe.jpg)
*The General scene settings.*

## Placement & localization

Documentation source: [Scene Settings](https://scenery.app/docs/editor/scene-settings.md).

How the scene finds its place in the real world – placed by the viewer, placed automatically,
anchored to a printed marker, or localized against a location – has its own page:
[Placement & Localization](https://scenery.app/docs/editor/placement). Markers live there too, under the method that uses
them.

## Meshing & occlusion

Documentation source: [Scene Settings](https://scenery.app/docs/editor/scene-settings.md).

* **Floor mesh** – on by default; gives physics a floor to rest on (without it, physics objects fall through). A scene placed on a wall locates the floor before placement starts, so turning this off removes a step for the viewer when the scene doesn't need one – see [Placement & Localization](https://scenery.app/docs/editor/placement#surface).
* **World mesh** – off by default (performance); builds a mesh of the real environment so content can collide with or be occluded by it.
* **Scene mesh lighting** – let the mesh be lit by objects in the scene.
* **Object occlusion** – real objects hide virtual ones behind them (**LiDAR devices only**). Big realism win – a virtual dog correctly hidden behind a real desk.
* **People occlusion** – real people/pets correctly pass in front of virtual content (recommend **with depth**; iPhone XS and later). Crucial realism for photos and videos taken inside the experience.

![Meshing options – floor mesh and world meshing toggles](https://scenery.app/docs/assets/meshing-occlusion.BMdfy5Lp.jpg)
*The Meshing Options.*

## Physics

Documentation source: [Scene Settings](https://scenery.app/docs/editor/scene-settings.md).

* **Scene mesh collisions** – enable so physics objects can interact with the real environment.
* **Gravity** – default −9.81 (Earth); change it to simulate the moon, space, etc.

See [Physics actions](https://scenery.app/docs/editor/actions/physics) for using physics.

![Scene physics options – scene mesh collisions and the gravity value](https://scenery.app/docs/assets/physics-gravity.DeD0s0U7.jpg)
*The scene Physics Options.*

## Post-processing

Documentation source: [Scene Settings](https://scenery.app/docs/editor/scene-settings.md).

* **Surroundings effect** – dim/tint the real surroundings (none, semi-dark, dark, custom dim, custom tint). **Apple Vision Pro only.**
* **Bloom** – a luminous halo around bright objects. See below.
* **Custom effects** – apply [post-processing effects](https://scenery.app/docs/editor/post-fx) (filters/shaders) to the whole scene. iOS / macOS only.

### Bloom

Documentation source: [Scene Settings](https://scenery.app/docs/editor/scene-settings.md).

Bright things bleed light into what's around them. Bloom recreates that: anything brighter than the
**threshold** gets a soft halo. It reads best on emissive materials, screens, and light sources.

::: warning Platform support
Bloom requires **iOS 27, iPadOS 27, macOS 27 or visionOS 27**, on an iPhone 12, an iPad with an A14
or M-series chip, an Apple silicon Mac, or Apple Vision Pro. On earlier systems or devices the scene
renders normally, without bloom – an experience using it still opens and plays everywhere.

On Apple Vision Pro, bloom appears only in an **immersive space**; it has no effect in a window or
volume.

Not yet supported on the web.
:::

**Applies to** decides what can bloom, and it's the setting that matters for performance:

* **Selected objects** (default) – only objects you mark bloom. Turn on **Bloom** in an object's
  Lighting & Shadows section to mark it.
* **Whole scene** – anything bright enough blooms, wherever it is, including the environment behind
  your content. Costs noticeably more, because the renderer searches the entire screen every frame
  instead of just around the objects you marked. Use it when bright areas can appear anywhere, and
  prefer **Selected objects** whenever you know what should glow.

::: tip Nothing glowing?
In **Selected objects** mode nothing blooms until you mark something, so turning bloom on by itself
looks like it did nothing. Mark an object, and check it's actually bright enough to pass the
**threshold**.
:::

Then tune the look:

* **Strength** – how intense the halo is.
* **Threshold** – how bright something must be before it blooms. This isn't a 0–1 scale: 1 is about as
  bright as a fully lit white surface, and emissive materials go well beyond it, so raise it to keep the
  effect to the brightest highlights only. At 0, everything blooms however dim.
* **Blur radius** – how far the halo spreads, as a percentage of the screen height so it looks the same
  on every device. Larger values are softer and wider, and cost more to render.

Bloom is separate from the **custom effects** list, and from any bloom filter you may have added there.
Use one or the other, not both.

## Lighting & environment

Documentation source: [Scene Settings](https://scenery.app/docs/editor/scene-settings.md).

These pair with the viewport's [environment controls](https://scenery.app/docs/editor/environments-lighting):

* **Immersion mode** – **Mixed (AR)** (default), **Full VR** (replace the camera feed with a background), or **Progressive** (Vision Pro: the user dials the virtual environment in/out within a range you set).
* **Background** – a custom colour, HDRI, or preset, used by Full VR / Progressive.
* **Environment texturing** – on by default (real-world lighting on PBR materials); off to use a custom light map you control.
* **Adaptive resolution** – automatically scales the render resolution to the device: a smooth frame rate on older hardware, best quality on newer. When it's on, a **resolution multiplier** (10–100%, default 100%) lets you fine-tune that balance by hand – lower it to render at a lower internal resolution for more performance headroom, or keep it at 100% for maximum sharpness.

![Lighting and rendering settings – immersion mode, environment texturing, adaptive resolution and the resolution multiplier](https://scenery.app/docs/assets/lighting-environment.BT5wZJsC.jpg)
*Lighting & Rendering – immersion mode, environment texturing, and resolution.*

## Draw order groups

Documentation source: [Scene Settings](https://scenery.app/docs/editor/scene-settings.md).

Control the **order** in which objects render. Normally automatic, but stacked **transparent** elements (overlapping images/videos) can render with artifacts. Create a draw-order group, add the objects, and pick a **depth pass**:

* **Pre-pass** – computes depth before colour (better transparency).
* **Post-pass** – computes depth after colour (fewer artifacts in complex scenes).
* **None**.

Try different passes to see which resolves your scene's transparency best.

![A draw order group with its depth pass control](https://scenery.app/docs/assets/draw-order-groups.nfF0nsnh.jpg)
*A Draw Order Group and its Depth Pass.*

---

Source page: Experience Settings

Source URL: https://scenery.app/docs/editor/experience-settings.md

# Experience Settings

Documentation source: [Experience Settings](https://scenery.app/docs/editor/experience-settings.md).

Settings for the whole experience (not a single scene). Open them with the **Settings** button (top-right) when nothing is selected.

## Information & discovery

Documentation source: [Experience Settings](https://scenery.app/docs/editor/experience-settings.md).

* **Name** – shows wherever the experience is shared, inside Scenery and out. Make it enticing.
* **Description** – a concise hook (max 120 characters).
* **Tags** – up to 5; they appear on the preview and help discovery.
* **Category** – a primary and an optional secondary category.
* **Thumbnail** – upload an image, or use the **Snapshot** button to capture the scene (it uploads to the asset library and sets it as the thumbnail). The thumbnail + name + description are the first thing people see.

![The Information & Discovery settings – name, description, tags, categories, and the experience thumbnail](https://scenery.app/docs/assets/information-discovery.Dt89SJGq.jpg)
*The Information & Discovery settings.*

* **Availability**:
  * **Public** – anyone with the link can open it, and it may appear in the Creators tab. Only make public what's ready to share.
  * **Private** – only you can open it, even with the link. For confidential / in-progress work.
  * **Link** – anyone with the link can open it (and it can be featured), but it won't show on your public profile. Good for team / client review.

![The Availability menu – Public, Private, or Link](https://scenery.app/docs/assets/availability.bUeSoEAM.jpg)
*The Availability menu – Public, Private, or Link.*

## Sharing & delivery

Documentation source: [Experience Settings](https://scenery.app/docs/editor/experience-settings.md).

* **Generate link** – the gateway to your experience. On paid plans the link is an **App Clip** (instant access with no app install) – open it from a **QR code or NFC tag** for the smoothest entry (it skips the browser). Without a QR/NFC tag, a browser link shows an "open App Clip" prompt (Safari, non-private browsing only) – which is why a QR code is recommended. *(Free plan can't share App Clips; Agency/Enterprise can customize the App Clip card.)*
* **Allow featuring** – let other creators discover it in Scenery. Turn off for NDA work.
* **Enable SharePlay** – share the experience in a SharePlay session (best on Vision Pro; also iOS/iPadOS).
* **Scene transition loading indicator** – the spinner shown when moving between scenes; disable it for seamless, immersion-preserving transitions.
* **Update link metadata** – regenerates the shareable link and refreshes its preview card (the name, thumbnail, and description shown when the link is opened or shared). The button reads **Generate link** before a link exists, and **Update link metadata** afterwards – use it to refresh the preview after you change the experience's name, thumbnail, or description.

![Sharing and delivery – Generate link, Allow featuring, Enable SharePlay, the scene transition loading indicator, platforms, and the WebXR toggle](https://scenery.app/docs/assets/sharing-link.CxkpgxIt.jpg)
*Sharing & Delivery – Generate Link, featuring, SharePlay, platforms, and WebXR.*

## Platforms & WebXR

Documentation source: [Experience Settings](https://scenery.app/docs/editor/experience-settings.md).

* **Platforms** – all supported by default; restrict to selected platforms if needed.
* **Minimum OS version** – unrestricted by default. Requiring a version tells anyone on an older system that the experience is unavailable, rather than letting them open it and find parts of it missing. One setting covers iOS, macOS and visionOS, since Apple's version numbers are aligned. A platform you enable afterwards inherits the same requirement. Some features need a newer system than others: a scene using them says so beside this setting and offers to set the requirement for you.
* **WebXR support** (beta, opt-in) – also run the experience in a browser (Android and other devices) via the [WebXR viewer](https://scenery.app/docs/webxr/). A subset of features carries over (native-only features don't). It's available to every creator – just turn on the **WebXR support** toggle to opt in. (Still in beta, so expect rough edges.)

## Presentation mode

Documentation source: [Experience Settings](https://scenery.app/docs/editor/experience-settings.md).

* **Immersive** (default) – a fully immersive experience around the user.
* **Volume** (Apple Vision Pro) – a bounded volume that coexists with other windows/volumes (like a spatial widget). Options: allow resize, allow rotation, show base plate, adjust for viewport, **content scale factor** (shrink the whole scene into a diorama), and **content clipping margins** (let content spill a set distance beyond the volume before it's clipped – e.g. a waterfall falling just past the edge).

![Volume presentation mode – resize, rotation, base plate, adjust for viewport, content scale factor, and clipping margins](https://scenery.app/docs/assets/presentation-mode.Cr0SVzov.jpg)
*Volume presentation mode options.*

## Branding

Documentation source: [Experience Settings](https://scenery.app/docs/editor/experience-settings.md).

*(Agency / Enterprise only.)*

* **Intro text** (max 120 chars) – a short intro card shown when the experience opens.
* **Tint** – a custom colour applied to UI like buttons and the pause menu.
* **Header image** – shown on the intro screen above the intro text.
* **Logo** – watermarks the photos and videos users capture from within the experience (every experience ships with built-in photo/video capture + sharing, even in an App Clip), and appears on the pause screen.

![The Branding controls – tint colour, header image, and logo](https://scenery.app/docs/assets/branding.BQNZq8sg.jpg)
*The Branding controls.*

## Scripting

Documentation source: [Experience Settings](https://scenery.app/docs/editor/experience-settings.md).

* **Runtime version** – the [scripting](https://scenery.app/docs/scripting/) runtime the experience uses (currently one version).

---

Source page: Secrets

Source URL: https://scenery.app/docs/editor/secrets.md

# Secrets&#x20;

Documentation source: [Secrets](https://scenery.app/docs/editor/secrets.md).

A scene's scripts can call an API that needs a key – an AI model, a weather service, your own backend – without the key being part of the experience. You store the key once on your account, give it a name, and a script asks for it by name. Scenery makes the request from its own servers and adds the key on the way out.

That matters because a script is readable by anyone who can open the experience. A key written into a script is a key you have given away. A key stored as a secret never reaches a viewer's device at all.

::: warning You pay the API, not Scenery
The key is yours, so every charge the API makes lands on your account with that vendor. Scenery carries the request; it does not pay for it. Set a spend cap with the vendor as well as a daily limit here.
:::

## Where it lives

Documentation source: [Secrets](https://scenery.app/docs/editor/secrets.md).

**Library → Secrets**, in two tabs.

**My Secrets** is your account's keys, grouped by the service each one is for. These belong to you and follow you between experiences.

**In Use** is every name *this* experience's scripts call, and which key is behind each one. This is where a copied experience shows that it needs a key, and where a teammate's key shows up as theirs.

## Adding a key

Documentation source: [Secrets](https://scenery.app/docs/editor/secrets.md).

Under **My Secrets**, choose **Add Secret** and give it:

* **Name** – what a script will call it. Pick something a script can read, like `openai` or `weather`. Names are saved in lowercase, with dashes instead of spaces.
* **Value** – the key itself. It is stored encrypted and cannot be read back afterwards, so keep your own copy.
* **Daily limit** – how many calls a day this key may make. The default is 1000.

Once added, **Test** makes one real call so you can see the key works before you build around it. A custom secret shows **Check Address** instead, which confirms the address answers. Whether a custom key is accepted only shows when a script uses it. Each test or check spends one call against the daily limit.

## Using it in an experience

Documentation source: [Secrets](https://scenery.app/docs/editor/secrets.md).

Adding a key to your account does not let an experience spend it. That is a separate step, so a key cannot be used by an experience you did not mean to use it in.

Select the key under **My Secrets** and turn on **Use in This Experience**. It then appears under **In Use**, and scripts in this experience can call it:

```js
var response = await http.request('https://api.openai.com/v1/models', {
    secret: 'openai'
});
```

The name in `secret` is the binding's name under **In Use**, not the key's value and not the service's name. Rename the binding and the script has to say the new name.

One key can be used in up to 100 experiences.

## Replacing a key

Documentation source: [Secrets](https://scenery.app/docs/editor/secrets.md).

Select it under **My Secrets** and choose **Replace Value**. The key's identity does not change, so every experience and every script using it keeps working. Nothing needs editing anywhere.

This is the reason to reach for secrets even on an experience only you will ever open: rotating a key is one field, not a search through your scripts.

## The daily limit

Documentation source: [Secrets](https://scenery.app/docs/editor/secrets.md).

The limit counts **calls, not money**, and it is shared by everyone who opens an experience that uses the key. A thousand visitors asking one question each is a thousand calls against the same number.

When a key has spent its limit, further calls are refused until it resets. A script can tell that apart from other failures and say something useful rather than going quiet:

```js
try {
    var response = await http.request(url, { secret: 'openai' });
} catch (error) {
    if (error.reason === 'ceiling_reached') {
        // error.details.limit and error.details.resetAt say what and when
    }
}
```

Three refusals are worth handling separately. `ceiling_reached` means the limit is spent and `details.resetAt` says when it returns. `owner_busy` is momentary and worth retrying shortly. `owner_not_entitled` means the plan of the account the key belongs to no longer covers secrets, so no viewer can spend it until that account subscribes again.

Note that the API's own refusal is not an error here. A vendor answering 429 or 400 arrives as an ordinary response carrying that status, so a script that only wraps the call in `try` will miss it. Check `response.status`.

## Working as a team

Documentation source: [Secrets](https://scenery.app/docs/editor/secrets.md).

A key belongs to one account, never to a team or an experience. What is shared is permission to spend it.

So when you use your key in an experience and a teammate opens that experience, their calls go out on your key and against your daily limit. They cannot see it, copy it, or change it. Under **In Use** it is marked as yours, its name is fixed, and the key itself is not shown.

A teammate can also bring their own key for an experience they author. Both can be true in one experience: some names on your key, some on theirs.

If a teammate wants an experience to use their own key instead of yours, they can **Replace Key** – Scenery asks first and says whose key it is replacing, because the experience stops working for everyone if the new key is for a different API. **Remove Key** likewise asks, because only you can put yours back.

## Copies and templates

Documentation source: [Secrets](https://scenery.app/docs/editor/secrets.md).

A copy of someone else's experience, or one started from a template, keeps the **names** its scripts call and drops the **keys** behind them. Nobody inherits a key by duplicating.

Such a binding reads as needing your own key: the name is there, the key is not, and you pick one of yours to fill it. Until you do, scripts calling that name are refused with a reason that says the key is not set rather than one that looks like a typo.

Duplicating your *own* experience keeps its keys, since they were already yours to spend.

## What secrets cannot do yet

Documentation source: [Secrets](https://scenery.app/docs/editor/secrets.md).

::: warning Request and response only
A secret works for an ordinary request and its reply, with the key in a header. Three things are outside that:

* **Responses are capped at 5 MB.** A larger reply is refused with the reason `response_too_large`. For speech that is roughly 80 seconds of audio at the usual quality, which is ample for a spoken line and not enough for a long passage.
* **No streaming and no sockets.** The request completes and returns; there is nothing to subscribe to.
* **Realtime sessions are not available.** `secrets.mint`, which would hand a short-lived credential to the device for a realtime voice session, refuses with `mint_not_supported`.
  :::

Any API that takes its key in a header and answers in one reply works, whichever service it is.

## See also

Documentation source: [Secrets](https://scenery.app/docs/editor/secrets.md).

* [Fetch data from an API](https://scenery.app/docs/scripting/guide/examples#fetch-data-from-an-api) – worked examples, including [when a call fails](https://scenery.app/docs/scripting/guide/examples#when-an-api-call-fails)
* [HTTPClient](https://scenery.app/docs/scripting/api/httpclient) – the `secret` option in full

