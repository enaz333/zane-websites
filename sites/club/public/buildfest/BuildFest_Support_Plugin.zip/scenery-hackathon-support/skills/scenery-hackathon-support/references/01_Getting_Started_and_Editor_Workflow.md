# Getting Started and Editor Workflow

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: new here; Create button missing; where do I click; preview; scene; object; container; account; assets library.

## Contents

- Guide
- What Is Scenery?
- What Makes It Different
- Create Your First Experience
- Experience Library
- Asset Library & Folders
- Settings & Account
- Keyboard Shortcuts
- Editor Overview
- Experiences, Scenes & Objects

---

Source page: Guide

Source URL: https://scenery.app/docs/guide.md

# Guide

Documentation source: [Guide](https://scenery.app/docs/guide.md).

The "what is this and how do I start" layer, before the deep [Editor](https://scenery.app/docs/editor/overview) and [Scripting](https://scenery.app/docs/scripting/) reference.

## Getting started

Documentation source: [Guide](https://scenery.app/docs/guide.md).

* [What is Scenery?](https://scenery.app/docs/guide/what-is-scenery) – what the platform is and what you can build.
* [What makes it different](https://scenery.app/docs/guide/what-makes-different) – how Scenery compares to other tools.
* [Create your first experience](https://scenery.app/docs/guide/first-experience) – the shortest path to your first scene.
* [Understanding the editor](https://scenery.app/docs/editor/overview) – a tour of where everything lives.

## Discover & manage

Documentation source: [Guide](https://scenery.app/docs/guide.md).

* [Discover & your experiences](https://scenery.app/docs/guide/discover) – the Discover section and managing your experiences.
* [Asset library & folders](https://scenery.app/docs/guide/asset-library) – browse and organize your assets.
* [Settings & account](https://scenery.app/docs/guide/settings) – account and preferences.

## Reference & help

Documentation source: [Guide](https://scenery.app/docs/guide.md).

* [Compatibility](https://scenery.app/docs/guide/compatibility) – which features run on which devices.
* [Publishing & sharing](https://scenery.app/docs/guide/publishing) – getting an experience to users.
* [Keyboard shortcuts](https://scenery.app/docs/guide/keyboard-shortcuts) – speed up your workflow.
* [FAQ](https://scenery.app/docs/guide/faq) – common questions.

---

Source page: What Is Scenery?

Source URL: https://scenery.app/docs/guide/what-is-scenery.md

# What Is Scenery?

Documentation source: [What Is Scenery?](https://scenery.app/docs/guide/what-is-scenery.md).

Scenery is an Apple-native **spatial creation suite** – a no-code tool for building and sharing high-quality AR experiences for **mobile** and **Apple Vision Pro**.

You build visually, on Mac and iPad, and ship to every platform. Experiences are **multi-sensory** (spatial audio, custom haptics), can be **location-based** and globally accessible, and open **instantly, with no app download**, through App Clips.

## What you can build

Documentation source: [What Is Scenery?](https://scenery.app/docs/guide/what-is-scenery.md).

* **Contextual AR** embedded in real surroundings – tied to a place, an image, or the space around the user.
* **Multi-scene, interactive** experiences through a no-code event system, with dynamic physics for realism.
* **Rich media** – 3D models (USDZ), video (including spatial, transparent, and video textures), images, spatial and ambient audio, haptics, and custom shaders and post-processing.
* **Native-app polish** out of the box: people and object occlusion, solid tracking, and built-in photo and video capture with your own branding.

For developers, JavaScript scripting and custom-shader support take experiences further when you need it.

Scenery is made by **Amped Labs**, an XR studio in Berlin, and grew out of their earlier location-based AR app, Scavengar.

---

Source page: What Makes It Different

Source URL: https://scenery.app/docs/guide/what-makes-different.md

# What Makes It Different

Documentation source: [What Makes It Different](https://scenery.app/docs/guide/what-makes-different.md).

Most AR tools force a trade-off: native apps look great but need a download, while WebAR is instant but rough. **Scenery gives you both** – native-app fidelity and performance, shared instantly with no app install.

* **Quality without friction.** Best-in-class tracking, people and object occlusion, and high visual fidelity, delivered through App Clips so there's nothing to download. (Think "WebAR, but good.")
* **Build once, deploy everywhere.** Author on Mac and iPad, then ship to mobile and Apple Vision Pro from the same project.
* **Learnable in a day.** A human-centric interface that follows Apple's design guidelines – quick to pick up, masterable in weeks rather than months.
* **Contextual and multi-sensory.** Content embedded in real surroundings, with spatial audio and custom haptics for genuine immersion – not AR as a gimmick.
* **No-code to low-code.** A no-code event system for most work, with JavaScript scripting and custom shaders when you want to go deeper.

---

Source page: Create Your First Experience

Source URL: https://scenery.app/docs/guide/first-experience.md

# Create Your First Experience

Documentation source: [Create Your First Experience](https://scenery.app/docs/guide/first-experience.md).

This walks through starting a brand-new experience, from the Create button to the editor.

::: tip Where to build
The **Create experience** button currently appears on **Mac** and **iPad** – the platforms suited to building. **iPhone** and **Apple Vision Pro** are mainly for viewing experiences.
:::

## 1. Start from a template, or from scratch

Documentation source: [Create Your First Experience](https://scenery.app/docs/guide/first-experience.md).

Click **Create experience**, and you're shown a **template** picker:

* **Custom** – a blank experience built entirely from scratch. The best choice when you're learning, or when no template fits.
* **Templates** – ready-made starting points that come with content and logic already set up, for common use cases: image tracking, face tracking, a showroom, location-based AR, a physics playground, a puzzle, architecture, spatial audio, a scavenger hunt, visual effects / spatial video, custom materials, a mixed-reality portal, and more.

The template list grows over time, so check back for new ones.

![The Create Experience dialog – a category sidebar and a grid of templates (Image Tracking, Face-Tracking, Showroom, Location-based AR, and more)](https://scenery.app/docs/assets/template-picker.D41B16FP.jpg)
*The Create Experience template picker.*

## 2. Choose a tracking context

Documentation source: [Create Your First Experience](https://scenery.app/docs/guide/first-experience.md).

Next, set the experience's **[tracking context](https://scenery.app/docs/editor/tracking-contexts)** – how it understands and anchors to the world (the space around the user, a real-world location, an image, or a face).

::: warning This choice is permanent
You can only set the context **at the very beginning**, and it **can't be changed later**. Make sure it's right before you continue. Most experiences should use **World-Tracking**, the most flexible and compatible context.
:::

As you select a context, a [compatibility](https://scenery.app/docs/guide/compatibility) indicator shows which platforms support it.

## 3. Create and enter the editor

Documentation source: [Create Your First Experience](https://scenery.app/docs/guide/first-experience.md).

Click **Create**, and your new experience opens in the **editor**, where you place content, anchor it to the world, and make it interactive.

Next: [Understanding the editor](https://scenery.app/docs/editor/overview).

---

Source page: Experience Library

Source URL: https://scenery.app/docs/guide/discover.md

# Experience Library

Documentation source: [Experience Library](https://scenery.app/docs/guide/discover.md).

The **Experiences** tab is your library – every experience you create lives here. Organize them into **folders**, just like the asset library.

Each experience offers:

* **Share** – share it with others.
* **Edit** – open it in the editor.
* **Start** – run (simulate) it on the device you're using.
* **Duplicate** and **Delete**, from the **⋯** menu. Duplicating is a great way to keep a **backup** before reworking part of an experience.

## Discover

Documentation source: [Experience Library](https://scenery.app/docs/guide/discover.md).

When you open Scenery, you land on the **Discover** section – the home for browsing experiences and finding your way around.

* **Featured experiences** – picks from the Scenery team, featured creators, and agency / enterprise clients. (Interested in being featured? Reach out to us.)
* **Made by creators** – community work. When you set an experience to **Public**, it can appear here.
* **Resources** – links to the Discord, tutorials, the documentation, and answers to questions creators ask often.

## Resources & roadmap

Documentation source: [Experience Library](https://scenery.app/docs/guide/discover.md).

* **Tutorials** – a series to help you get started building.
* **Feature roadmap** – what's in the making, and where you can **request features** to help shape what comes next.

---

Source page: Asset Library & Folders

Source URL: https://scenery.app/docs/guide/asset-library.md

# Asset Library & Folders

Documentation source: [Asset Library & Folders](https://scenery.app/docs/guide/asset-library.md).

The **asset library** holds everything you can place in an experience – 3D models, images, videos, audio, and more. Open it from the **Assets** tab, or from within the editor at any time.

## Asset types

Documentation source: [Asset Library & Folders](https://scenery.app/docs/guide/asset-library.md).

The library is organized by type:

* **3D** – 3D models in **USDZ**, including ready-made assets, particle systems, and ShaderGraph materials. (Prepare them in Reality Composer Pro and export as USDZ.)
* **Images** – **PNG** (with transparency) and **JPEG**.
* **Videos** – standard video, plus **spatial (stereoscopic)** video (marked automatically when the system detects it) and **transparent** video. Transparent video lets you build polished, layered experiences without touching 3D.
* **Shader libraries** – custom **Metal** shaders (see [Materials](https://scenery.app/docs/editor/materials) and [Post-FX](https://scenery.app/docs/editor/post-fx)).
* **Audio** – sound files (MP3, WAV, M4A) for spatial, ambient, and effect audio.
* **Custom haptics** – **AHAP** patterns for tactile feedback.
* **Environment maps** – **HDR / 360°** images for custom lighting and backgrounds (see [Environments & lighting](https://scenery.app/docs/editor/environments-lighting)).
* **Splat captures** – **SPZ** scans of a real object or place (see [Adding Content](https://scenery.app/docs/editor/adding-content#gaussian-splat)).

## Uploading

Documentation source: [Asset Library & Folders](https://scenery.app/docs/guide/asset-library.md).

Upload with the **Upload asset** button, or simply **drag and drop** files into the library – or straight into the editor.

## Working with an uploaded asset

Documentation source: [Asset Library & Folders](https://scenery.app/docs/guide/asset-library.md).

Select an asset to reveal what can be done with it – **Preview** it, **Replace** the file while
keeping every reference to it intact, **Rename** it, or **Delete** it.

Two entries appear only where they apply:

* **Set Custom Thumbnail** – replaces the picture shown on the asset's tile with an image of your
  choosing.
* **Generate Thumbnail** – draws a preview for an asset no thumbnail could be made for
  automatically, currently splat captures. It appears only while the asset still has none, and needs
  a device that can draw the asset.

**Alternate Files** opens a sheet with the asset's details and, for a splat capture, its
[renditions](https://scenery.app/docs/editor/adding-content#renditions).

A capture's tile also shows its **splat count** beside its file size, since the count is what decides
whether it draws in full on a given device.

## Folders

Documentation source: [Asset Library & Folders](https://scenery.app/docs/guide/asset-library.md).

Keep things organized with **folders**, available here and across the app. Create a folder, give it a **name**, a **colour**, and an **icon**, then **drag and drop** assets into it. Right-click a folder to delete it – the assets move back out, they aren't lost.

::: tip Find assets fast
A library gets unwieldy across projects. Lean on folders to stay organized, and use the **search** bar to find an asset by name.
:::

---

Source page: Settings & Account

Source URL: https://scenery.app/docs/guide/settings.md

# Settings & Account

Documentation source: [Settings & Account](https://scenery.app/docs/guide/settings.md).

Open **Settings** to manage your account and preferences.

## Account & profile

Documentation source: [Settings & Account](https://scenery.app/docs/guide/settings.md).

* **Name** – tap your name to change how you appear to others.
* **Profile image** – set or change your avatar.

**Signing in.** Scenery offers two methods, and you can use either or both: **Sign in with Apple** (quickest, via your Apple Account) and **Email & password**. From Settings you can **Connect Apple Sign-In** (if you started with email), **Add Email & Password** (if you started with Apple), or **Reset Password**.

**Why you need an account.** You can browse Scenery without signing in, but to **create, save, and own** experiences – and to **subscribe to a paid plan** – you connect a real account. That ties your work and your subscription to you, so they stay safe and follow you across devices. Scenery prompts you to connect one the first time you create or manage content.

## Tools

Documentation source: [Settings & Account](https://scenery.app/docs/guide/settings.md).

* **Open experience via link** – paste an experience link to open it directly, handy if it won't open another way.
* **Rate Scenery** – leave a star rating and a short note.
* **Send feedback** – tell us what's working and what isn't.
* **Delete cache** – clear cached data.
* **Sign out** and **Delete account**.

## About

Documentation source: [Settings & Account](https://scenery.app/docs/guide/settings.md).

The **About** screen shows your **Scenery version**, links to **privacy** and **terms**, **beta** info (if you're in a beta), social channels, and a link to **join our Discord** – the place to share work and get first-hand help from other creators.

---

Source page: Keyboard Shortcuts

Source URL: https://scenery.app/docs/guide/keyboard-shortcuts.md

# Keyboard Shortcuts

Documentation source: [Keyboard Shortcuts](https://scenery.app/docs/guide/keyboard-shortcuts.md).

The Scenery editor is built for **Mac** and **iPad with a hardware keyboard** – that's where these shortcuts apply. iPhone and Apple Vision Pro are mainly for viewing experiences. On Mac, the editor commands also live in the **menu bar**, so you can always rediscover them there.

Modifier keys: ⌘ Command, ⇧ Shift, ⌥ Option, ⎋ Escape, ↩ Return, ⌫ Delete.

## App & windows

Documentation source: [Keyboard Shortcuts](https://scenery.app/docs/guide/keyboard-shortcuts.md).

| Shortcut | Action |
|---|---|
| ⌘N | New window |
| ⌘? | Open the documentation |
| ⌘F | Search – in Discover, the Asset Library, and your Experiences |
| ⎋ | Close or cancel the current panel |
| ↩ | Confirm the default button in a dialog |

## Editor – experience

Documentation source: [Keyboard Shortcuts](https://scenery.app/docs/guide/keyboard-shortcuts.md).

| Shortcut | Action |
|---|---|
| ⌘S | Save the experience |
| ⌘W | End editing (close the editor) |
| ⌘P | Preview the experience |
| ⌘. | Stop the preview |
| ⌘⇧P | Preview the selected object |
| ⌥A | Run the selected action – press again to stop |
| ⌘⌥R | Send to connected devices  |

## Playing an experience

Documentation source: [Keyboard Shortcuts](https://scenery.app/docs/guide/keyboard-shortcuts.md).

Available to the experience's owner and their team, in an experience that uses scripting.

| Shortcut | Action |
|---|---|
| ⌘⌥C | Show the console |

Inside the console's input field:

| Shortcut | Action |
|---|---|
| ↩ | Run what you typed |
| ⇧↩ | Add a line instead of running |
| ↑, ↓ | Step through what you ran before – while the field holds a single line |
| ⎋ | Close the console's search field |

## Editor – objects

Documentation source: [Keyboard Shortcuts](https://scenery.app/docs/guide/keyboard-shortcuts.md).

| Shortcut | Action |
|---|---|
| ⌘C, ⌘X, ⌘V | Copy, cut, paste the selected object |
| ⌘D | Duplicate the selected object |
| ⌘F | Frame the selected object in the viewport |
| ⌥ *(hold while dragging)* | Snap the gizmo to a grid |
| ⇧ *(click)*, ⌘ *(click)* | Add an object to the selection, or remove it again |
| ⇧ *(drag in the viewport)* | Draw a rectangle to select everything inside it |
| ⌘⇧ *(drag in the viewport)* | Draw a rectangle and add what it covers to the selection |

## Editor – interface builder

Documentation source: [Keyboard Shortcuts](https://scenery.app/docs/guide/keyboard-shortcuts.md).

In the [UI editor](https://scenery.app/docs/editor/user-interface/#the-ui-editor):

| Shortcut | Action |
|---|---|
| ↑, ↓ | Select the previous, next element |
| ⌘C, ⌘X, ⌘V | Copy, cut, paste an element |
| ⌘D | Duplicate the selected element |
| ⌘⌥C, ⌘⌥V | Copy, paste an element's style |
| ↩ | Rename the selected element |
| ⌫ | Delete the selected element |
| ⌘Z, ⌘⇧Z | Undo, redo |

## Media – video trim

Documentation source: [Keyboard Shortcuts](https://scenery.app/docs/guide/keyboard-shortcuts.md).

When choosing a video's thumbnail or trim point:

| Shortcut | Action |
|---|---|
| ←, → | Step one frame back, forward |
| ↩ | Confirm |
| ⎋ | Cancel |

---

Source page: Editor Overview

Source URL: https://scenery.app/docs/editor/overview.md

# Editor Overview

Documentation source: [Editor Overview](https://scenery.app/docs/editor/overview.md).

A quick tour of where things live in the editor. You arrive here after [creating an experience](https://scenery.app/docs/guide/first-experience) and choosing its tracking context.

## Around the canvas

Documentation source: [Editor Overview](https://scenery.app/docs/editor/overview.md).

The numbers below match the numbered points on the screenshot.

1. **Hierarchy** (left) – the objects in the current scene.
2. **Add (+)** (top) – [add content](https://scenery.app/docs/editor/adding-content) to the scene.
3. **Undo / Redo** – step back and forth through your changes.
4. **Snapshot** – capture the scene as a preview image for the experience.
5. **Asset Library** – open the library at any time.
6. **Send to Devices**  – push your edits to a device in **real time**. While you're actively editing, open the experience on another device (iPhone, iPad, Vision Pro) signed in with the **same Apple ID or connected email address**, and it automatically appears here as a connected device; changes you make are reflected live as you build. Especially powerful on visionOS.
7. **Preview** – run the experience in a **simulator**, or in **AR** on the device you're building on. Choose **full experience** or **selected object only** (very useful for iterating on one element of a complex object, like a single animation).
8. **Settings** – experience and app settings.
9. **Sidebar toggle** – show or hide the side panel.

A few of these open something worth seeing up close:

## Moving around the viewport

Documentation source: [Editor Overview](https://scenery.app/docs/editor/overview.md).

* **Orbit** by click-dragging; **move** with WASD or the arrow keys. With a **trackpad**, you can also navigate the scene with **two-finger swipes** and **pinch** gestures.
* The **axis gizmo** (top-right) shows X/Y/Z; click a face to snap the view, or use keys **1–6**.
* **⌘F** recenters the view on the selected object.
* Switch **view presets** (front, left, top, …) and toggle **perspective / orthographic** camera.
* A **background & lighting** button opens the [environment settings](https://scenery.app/docs/editor/environments-lighting).

![The viewport view-preset menu open – Perspective, Orthographic, and the Front/Back/Left/Right/Top/Bottom views](https://scenery.app/docs/assets/viewport-tools.CCYC_Cx1.jpg)
*The view-preset menu – perspective / orthographic and the standard views.*

## The bottom panel

Documentation source: [Editor Overview](https://scenery.app/docs/editor/overview.md).

A contextual panel along the bottom, with tabs:

* **Events** (default) – object and scene [events](https://scenery.app/docs/editor/triggers).
* **Materials** – your custom [materials](https://scenery.app/docs/editor/materials).
* **Post-FX** – [post-processing effects](https://scenery.app/docs/editor/post-fx).
* **Statistics** – coming soon.

Drag the panel up for more room, or use the corner controls to minimize or enlarge it.

![The bottom panel maximized, showing the Events, Materials and Post-FX tabs](https://scenery.app/docs/assets/bottom-panel.BZrj6Uht.jpg)
*The bottom panel, maximized – Events, Materials, Post-FX, and more.*

## Hierarchy, selection & right-click

Documentation source: [Editor Overview](https://scenery.app/docs/editor/overview.md).

The **hierarchy** (left) lists the scene's objects. Most elements – in the hierarchy *or* the viewport – respond to **right-click** with the same menu:

* **Frame Selected** (or ⌘F) – centre the view on it.
* **Duplicate** / **Delete**.
* **Lock / Unlock** – stop an object being moved by accident (good for carefully composed containers).
* **Show Events** – jump to its events.
* **Wrap in Container** – put it inside a new container.
* **Add Event** / **Quick Events** – set up a trigger without opening the Events panel (Quick Events are pre-built combos, e.g. remove-on-collision-and-show-next for scavenger hunts).
* **Copy Development ID** – the object's unique ID, for referencing it in [scripts](https://scenery.app/docs/scripting/).

![The right-click menu on an object – Frame Selected, Duplicate, Delete, Lock, and Copy Development ID](https://scenery.app/docs/assets/right-click-menu.DUtVL3el.jpg)
*The right-click menu on an object.*

Other handy moves:

* **Hide / show** – the eye icon (hover an item) temporarily removes it from the scene, like toggling a layer – useful for comparing versions. A hidden object shows an invisible marker in Scene Events.
* **Multi-select** – ⌘-click several objects (in the viewport or hierarchy) to get one shared gizmo and transform them together.

The same right-click also works in the **Events** panel (copy/duplicate an action or a whole chain).

## Scenes

Documentation source: [Editor Overview](https://scenery.app/docs/editor/overview.md).

An experience can hold **multiple scenes**. Click the **arrow** next to the current scene for an overview; right-click a scene to **duplicate** it (an exact copy of all its content and events), and double-click / Enter to rename. Move between scenes at runtime with the [Transition to Scene](https://scenery.app/docs/editor/actions/experience) action.

![The hierarchy showing more than one scene](https://scenery.app/docs/assets/scenes-overview.DuvNy5xU.jpg)
*Multiple scenes in the hierarchy.*

---

Source page: Experiences, Scenes & Objects

Source URL: https://scenery.app/docs/editor/concepts.md

# Experiences, Scenes & Objects

Documentation source: [Experiences, Scenes & Objects](https://scenery.app/docs/editor/concepts.md).

A few core ideas show up everywhere in Scenery. Understanding how they nest makes the rest of the editor click.

## Experience

Documentation source: [Experiences, Scenes & Objects](https://scenery.app/docs/editor/concepts.md).

An **Experience** is the whole thing you build and share – one project, with its own settings, link, and [tracking context](https://scenery.app/docs/editor/tracking-contexts). An experience can hold **one or more Scenes**.

## Scene

Documentation source: [Experiences, Scenes & Objects](https://scenery.app/docs/editor/concepts.md).

A **Scene** is a self-contained stage within an experience – its own content, events, lighting, and settings. Simple experiences have a single scene; larger ones use **several**, moving between them at runtime with the [Transition to Scene](https://scenery.app/docs/editor/actions/experience) action. Manage scenes from the hierarchy (see [Editor overview](https://scenery.app/docs/editor/overview#scenes)).

## Object

Documentation source: [Experiences, Scenes & Objects](https://scenery.app/docs/editor/concepts.md).

An **Object** is something you place in a scene – the root node you select and move. Crucially, an object is what **carries the anchor** that decides where and how it attaches to the world (see [Anchors](https://scenery.app/docs/editor/anchors)).

Inside each object sits its **visual content** – a 3D model, an image or video, a UI panel, and so on. Select the **object** (not the content nested inside it) to anchor and position it; the content moves with it.

## Container

Documentation source: [Experiences, Scenes & Objects](https://scenery.app/docs/editor/concepts.md).

A **Container** is an object that **groups other objects**. Anchor and move a container, and everything inside it comes along – handy for arranging several objects as one unit, or anchoring a group together.

::: tip Object vs. its content
Tracking comes from the **object's** position, so fine-tune placement by moving the **object**, not the model inside it. See [Anchors](https://scenery.app/docs/editor/anchors).
:::

