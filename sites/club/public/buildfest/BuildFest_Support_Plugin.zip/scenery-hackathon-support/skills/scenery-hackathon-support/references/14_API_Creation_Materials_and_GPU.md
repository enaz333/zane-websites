# API Creation Materials and GPU

Evidence: official Scenery documentation. Snapshot: November 5, 2026. Full source text, reorganized; no feature guarantees beyond the source.

Participant search terms: createEntity; factory; descriptor; Anchor; Material; GPU; compute; Kernel; mesh; texture; instances.

Audience: advanced reference. Retrieve only when code is necessary or explicitly requested. Start with the guides in 08 before using API signatures.

## Contents

- Kernel beta
- Texture beta
- TextureBinding
- Buffer beta
- EngineBufferBinding
- Splat
- SplatAttribute
- InstanceData
- Light
- Anchor
- ObjectTraits
- ObjectDescriptor
- Material
- Mesh beta
- Instances beta
- Global Functions

---

Source page: Kernel beta

Source URL: https://scenery.app/docs/scripting/api/kernel.md

# Kernel beta

Documentation source: [Kernel beta](https://scenery.app/docs/scripting/api/kernel.md).

Opaque handle to a compiled GPU compute kernel. Returned by `Kernel.fromSource(...)` / `Kernel.fromAsset(...)`. Two dispatch entry points: `kernel.run({...})` for standalone compute (texture / buffer I/O, no mesh involvement) and `mesh.runCompute(kernel, options)` when the kernel writes mesh-attribute buffers.

## Properties

Documentation source: [Kernel beta](https://scenery.app/docs/scripting/api/kernel.md).

### functionName

Documentation source: [Kernel beta](https://scenery.app/docs/scripting/api/kernel.md).

* **Type:** string
* Display name of the kernel's entry-point function.

### id

Documentation source: [Kernel beta](https://scenery.app/docs/scripting/api/kernel.md).

* **Type:** string
* Stable handle id assigned at construction. Surfaces in the scripting manager's live-set; used by `destroy()` to release the experience-lifetime retention.

## Static Methods

Documentation source: [Kernel beta](https://scenery.app/docs/scripting/api/kernel.md).

### fromAsset()

Documentation source: [Kernel beta](https://scenery.app/docs/scripting/api/kernel.md).

```javascript
Kernel.fromAsset(options: Object): Promise<Kernel>
```

Compile a compute kernel from a shader-library asset declared in the experience's asset library.

**Parameters:**

* `options` (Object)
* `options.assetId` (string) - Shader-library asset id.
* `options.functionName` (string) - Kernel entry-point name.

**Returns:** Promise\<Kernel>

### fromSource()

Documentation source: [Kernel beta](https://scenery.app/docs/scripting/api/kernel.md).

```javascript
Kernel.fromSource(options: Object): Promise<Kernel>
```

Compile a compute kernel from inline MSL source. Handy for prototypes and tests; production scripts should prefer `Kernel.fromAsset(...)` so the source lives in the experience's asset library.

**Example:**

```javascript
const kernel = await Kernel.fromSource({
    source: `#include <metal_stdlib>
             using namespace metal;
             kernel void wave(...) { ... }`,
    functionName: 'wave'
});
```

**Parameters:**

* `options` (Object)
* `options.source` (string) - MSL source string.
* `options.functionName` (string) - Kernel entry-point name.

**Returns:** Promise\<Kernel>

## Methods

Documentation source: [Kernel beta](https://scenery.app/docs/scripting/api/kernel.md).

### destroy()

Documentation source: [Kernel beta](https://scenery.app/docs/scripting/api/kernel.md).

```javascript
destroy(): void
```

Release the kernel's GPU resources (compiled library + pipeline state) immediately. Use in hot loops where JSC's non-deterministic GC would otherwise stretch the lifetime. Normal scripts don't need to call this – ARC handles cleanup when the kernel goes out of scope. Calling `mesh.runCompute(...)` or `kernel.run(...)` against a destroyed kernel warns and aborts the dispatch.

**Returns:** void

### run()

Documentation source: [Kernel beta](https://scenery.app/docs/scripting/api/kernel.md).

```javascript
run(options: { uniforms?, inputBuffers?, outputBuffers?, inputTextures?, outputTextures?, threadGroups, threadsPerThreadgroup? }): void
```

Dispatch the kernel against textures and / or `Buffer` handles – no mesh involvement. Use for compute passes that don't write mesh attribute buffers (texture generation, particle simulation pre-pass, any "pure compute" kernel that doesn't displace geometry).

MSL slot order: `buffer(0)` uniforms → `buffer(1..)` inputBuffers then outputBuffers → `texture(0..)` inputTextures then outputTextures.

**Example:**

```javascript
kernel.run({
    uniforms: new Float32Array([scene.time]),
    outputTextures: { heightOut: heightMap.write },
    threadGroups: [16, 16, 1]
});
```

**Parameters:**

* `options` ({ uniforms?, inputBuffers?, outputBuffers?, inputTextures?, outputTextures?, threadGroups, threadsPerThreadgroup? })

**Returns:** void

---

Source page: Texture beta

Source URL: https://scenery.app/docs/scripting/api/texture.md

# Texture beta

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

A GPU texture created and managed at runtime. Construct one from an image or video source (`Texture.image(...)`, `Texture.video(...)`), the live camera feed (`Texture.cameraFeed()`), or a compute kernel that writes its pixels (`Texture.compute(...)`).

For a compute-written texture the kernel writes the pixels and materials sample the same texture through the same handle, so updates show up in the next rendered frame without an explicit copy. Feed `.read` / `.write` tokens into a kernel's `inputTextures` / `outputTextures` maps.

## Properties

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

### depth

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

* **Type:** number
* Depth (slices) for 3D textures, layer count for arrays. `1` for flat 2D / cubemap-face textures.

### height

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

* **Type:** number

### id

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

* **Type:** string
* Texture id – matches `dynamicTexture.id`. Stable for the lifetime of the texture; surfaces in material `TextureReference.dynamic` references.

### pixelFormat

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

* **Type:** string
* Engine-agnostic pixel format name (e.g. `"rgba32Float"`).

### read

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

* **Type:** [TextureBinding](https://scenery.app/docs/scripting/api/texturebinding)
* Token tagged as "read into kernel" – pass to a kernel's `inputTextures` map.

### textureType

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

* **Type:** string
* Texture dimensionality: `"2d"`, `"3d"`, `"cube"`, `"2dArray"`, `"cubeArray"`.

### width

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

* **Type:** number

### write

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

* **Type:** [TextureBinding](https://scenery.app/docs/scripting/api/texturebinding)
* Token tagged as "write from kernel" – pass to a kernel's `outputTextures` map.

## Static Methods

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

### cameraFeed()

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

```javascript
Texture.cameraFeed(options?: Object): Promise<Texture>
```

Live camera feed as a sampleable texture. Binds the device's camera capture as a regular texture handle – typical uses are first-person portal effects, augmented-reality color grading on detected planes, or piping the feed into a compute kernel for a real-time filter.

Available on iOS / iPadOS only – Mac Catalyst and visionOS don't expose the AR camera capture. Always gate with `environment.features.has('cameraFeed')`.

**Example:**

```javascript
if (!environment.features.has('cameraFeed')) return;
const camTex = await Texture.cameraFeed();
await entity.representation.setMaterial(Material.unlit({ map: camTex }));
```

**Parameters:**

* `options` (Object) *(optional)*
* `options.semantic` (string) *(optional)*

**Returns:** Promise\<Texture>

### compute()

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

```javascript
Texture.compute(options: Object): Promise<Texture>
```

Allocate a GPU-only texture written by a compute kernel. Supports 2D, 3D, cube, and array textures with optional mipmap chains.

Async because the dynamic-texture asset-provider funnel allocates the underlying GPU resource and registers it in the runtime's manager cache (so material binding finds the same instance later). Authors `await` once at allocation; subsequent kernel dispatches are sync.

**Example:**

```javascript
// 2D height map for a wave-grid kernel
const heightMap = await Texture.compute({
    pixelFormat: 'rgba32Float',
    width: 256,
    height: 256
});

// 3D scalar field for volumetric / marching-cubes work
const field = await Texture.compute({
    textureType: '3d',
    pixelFormat: 'r32Float',
    width: 64, height: 64, depth: 64
});

// Compute-driven normal map sampled by a PBR material
const normalMap = await Texture.compute({
    pixelFormat: 'rgba8Unorm',
    width: 512, height: 512,
    semantic: 'normal'
});
```

**Parameters:**

* `options` (Object)
* `options.pixelFormat` (string) - e.g. `'rgba32Float'`, `'rgba16Float'`, `'r32Float'`.
* `options.textureType` (string) *(optional)* - `'2d' | '3d' | 'cube' | '2dArray' | 'cubeArray'`.
* `options.width` (number)
* `options.height` (number)
* `options.depth` (number) *(optional)* - Slice count for 3D textures.
* `options.arrayLength` (number) *(optional)* - Layer count for arrays.
* `options.mipmapLevelCount` (number) *(optional)* - Set > 1 + call `texture.generateMipmaps()` to populate.
* `options.semantic` (string) *(optional)* - `'color' | 'normal' | 'scalar' | 'hdrColor' | 'raw'`. Tells material binding how to sample (sRGB vs linear, etc.).
* `options.usage` (Array\<string>) *(optional)*

**Returns:** Promise\<Texture>

### image()

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

```javascript
Texture.image(urlOrId: string, options?: Object): Promise<Texture>
```

Static image-asset texture. Reads an image asset (PNG / JPG / etc.) from the experience's asset library or an absolute URL and binds it as a sampleable texture – typical use is a hand-painted normal map or albedo map fed to `Material.pbr({ normalMap: tex })`.

**Example:**

```javascript
const normalMap = await Texture.image('rocks-normal.png', { semantic: 'normal' });
await entity.representation.setMaterial(Material.pbr({
    map: 'rocks-color.png',
    normalMap: normalMap
}));
```

**Parameters:**

* `urlOrId` (string) - HTTPS URL or asset id from the project library.
* `options` (Object) *(optional)*
* `options.semantic` (string) *(optional)* - `'color' | 'normal' | 'scalar' | 'hdrColor' | 'raw'`. Tells material binding how to sample (sRGB vs linear).

**Returns:** Promise\<Texture>

### video()

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

```javascript
Texture.video(urlOrId: string, options?: Object): Promise<Texture>
```

Video-asset texture. Plays a video file (mp4 / mov) as a sampleable texture and binds it to a material – typical use is a looping background, an animated diorama, or a UI-overlay video sticker.

The video starts playing automatically by default. Pass `{ autoplays: false }` and call `videoTexture.play()` later when the entity becomes visible.

**Example:**

```javascript
const intro = await Texture.video('intro-loop.mp4', { loops: true, volume: 0.3 });
await entity.representation.setMaterial(Material.unlit({ map: intro }));
```

**Parameters:**

* `urlOrId` (string) - HTTPS URL or asset id from the project library.
* `options` (Object) *(optional)*
* `options.semantic` (string) *(optional)* - `'color' | 'normal' | 'scalar' | 'hdrColor' | 'raw'`.
* `options.loops` (boolean) *(optional)* - Restart from frame 0 on end.
* `options.autoplays` (boolean) *(optional)* - Start playback as soon as the asset is ready.
* `options.volume` (number) *(optional)* - Linear gain (0..1). Unset = system default.
* `options.streamContent` (boolean) *(optional)* - HTTP streaming vs. download-then-play.
* `options.isShared` (boolean) *(optional)* - SharePlay sync – when true, playback time syncs across session participants.

**Returns:** Promise\<Texture>

## Methods

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

### destroy()

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

```javascript
destroy(): void
```

Release the texture's GPU memory immediately.

Textures clean up automatically when the proxy goes out of scope. Call `destroy()` only for early termination in hot allocation / teardown loops where JSC's GC delay matters. Subsequent kernel dispatches binding this texture warn and abort, since a skipped binding would shift every later texture into the wrong slot.

**Returns:** void

### generateMipmaps()

Documentation source: [Texture beta](https://scenery.app/docs/scripting/api/texture.md).

```javascript
generateMipmaps(): void
```

Generate the mipmap chain. Runs a synchronous GPU mipmap-generation pass against the texture's command queue. Requires the texture was allocated with `mipmapLevelCount > 1`. No-op on textures without a mip chain.

**Returns:** void

---

Source page: TextureBinding

Source URL: https://scenery.app/docs/scripting/api/texturebinding.md

# TextureBinding

Documentation source: [TextureBinding](https://scenery.app/docs/scripting/api/texturebinding.md).

Marker token returned by `texture.read` / `texture.write`. Carries the backing texture and the role so dispatch knows whether to bind the texture as a kernel read source or write target.

---

Source page: Buffer beta

Source URL: https://scenery.app/docs/scripting/api/buffer.md

# Buffer beta

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

Raw GPU buffer wrapping a typed scratch region for compute kernels. Use for things meshes + textures don't model: atomic counters, lookup tables (e.g. marching cubes' triangle / edge tables), per-particle state, scratch arrays between kernel passes.

Authors construct via `Buffer.float32/uint32/uint8/atomic(...)`. The returned handle binds via `mesh.runCompute(...)`'s `inputBuffers` / `outputBuffers` maps and supports CPU readback via `readSync()` for things like "how many triangles did marching cubes emit this frame?".

## Properties

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

### byteLength

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

* **Type:** number
* Total byte length – `length * elementSize`.

### elementType

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

* **Type:** string
* Element type as a scripting string (`"float32"`, `"uint32"`, `"uint8"`, `"atomic_uint"`).

### id

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

* **Type:** string
* Stable handle id assigned at construction. Surfaces in the scripting manager's live-set; used by `destroy()` to release the experience-lifetime retention.

### length

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

* **Type:** number
* Number of elements (not bytes).

## Static Methods

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

### atomic()

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

```javascript
Buffer.atomic(initialValue?: number): Buffer | any
```

Allocate a single-element atomic-uint counter – common pattern for marching-cubes' triangle emitter, particle compaction, etc.

**Example:**

```javascript
const triCounter = Buffer.atomic(0);

mesh.runCompute(kernel, {
    outputBuffers: { triCount: triCounter },
    threadGroups: [8, 8, 4]
});

const [emitted] = triCounter.readSync();
mesh.drawCount = emitted * 3;
```

**Parameters:**

* `initialValue` (number) *(optional)* - Counter seed.

**Returns:** [Buffer](https://scenery.app/docs/scripting/api/buffer) | any

### float32()

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

```javascript
Buffer.float32(length: number, initialValue?: number): Buffer | any
```

Allocate a Float32-typed GPU buffer.

**Parameters:**

* `length` (number) - Element count (not bytes).
* `initialValue` (number) *(optional)* - Optional seed value for all elements.

**Returns:** [Buffer](https://scenery.app/docs/scripting/api/buffer) | any

### uint32()

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

```javascript
Buffer.uint32(length: number, initialValue?: number): Buffer | any
```

Allocate a Uint32-typed GPU buffer.

**Parameters:**

* `length` (number) - Element count (not bytes).
* `initialValue` (number) *(optional)* - Optional seed value for all elements.

**Returns:** [Buffer](https://scenery.app/docs/scripting/api/buffer) | any

### uint8()

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

```javascript
Buffer.uint8(length: number, initialValue?: number): Buffer | any
```

Allocate a Uint8-typed GPU buffer.

**Parameters:**

* `length` (number) - Element count (not bytes).
* `initialValue` (number) *(optional)* - Optional seed value for all elements.

**Returns:** [Buffer](https://scenery.app/docs/scripting/api/buffer) | any

## Methods

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

### destroy()

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

```javascript
destroy(): void
```

Release the underlying GPU buffer immediately.

Buffers clean up automatically when the proxy goes out of scope. Call `destroy()` only for early termination in hot allocation / teardown loops where JSC's GC delay matters.

**Returns:** void

### readSync()

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

```javascript
readSync(): Float32Array | Uint32Array | Uint8Array
```

Read the buffer contents back to JS as a TypedArray. Blocks until any compute dispatch still in flight has finished, so the values are the ones the kernel wrote – use sparingly (typical pattern: read atomic counters after dispatch to size a downstream draw call).

`elementType`. Nil if the buffer is detached.

**Returns:** Float32Array | Uint32Array | Uint8Array

### writeSync()

Documentation source: [Buffer beta](https://scenery.app/docs/scripting/api/buffer.md).

```javascript
writeSync(data: Float32Array | Uint32Array | Uint8Array): void
```

Write a TypedArray's contents into the buffer (CPU → GPU). Useful for seeding lookup tables, atomic counter resets, particle initial state. Length must match the buffer's declared element count; shorter writes leave the tail untouched. Blocks until any compute dispatch still in flight has finished, so a reset between passes cannot land under a running kernel.

`elementType`.

**Parameters:**

* `data` (Float32Array | Uint32Array | Uint8Array) - matching

**Returns:** void

---

Source page: EngineBufferBinding

Source URL: https://scenery.app/docs/scripting/api/enginebufferbinding.md

# EngineBufferBinding

Documentation source: [EngineBufferBinding](https://scenery.app/docs/scripting/api/enginebufferbinding.md).

Marker token for a GPU buffer the engine owns and renders from, as opposed to the scratch regions a script's own `Buffer` allocates. Mirrors `TextureBinding`: a role plus a way back to the memory, resolved at dispatch.

The provider is held strongly, because a script that writes `outputBuffers: { p: rep.splat.position.write }` keeps nothing else alive by the time the dispatch runs. Keeping the entity out of that chain is the provider's job, not the token's.

Resolution is deferred rather than captured because the engine's backing store for a buffer is not stable between frames, so a handle taken when the token was made would be both unsynchronised and, in time, pointed at a retired allocation.

* Warning: a `.write` token resolves to a fresh backing store, not the previous frame's   contents. A kernel bound to one must write every element it is dispatched over; whatever it   skips is undefined, not preserved.

Deliberately offers no CPU readback. A script may read its own `Buffer` because that is shared storage nobody else writes; an engine-owned buffer has no defined synchronisation while the GPU is mid-write.

---

Source page: Splat

Source URL: https://scenery.app/docs/scripting/api/splat.md

# Splat

Documentation source: [Splat](https://scenery.app/docs/scripting/api/splat.md).

The GPU buffers behind a Gaussian splat, for handing to a compute kernel.

Reached via `entity.representation.splat` on a splat representation; `null` for any other kind. Each attribute vends `.read` and `.write` tokens that go into a kernel's `inputBuffers` / `outputBuffers` maps, exactly as `texture.read` / `texture.write` do.

* Important: pass `threadsPerThreadgroup` whenever the group count was divided by a number of   your own. Left out, it defaults to the GPU's thread execution width (32 on Apple silicon), so   dividing by 64 covers half the capture and leaves the rest of a `.write` buffer undefined.

* Warning: a `.write` token hands the kernel an **uninitialised** buffer, not last frame's   contents. Whatever the kernel does not write is undefined. To change part of an attribute,   bind `.read` as an input in the same dispatch and copy the rest across.

**Example:**

```javascript
const splat = entity.representation.splat;
const THREADS = 64;
kernel.run({
    uniforms: new Float32Array([scene.time, splat.count]),
    inputBuffers:  { src: splat.position.read },
    outputBuffers: { dst: splat.position.write },
    threadGroups: [Math.ceil(splat.count / THREADS), 1, 1],
    threadsPerThreadgroup: [THREADS, 1, 1]
});
```

## Properties

Documentation source: [Splat](https://scenery.app/docs/scripting/api/splat.md).

### boundingBox

Documentation source: [Splat](https://scenery.app/docs/scripting/api/splat.md).

* **Type:** [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox)
* The box around the capture, in the same space as the values in `position`.

### count

Documentation source: [Splat](https://scenery.app/docs/scripting/api/splat.md).

* **Type:** number
* How many splats the capture holds. Size a dispatch from this, and guard on it in the kernel: a thread that runs past the end writes into memory the renderer is using.

### opacity

Documentation source: [Splat](https://scenery.app/docs/scripting/api/splat.md).

* **Type:** [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute)
* Opacity of each splat, 1 float per splat, stored pre-sigmoid so 0 is half opaque rather than invisible. Fade the alpha and convert back rather than interpolating the stored value.

### position

Documentation source: [Splat](https://scenery.app/docs/scripting/api/splat.md).

* **Type:** [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute)
* Centre of each splat, 3 floats per splat, read in a kernel as `packed_float3`.

### rotation

Documentation source: [Splat](https://scenery.app/docs/scripting/api/splat.md).

* **Type:** [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute)
* Orientation of each splat as a quaternion, 4 floats per splat, stored **w first** as `(w, x, y, z)`. Identity is `(1, 0, 0, 0)`; an `xyzw` identity is a half turn.

### scale

Documentation source: [Splat](https://scenery.app/docs/scripting/api/splat.md).

* **Type:** [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute)
* Per-axis size of each splat, 3 floats per splat, in log space and read in a kernel as `packed_float3`. Halving a splat means subtracting `log(2)`, not multiplying by 0.5.

### sphericalHarmonicDegree

Documentation source: [Splat](https://scenery.app/docs/scripting/api/splat.md).

* **Type:** number
* Spherical harmonic degree of the capture, 0 through 3.

### sphericalHarmonics

Documentation source: [Splat](https://scenery.app/docs/scripting/api/splat.md).

* **Type:** [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute)
* View-dependent colour: the DC triplet first, then one triplet per higher-order coefficient, so `itemSize` is `3 * (bands + 1)` and a splat's base colour is the first three floats of its block. Read in a kernel as `float`, indexed by that stride.

---

Source page: SplatAttribute

Source URL: https://scenery.app/docs/scripting/api/splatattribute.md

# SplatAttribute

Documentation source: [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute.md).

One attribute's GPU buffer, as a pair of kernel bindings.

## Properties

Documentation source: [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute.md).

### itemSize

Documentation source: [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute.md).

* **Type:** number
* Floats per splat. Buffer length is `splat.count * itemSize`, which is what a kernel's bounds guard and thread count are sized from. Named after three.js `BufferAttribute`.

### read

Documentation source: [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute.md).

* **Type:** [EngineBufferBinding](https://scenery.app/docs/scripting/api/enginebufferbinding)
* Token tagged as "read into kernel". Returns the contents as the renderer last saw them.

### write

Documentation source: [SplatAttribute](https://scenery.app/docs/scripting/api/splatattribute.md).

* **Type:** [EngineBufferBinding](https://scenery.app/docs/scripting/api/enginebufferbinding)
* Token tagged as "write from kernel". The buffer arrives uninitialised, so the kernel has to write every element it is dispatched over. Written values then persist with no further dispatches, so a one-shot effect can stop when it finishes.

---

Source page: InstanceData

Source URL: https://scenery.app/docs/scripting/api/instancedata.md

# InstanceData

Documentation source: [InstanceData](https://scenery.app/docs/scripting/api/instancedata.md).

The GPU buffer behind an entity's mesh instances, for handing to a compute kernel.

Reached via `entity.instances` once `setInstances(...)` has run; `null` before that, or where instancing is unavailable. Vends `.read` and `.write` tokens exactly as a splat attribute does, so a kernel can move thousands of instances per frame without rebuilding the transform list in JavaScript.

* Warning: a `.write` token hands the kernel an **uninitialised** buffer, not last frame's   contents. Whatever the kernel does not write is undefined. To move part of the set, bind   `.read` as an input in the same dispatch and copy the rest across.

* Note: the bounds `setInstances(...)` computed do not follow a kernel that moves instances   outside them. Instances beyond the original extent are culled and lose shadows.

**Example:**

```javascript
entity.setInstances(Instances.transforms(spots));
const instances = entity.instances;
const THREADS = 64;
kernel.run({
    uniforms: new Float32Array([scene.time, instances.count]),
    inputBuffers:  { src: instances.read },
    outputBuffers: { dst: instances.write },
    threadGroups: [Math.ceil(instances.count / THREADS), 1, 1],
    threadsPerThreadgroup: [THREADS, 1, 1]
});
```

## Properties

Documentation source: [InstanceData](https://scenery.app/docs/scripting/api/instancedata.md).

### count

Documentation source: [InstanceData](https://scenery.app/docs/scripting/api/instancedata.md).

* **Type:** number
* How many instances the entity draws. Size a dispatch from this, and guard on it in the kernel: a thread past the end writes into memory the renderer is using.

### localToMesh

Documentation source: [InstanceData](https://scenery.app/docs/scripting/api/instancedata.md).

* **Type:** Array\<any>
* Converts a distance or position from metres into the buffer's units. Multiply an offset in metres by its scale, element 0, before adding it to an instance's translation. The inverse of `meshToLocal`, same 16-number column-major layout.

### meshToLocal

Documentation source: [InstanceData](https://scenery.app/docs/scripting/api/instancedata.md).

* **Type:** Array\<any>
* Converts a distance or position from the buffer's units into metres, as 16 numbers in column-major order, ready to hand a kernel as uniforms. Its scale, element 0, is the conversion factor on its own.

### read

Documentation source: [InstanceData](https://scenery.app/docs/scripting/api/instancedata.md).

* **Type:** [EngineBufferBinding](https://scenery.app/docs/scripting/api/enginebufferbinding)
* Token tagged as "read into kernel". Returns the transforms as the renderer last saw them.

### write

Documentation source: [InstanceData](https://scenery.app/docs/scripting/api/instancedata.md).

* **Type:** [EngineBufferBinding](https://scenery.app/docs/scripting/api/enginebufferbinding)
* Token tagged as "write from kernel". The buffer arrives uninitialised, so the kernel has to write every element it is dispatched over. One `float4x4` per instance, column-major, so column 3 is the translation, in the instanced mesh's own space rather than the space `rep.setInstances(...)` accepts.

---

Source page: Light

Source URL: https://scenery.app/docs/scripting/api/light.md

# Light

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

A light in the running scene.

Reached via `entity.representation.light` on a light representation, whether the author placed it or a script created it with `createSpotLight(...)`, `createPointLight(...)` or `createDirectionalLight(...)`. Returns `null` for any other representation kind.

Writes are runtime state: they change the running scene, not the saved experience. A property that belongs to another light type reads as 0 and warns when written.

## Properties

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

### attenuationRadius

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

* **Type:** number
* The distance in metres at which the light's contribution reaches zero. Spot and point only – a directional light shines from infinitely far away.

### color

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

* **Type:** [Color](https://scenery.app/docs/scripting/api/color)
* The colour the light emits. White leaves surfaces their own colour.

### falloffExponent

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

* **Type:** number
* How quickly the light fades with distance. 2 is physically correct; lower carries further. Spot and point only.

### innerAngle

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

* **Type:** number
* The cone that receives the light's full intensity, in degrees. Spot only; reading it on another type returns 0 and writing is ignored with a warning. Clamped to the outer angle, which is what the renderer requires.

### intensity

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

* **Type:** number
* Brightness. Lumens for a spot or point light, lux for a directional one, so the same number means different things across the three.

### outerAngle

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

* **Type:** number
* The cone at which the light has fallen to nothing, in degrees. Between the two angles it fades. Spot only.

### projectedTextureOffset

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

* **Type:** [Vector2](https://scenery.app/docs/scripting/api/vector2)
* Shifts the projected texture within the cone. Spot only, and only where `environment.features.has('projectedLightTexture')` is true.

### projectedTextureRotation

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

* **Type:** number
* Rotation of the projected texture within the cone, in radians. Spot only, and only where `environment.features.has('projectedLightTexture')` is true.

### projectedTextureScale

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

* **Type:** [Vector2](https://scenery.app/docs/scripting/api/vector2)
* Tiles the projected texture within the cone, `1, 1` being the authored size. Spot only, and only where `environment.features.has('projectedLightTexture')` is true.

### type

Documentation source: [Light](https://scenery.app/docs/scripting/api/light.md).

* **Type:** string
* Which light this is: `"spot"`, `"point"` or `"directional"`. Read-only – the three types take different parameters, so switching one for another is creating a different light.

---

Source page: Anchor

Source URL: https://scenery.app/docs/scripting/api/anchor.md

# Anchor

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

Anchor types for object placement

## Static Methods

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

### position()

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

```javascript
Anchor.position(xOrVector: Vector3 | number, y?: number, z?: number): Object
```

Anchor at fixed world position

**Parameters:**

* `xOrVector` ([Vector3](https://scenery.app/docs/scripting/api/vector3) | number) - Position vector or X coordinate
* `y` (number) *(optional)* - Y coordinate (if first param is number)
* `z` (number) *(optional)* - Z coordinate (if first param is number)

**Returns:** Object

### geoLocation()

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

```javascript
Anchor.geoLocation(latitude: number, longitude: number, altitude?: number): void
```

Anchor at geographic location

**Parameters:**

* `latitude` (number)
* `longitude` (number)
* `altitude` (number) *(optional)*

**Returns:** void

### camera()

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

```javascript
Anchor.camera(xOrVector: Vector3 | number, y?: number, z?: number, lerpFactor?: number): void
```

Anchor relative to camera

**Parameters:**

* `xOrVector` ([Vector3](https://scenery.app/docs/scripting/api/vector3) | number) - Offset vector or X coordinate
* `y` (number) *(optional)* - Y coordinate (if first param is number)
* `z` (number) *(optional)* - Z coordinate (if first param is number)
* `lerpFactor` (number) *(optional)* - Smoothing factor

**Returns:** void

### currentPOV()

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

```javascript
Anchor.currentPOV(xOrVector?: Vector3 | number, y?: number, z?: number, resetRotation?: boolean): Object
```

Anchor at user's current point of view (captures current camera position)

**Parameters:**

* `xOrVector` ([Vector3](https://scenery.app/docs/scripting/api/vector3) | number) *(optional)* - Offset vector or X coordinate
* `y` (number) *(optional)* - Y coordinate (if first param is number)
* `z` (number) *(optional)* - Z coordinate (if first param is number)
* `resetRotation` (boolean) *(optional)* - If true, object faces forward instead of matching camera

**Returns:** Object

### screenSpace()

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

```javascript
Anchor.screenSpace(options?: Object): Object
```

Anchor a UI panel in screen space – a flat 2D overlay pinned to a screen edge or corner, rather than a plane placed in the world. Use for HUDs and controls that should stay put wherever the viewer looks.

**Example:**

```javascript
// A slider pinned to the bottom of the screen, 24 pt clear of the edge.
createPanel(
    UI.slider({ name: 'amount', sizing: { width: 'fill' } }),
    { panelSize: 'auto' }
).anchor(Anchor.screenSpace({ alignment: 'bottom', insets: 24 }));
```

**Parameters:**

* `options` (Object) *(optional)*
* `options.alignment` (string) *(optional)* - Where the panel sits:
  `"center"`, `"top"`, `"bottom"`, `"leading"`, `"trailing"`, or a corner
  (`"topLeading"`, `"topTrailing"`, `"bottomLeading"`, `"bottomTrailing"`).
* `options.insets` (number | Object) *(optional)* - Gap from the screen edges, in points.
  A number applies to all sides; `{ top, leading, bottom, trailing }` sets each.
* `options.respectsSafeArea` (boolean) *(optional)* - Stay clear of notches,
  home indicators, and system bars.

**Returns:** Object

### horizontalPlane()

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

```javascript
Anchor.horizontalPlane(classification?: string, minWidth?: number, minHeight?: number): Object
```

Anchor on detected horizontal plane (floor, table, etc.)

**Parameters:**

* `classification` (string) *(optional)* - Surface type: "floor", "table", "seat", "ceiling"
* `minWidth` (number) *(optional)* - Minimum plane width in meters
* `minHeight` (number) *(optional)* - Minimum plane depth in meters

**Returns:** Object

### verticalPlane()

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

```javascript
Anchor.verticalPlane(classification?: string, minWidth?: number, minHeight?: number): void
```

Anchor on vertical plane

**Parameters:**

* `classification` (string) *(optional)* - "wall", "window", "door"
* `minWidth` (number) *(optional)*
* `minHeight` (number) *(optional)*

**Returns:** void

### hand()

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

```javascript
Anchor.hand(chirality: string, joint?: string, trackingScope?: string, lerpFactor?: number, providesDiscoveryHint?: boolean): Object
```

Anchor to user's hand (visionOS hand tracking)

**Parameters:**

* `chirality` (string) - "left" or "right" hand
* `joint` (string) *(optional)* - Hand joint: "wrist", "thumbTip", "indexFingerTip", "middleFingerTip", etc.
* `trackingScope` (string) *(optional)* - "full", "position", or "orientation"
* `lerpFactor` (number) *(optional)* - Smoothing factor (0-1, lower = smoother)
* `providesDiscoveryHint` (boolean) *(optional)* - Show visual hint for hand tracking

**Returns:** Object

### image()

Documentation source: [Anchor](https://scenery.app/docs/scripting/api/anchor.md).

```javascript
Anchor.image(imageUrl: string, physicalWidth: number, identifier?: string, orientation?: string, tracksContinuously?: boolean, hideIfTrackingLost?: boolean, providesDiscoveryHint?: boolean): Object
```

Anchor to image marker (image tracking)

**Parameters:**

* `imageUrl` (string) - URL to reference image for tracking
* `physicalWidth` (number) - Real-world width of the image in meters
* `identifier` (string) *(optional)* - Optional unique identifier
* `orientation` (string) *(optional)* - Expected orientation: "horizontal" or "vertical"
* `tracksContinuously` (boolean) *(optional)* - Continue tracking after initial detection
* `hideIfTrackingLost` (boolean) *(optional)* - Hide object when image not visible
* `providesDiscoveryHint` (boolean) *(optional)* - Show visual hint to find image

**Returns:** Object

---

Source page: ObjectTraits

Source URL: https://scenery.app/docs/scripting/api/objecttraits.md

# ObjectTraits

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

Builder object passed to the compatibility-only `.traits(t => …)` callback. New code should skip this entirely and use the direct descriptor methods (`.physics(…)`, `.material(…)`, `.shadow(…)`, `.gestures(…)`, `.transform(…)`, `.opacity(…)`, `.fittingBox(…)`, `.pivot(…)`, `.revealAnimation(…)`, `.removalAnimation(…)`, `.hideByDefault(…)`, `.flatten(…)`), which expose the same configuration and chain.

## Instance Methods

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

### transform()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
transform(transform: Transform): ObjectTraits
```

Set initial transform

**Parameters:**

* `transform` ([Transform](https://scenery.app/docs/scripting/api/transform)) - Transform object

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### fittingBox()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
fittingBox(size: number): ObjectTraits
```

Scale model to fit within a cubic bounding box

**Parameters:**

* `size` (number) - Maximum dimension in meters (model will fit inside this cube)

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### pivot()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
pivot(pivot: string): ObjectTraits
```

Set pivot adjustment

**Parameters:**

* `pivot` (string) - which face of the model sits at its origin: "automatic", "top",
  "center", "bottom", "left", "right", "front", or "back". "back" seats a model flat against
  a wall the way "bottom" stands one on a floor.

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### revealAnimation()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
revealAnimation(animation: Object | string | boolean): ObjectTraits
```

Choose how the object animates in when it appears.

Mirrors the editor's Reveal Animation picker, so a script-created object can look like an authored one. Omit it and the object uses the app default, the same as the picker's "Default".

**Example:**

```javascript
// A script that owns the reveal itself: no built-in animation to play over it.
createSplat(assetId).revealAnimation(false);
```

**Parameters:**

* `animation` (Object | string | boolean) - A style name, an options object, or `false`
  for no animation at all (`true` restores the app default).
* `animation.style` (string) - `"default"` (the app's own reveal), `"disabled"` (appear
  instantly), `"fade"`, or `"fadeAndScale"` (fades in while growing from `scaleFactor`).
* `animation.duration` (number) *(optional)* - Seconds, for `"fade"` and `"fadeAndScale"`.
* `animation.scaleFactor` (number) *(optional)* - The fraction of full size the object grows
  from, for `"fadeAndScale"`.

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### removalAnimation()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
removalAnimation(animation: Object | string | boolean): ObjectTraits
```

Choose how the object animates out when it is removed. Same options as {@link ObjectTraits#revealAnimation}, and mirrors the editor's Removal Animation picker.

**Parameters:**

* `animation` (Object | string | boolean)

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### hideByDefault()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
hideByDefault(hidden?: boolean): ObjectTraits
```

Hide the object when it is first added to the scene, so a script can prepare it before anyone sees it. Mirrors the editor's Hide By Default toggle.

The object still loads: its representation is built and its physics body precomputed, it is simply not shown and its physics stays paused. Bring it up with `scene.toggle([entity], true)`, which reveals a batch on a single frame.

**Example:**

```javascript
// Create it hidden, write the state it should appear in, then bring it up.
var capture = await scene.createEntity(createSplat(assetId).hideByDefault());
await capture.waitUntilReady();
await scene.toggle([capture], true);
```

**Parameters:**

* `hidden` (boolean) *(optional)* - `true` to start hidden, `false` for the normal behaviour.

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### flatten()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
flatten(flatten?: boolean): ObjectTraits
```

Load a model as one mesh instead of its authored node tree. Mirrors the editor's Flatten toggle. Models only.

`setInstances` needs it, since instancing works on a single mesh. The cost is the hierarchy: once flattened, `findChild`, `getChildNames` and per-node material targeting have no nodes to work with.

**Example:**

```javascript
createModel(assetId).flatten().fittingBox(0.2);
```

**Parameters:**

* `flatten` (boolean) *(optional)* - `true` to collapse the model, `false` to keep its nodes.

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### opacity()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
opacity(opacity: number): ObjectTraits
```

Set opacity adjustment

**Parameters:**

* `opacity` (number) - Opacity value (0.0 to 1.0)

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### shadow()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
shadow(options: Object): ObjectTraits
```

Configure how this object interacts with the scene's two shadow systems. Mirrors `t.physics({…})` / `t.gestures({…})`: pass only the keys you want to change.

**Example:**

```javascript
// A dense instanced field: skip the directional shadow it can't render cleanly.
createBox(0.03, 0.03, 0.03).shadow({ directional: false });
```

**Parameters:**

* `options` (Object)
* `options.directional` (boolean) *(optional)* - Cast a shadow from the scene's directional light
  (the main projected shadow). Set `false` where it isn't wanted – e.g. a dense instanced field,
  whose many small copies alias the shared shadow map into streaks.
* `options.grounding` (boolean | Object) *(optional)* - The soft AR contact shadow beneath the
  object. `true` to cast it, or an object to configure:
  `{ casts?: boolean, receives?: boolean, fadeNearObjects?: boolean }` – `receives` takes
  grounding shadows cast by other objects; `fadeNearObjects` fades the shadow as it approaches
  detected physical surfaces (otherwise constant).

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### material()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
material(materialOrId: string | Material, target?: Object): ObjectTraits
```

Apply a material – either a library reference by ID or an inline Material instance.

**Parameters:**

* `materialOrId` (string | [Material](https://scenery.app/docs/scripting/api/material)) - Library material ID, or a Material instance.
* `target` (Object) *(optional)* - Optional target override.
* `target.type` (string) *(optional)* - "allModels", "firstModel", or "selectedModels"
* `target.models` (Array) *(optional)* - Array of model names (for selectedModels)
* `target.materialSlots` (Array\<number>) *(optional)* - Material slot indices

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### physics()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
physics(options: Object): ObjectTraits
```

Give the object a physics body so it can collide, fall, and be pushed.

Mirrors the editor's Physics inspector, so anything set here stays visible and editable there. Sub-groups are written only when you supply at least one of their keys – `t.physics({ mode: 'static' })` produces a plain static body with no mass, damping, or material overrides.

Physics also needs scene-level setup: enable the floor mesh and scene mesh collisions in the scene's settings, or bodies will fall forever.

**Example:**

```javascript
// A ball you can throw.
createSphere(0.05).physics({
    mode: 'dynamic', shape: 'sphere', mass: 0.15, restitution: 0.4
});
```

**Parameters:**

* `options` (Object)
* `options.mode` (string) - `"static"` (never moves, others collide with it),
  `"dynamic"` (gravity, impulses, collisions), or `"kinematic"` (you move it;
  it pushes others but isn't pushed).
* `options.shape` (string) *(optional)* - Collision shape: `"box"`, `"sphere"`, or
  `"convex"` (hull of the object's geometry).
* `options.mass` (number) *(optional)* - Mass in kilograms. Omit for the default.
* `options.gravity` (boolean) *(optional)* - Whether the body reacts to gravity.
* `options.linearDamping` (number) *(optional)* - How quickly movement slows on its own, like drag.
* `options.angularDamping` (number) *(optional)* - How quickly spin slows on its own.
* `options.friction` (number) *(optional)* - Resistance to sliding.
* `options.restitution` (number) *(optional)* - Bounciness. `0` lands with a thud.
* `options.translationLock` (Object) *(optional)* - `{ x, y, z }` booleans constraining movement.
* `options.rotationLock` (Object) *(optional)* - `{ x, y, z }` booleans constraining rotation.

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### gestures()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
gestures(options: Object): ObjectTraits
```

Let the user move, rotate or resize this object with a gesture, and choose what happens when they let go.

Omit a gesture to leave it disabled – an object with no gestures configured cannot be manipulated at all.

**Example:**

```javascript
// A ball you can pick up and throw. Trait methods chain directly on the descriptor.
createSphere(0.06)
    .physics({ mode: 'dynamic', shape: 'sphere', mass: 0.2 })
    .gestures({ drag: true, releaseBehavior: 'momentum', momentumScale: 0.6 });
```

**Parameters:**

* `options` (Object) - Gesture configuration.
* `options.drag` (Object | boolean) *(optional)* - Drag/move the object. `true` enables it on all axes,
  or pass `{ axes: { x, y, z } }` to restrict which axes it may move along.
* `options.rotate` (Object | boolean) *(optional)* - Rotate the object. `true` enables it on all axes,
  or pass `{ axes: { x, y, z } }`.
* `options.resize` (Object | boolean) *(optional)* - Scale the object. `true` enables it on all axes, or
  pass `{ axes: { x, y, z }, minScale, maxScale }`.
* `options.releaseBehavior` (string) *(optional)* - What the object does when released:
  * `'stay'` – stays where it was let go, then falls under gravity if it has a dynamic body.
  * `'reset'` – animates back to where the gesture started.
  * `'momentum'` – keeps the motion the gesture gave it. A flick throws it; a slow release
    lets it drift. Requires a dynamic physics body.
* `options.momentumScale` (number) *(optional)* - Scales the released linear velocity when
  `releaseBehavior` is `'momentum'`. `1.0` is the object's true world-space speed, which
  usually feels too fast on a touchscreen – a finger flick maps to a large velocity once
  projected out to the object's distance. Lower it for a gentler toss.
* `options.angularMomentumScale` (number) *(optional)* - Scales the released spin. Kept below the
  linear scale because gesture-derived spin is noisy and tumbles heavily at full strength.
* `options.disableAudio` (boolean) *(optional)* - Suppress the built-in interaction sound.

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### set()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
set(path: string, value: any): ObjectTraits
```

Directly set a property path in traits

**Parameters:**

* `path` (string) - Dot-separated path (e.g., "modelAdjustments.flatten")
* `value` (any) - Value to set

**Returns:** [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits)

### build()

Documentation source: [ObjectTraits](https://scenery.app/docs/scripting/api/objecttraits.md).

```javascript
build(): Object
```

Build and return the traits object

**Returns:** Object

---

Source page: ObjectDescriptor

Source URL: https://scenery.app/docs/scripting/api/objectdescriptor.md

# ObjectDescriptor

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

Descriptor for creating scene objects dynamically

## Properties

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

### id read-only

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

* **Type:** string
* The object's id. Read-only – set at construction (or preserved by `scene.getObjectDescriptor`, re-minted by `.clone()`). Use it to look the object up later, e.g. `scene.findEntity(descriptor.id)` after `scene.createEntity(descriptor)`.

### kind read-only

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

* **Type:** string | null
* The object's representation kind: `'model'` | `'primitive'` | `'visualMedia'` | … , or `null` if the object has no representation. Read-only. Lets a script branch on what it fetched before editing – e.g. `if (d.kind === 'model') d.asset(hi)`.

## Instance Methods

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

### name()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
name(value: string): ObjectDescriptor
```

Set the object name

**Parameters:**

* `value` (string)

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### anchor()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
anchor(anchor: Object): ObjectDescriptor
```

Set the anchor

**Parameters:**

* `anchor` (Object) - Anchor descriptor created by Anchor static methods

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### asset()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
asset(urlOrId: string): ObjectDescriptor
```

Set / replace the object's **source asset**, kind-routed to the right field (`model` → the model asset, image / video / GIF → the media source). Same-kind swap only – it does **not** change the object's kind: pointing a model at a video URL gives a broken model, not a video (use `.representation(...)` to change kind). Warns for kinds with no source (primitive, container). Accepts an HTTPS URL or an asset id from the project.

**Parameters:**

* `urlOrId` (string)

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### representation()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
representation(sourceDescriptor: ObjectDescriptor): ObjectDescriptor
```

Fully replace this object's visual **representation** with the one from a freshly built descriptor (`createBox`, `createModel`, `createVideo`, …) – the clean way to change kind (model → primitive, model → video). Keeps this object's identity and wiring: its id, representation id, anchor (placement), and events. Takes the source's `kind` **and its traits** – configure the new look via the factory chain, e.g. `d.representation(createBox(0.1,0.1,0.1).gestures({ drag: true }))`.

Note: the authored **transform trait** rides inside the old kind and is dropped by the swap ("keeps placement" means the anchor, not the transform) – re-apply via the source chain if needed. Element-level fields on the source (`.name()`, `.anchor()`, events) are ignored; only its representation is taken.

**Parameters:**

* `sourceDescriptor` ([ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor))

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### clone()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
clone(): ObjectDescriptor
```

Deep-copy this descriptor with a **fresh id graph** (element id + every nested representation id + events), so it can be added alongside the original without an id collision. Use it to spawn variants of an authored object: `scene.getObjectDescriptor({ name: 'can' }).clone().transform({ position: p })`, then `scene.createEntity(...)`. The copy inherits the original's events (re-wired to the copy); clear them with `copy.data.events = []` if unwanted.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### traits() deprecated

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

::: warning Deprecated
Prefer the direct trait methods on the descriptor – `.physics(…)`, `.material(…)`, `.gestures(…)`, `.shadow(…)`, `.transform(…)`, `.opacity(…)`, `.fittingBox(…)`, `.pivot(…)`, `.revealAnimation(…)`, `.removalAnimation(…)`, `.hideByDefault(…)`, `.flatten(…)`. They read the same, chain, and are the supported form going forward. `.traits(fn)` is kept only for compatibility with existing scripts and will be removed in a future runtime version.
:::

```javascript
traits(configureFn: function): ObjectDescriptor
```

Configure traits via a callback. Traits already on the descriptor (e.g. from `createMesh({ materials: [...] })`) are preserved – calls add on top.

**Parameters:**

* `configureFn` (function) - Function that receives an ObjectTraits builder.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### physics()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
physics(options: Object): ObjectDescriptor
```

Give this object a physics body. See {@link ObjectTraits#physics} for the full options.

**Parameters:**

* `options` (Object) - `{ mode, shape, mass, friction, restitution, … }`.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### gestures()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
gestures(options: Object): ObjectDescriptor
```

Enable manipulation gestures (drag / rotate / resize). See {@link ObjectTraits#gestures}.

**Parameters:**

* `options` (Object) - `{ drag, rotate, resize, releaseBehavior, … }`.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### material()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
material(materialOrId: string | Material, target?: Object): ObjectDescriptor
```

Apply a material – a library id or an inline `Material`. See {@link ObjectTraits#material}.

**Parameters:**

* `materialOrId` (string | [Material](https://scenery.app/docs/scripting/api/material))
* `target` (Object) *(optional)* - Optional model / slot target.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### shadow()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
shadow(options: Object): ObjectDescriptor
```

Configure the object's shadows (directional + grounding). See {@link ObjectTraits#shadow}.

**Parameters:**

* `options` (Object) - `{ directional, grounding }`.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### transform()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
transform(transform: Object): ObjectDescriptor
```

Set the object's transform (position / rotation / scale). See {@link ObjectTraits#transform}.

**Parameters:**

* `transform` (Object)

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### opacity()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
opacity(opacity: number): ObjectDescriptor
```

Set the object's opacity (0–1). See {@link ObjectTraits#opacity}.

**Parameters:**

* `opacity` (number)

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### fittingBox()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
fittingBox(size: number): ObjectDescriptor
```

Scale a model to fit a box of the given size. See {@link ObjectTraits#fittingBox}.

**Parameters:**

* `size` (number)

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### pivot()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
pivot(pivot: string): ObjectDescriptor
```

Adjust the model's pivot. See {@link ObjectTraits#pivot}.

**Parameters:**

* `pivot` (string)

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### revealAnimation()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
revealAnimation(animation: Object | string | boolean): ObjectDescriptor
```

Choose how this object animates in when it appears. See {@link ObjectTraits#revealAnimation}.

**Parameters:**

* `animation` (Object | string | boolean) - A style name, `{ style, duration, scaleFactor }`,
  or `false` for no animation.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### removalAnimation()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
removalAnimation(animation: Object | string | boolean): ObjectDescriptor
```

Choose how this object animates out when it is removed. See {@link ObjectTraits#removalAnimation}.

**Parameters:**

* `animation` (Object | string | boolean)

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### hideByDefault()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
hideByDefault(hidden?: boolean): ObjectDescriptor
```

Start this object hidden, to be brought up with `scene.toggle`. See {@link ObjectTraits#hideByDefault}.

**Parameters:**

* `hidden` (boolean) *(optional)*

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

### flatten()

Documentation source: [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor.md).

```javascript
flatten(flatten?: boolean): ObjectDescriptor
```

Load this model as one mesh rather than its node tree. See {@link ObjectTraits#flatten}.

**Parameters:**

* `flatten` (boolean) *(optional)*

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

---

Source page: Material

Source URL: https://scenery.app/docs/scripting/api/material.md

# Material

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

Chainable builder for an inline material. Six kinds: `unlit`, `pbr`, `occlusion`, `customShader`, `materialX`, `video`. Use the matching factory (`Material.unlit({...})`, etc.) or `new Material(kind)`.

Properties map to the underlying material data model with web-standard names: - Colors: `color`, `emissive`, `sheenColor`, `specularColor` – flat tint. - Maps: `map`, `emissiveMap`, `roughnessMap`, `metalnessMap`, `normalMap`, `aoMap`, `specularMap`, `sheenMap`, `clearcoatMap`, `alphaMap` – textures accept either a URL/asset-id string or `{ texture, scale }`. - Scalars: `roughness`, `metalness`, `clearcoat`, `opacity`, `emissiveIntensity`. - Rendering: `opaque`, `transparent`, `opacityThreshold`, `blendMode`, `faceCulling`, `wireframe`, `writesDepth`, `readsDepth`.

## Static Methods

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

### unlit()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
Material.unlit(opts?: Object): Material
```

Flat-shaded material. Renders the surface color regardless of scene lighting – useful for UI, billboards, vertex-colored point clouds, etc.

**Parameters:**

* `opts` (Object) *(optional)* - Any chainable setter name as a key:
  `color`, `map`, `opacity`, `alphaMap`, `disableToneMapping`,
  `faceCulling`, `blendMode`, `wireframe`, `target`, `name`.

**Returns:** [Material](https://scenery.app/docs/scripting/api/material)

### pbr()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
Material.pbr(opts?: Object): Material
```

Physically-Based material – the realistic-rendering default for surfaces that should respond to scene lighting.

**Parameters:**

* `opts` (Object) *(optional)* - `color`, `map`, `emissive`, `emissiveMap`,
  `emissiveIntensity`, `metalness`, `metalnessMap`, `roughness`,
  `roughnessMap`, `normalMap`, `aoMap`, `sheenColor`, `sheenMap`,
  `specularColor`, `specularMap`, `clearcoat`, `clearcoatMap`,
  `opacity`, `alphaMap`, `opacityThreshold`, plus rendering state.

**Returns:** [Material](https://scenery.app/docs/scripting/api/material)

### occlusion()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
Material.occlusion(opts?: Object): Material
```

Occlusion material – invisible itself but hides geometry behind it. Use for matte holdouts, real-world geometry masks, portals.

**Parameters:**

* `opts` (Object) *(optional)* - `receivesDynamicLighting`, `faceCulling`.

**Returns:** [Material](https://scenery.app/docs/scripting/api/material)

### customShader()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
Material.customShader(opts?: Object): Material
```

Custom shader material – author-supplied surface shader and/or geometry modifier from a compiled shader library.

**Parameters:**

* `opts` (Object) *(optional)* - `shaderLibrary`, `lightingModel`,
  `surfaceShader`, `geometryModifier`, plus general rendering state.

**Returns:** [Material](https://scenery.app/docs/scripting/api/material)

### materialX()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
Material.materialX(opts?: Object): Material
```

ShaderGraph material from a bundled `.usdz`. Reference by file path plus the `/Root/<MaterialName>` path inside.

**Parameters:**

* `opts` (Object) *(optional)* - Typically use `.materialXAsset(urlOrId, name)`
  followed by `.setParameter(name, value, typeHint?)` calls.

**Returns:** [Material](https://scenery.app/docs/scripting/api/material)

### video()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
Material.video(): Material
```

Video texture material. Use `.videoSource(urlOrId)` for the playback source and `.videoOptions({ loops, streamContent, volume })` for playback config.

**Returns:** [Material](https://scenery.app/docs/scripting/api/material)

## Instance Methods

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

### opacity()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
opacity(): void
```

Material opacity. Values < 1 also flip `isOpaque` to `false` so the blending state matches.

**Returns:** void

### materialXAsset()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
materialXAsset(): void
```

MaterialX (ShaderGraph): URL or asset id of the .usdz, plus the path to the material inside it (e.g. `"/Root/MyMaterial"`).

**Returns:** void

### setParameter()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
setParameter(name: string, value: any, typeHint?: Object): Material
```

Set a constant value on a shader parameter. Works on `customShader` and `materialX` kinds – routes to the right options blob automatically. Warns and no-ops on kinds without shader parameters.

For runtime variable bindings, use `entity.representation.bindMaterialParameter(name, variableId, opts?)`.

**Example:**

```javascript
Material.materialX().materialXAsset('myAsset', '/Root/MyMat')
    .setParameter('intensity', 0.6)
    .setParameter('tintColor', '#FF00FF', { type: 'color' });
```

**Parameters:**

* `name` (string) - Material parameter name (case-sensitive, must match
  the name the material exposes).
* `value` (any) - Number, boolean, string, array (vec2/3/4), or
  color-like object (`'#RRGGBB'`, `{r,g,b,a?}`, `{colorSpace,hex}`).
* `typeHint` (Object) *(optional)* - Override inferred type:
  `{ type: "float" | "int" | "vector2" | "vector3" | "vector4" | "color" | "boolean" | "string" }`.

**Returns:** [Material](https://scenery.app/docs/scripting/api/material)

### clone()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
clone(): void
```

Deep-copy the material with a fresh `id`. Use for the get → clone → tweak → apply pattern when overriding a library material for a single entity without mutating the library entry.

**Returns:** void

### toString()

Documentation source: [Material](https://scenery.app/docs/scripting/api/material.md).

```javascript
toString(): void
```

Useful per-kind summary for `console.log(mat)` – includes kind, id, name, and the meaningful state set on the material (channel colors, scalar values, shader params, etc.) so authors can see "what's on this material" at a glance. For the full serialized shape, use `JSON.stringify(mat, null, 2)`.

**Returns:** void

---

Source page: Mesh beta

Source URL: https://scenery.app/docs/scripting/api/mesh.md

# Mesh beta

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

Scriptable dynamic mesh with CPU-driven vertex and index updates.

Reached via `entity.representation.mesh` on representations created with `createMesh(...)`. Returns `null` for any other representation kind.

Write methods (`writeVertices`, `writeIndices`) are designed to run every frame: each call issues a single `memcpy` from the JS TypedArray's backing buffer directly into the mesh's GPU-backed storage, with no intermediate copies. Combine with `setBounds` / `drawCount` (single-part shorthand) or `updatePart` (multi-part) to publish the new draw range each tick.

## Properties

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

### attributes

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

* **Type:** any
* Read-only summary of the mesh's attribute layout: an object keyed by attribute name with `{ semantic, format, storage }` fields. Useful for introspection ("does this mesh have a 'speed' attribute?") and for cross-engine devs who reach for `geometry.attributes` reflexively.

### drawCount

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

* **Type:** number
* Convenience getter/setter for single-part meshes.

### indexCapacity

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

* **Type:** number
* Maximum index count the mesh was allocated for.

### partCount

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

* **Type:** number
* Number of parts (draw ranges) on the mesh.

### vertexCapacity

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

* **Type:** number
* Maximum vertex count the mesh was allocated for. Read-only – the underlying buffer is sized at creation. To grow, create a new mesh.

## Methods

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

### recomputeBounds()

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

```javascript
recomputeBounds(partIndex: number): BoundingBox | null
```

Recompute and apply min/max bounds for a part from its written vertex positions.

Walks the `position` attribute, writes the computed `BoundingBox` back onto the part, and returns it so callers can inspect the result.

Expensive on large meshes – walks `partVertexCount × 3` floats. Most authors should track running bounds incrementally in their own per-frame loop (cheap) and only call `recomputeBounds()` during prototyping or on a sparse cadence. Returns `null` if the mesh has no `position` attribute or `partIndex` is out of range.

**Example:**

```javascript
mesh.writeVertices("position", 0, scratch);
mesh.recomputeBounds(0);  // updates part 0's bounds to fit the written verts
```

**Parameters:**

* `partIndex` (number) - Zero-based index of the part to recompute.

**Returns:** [BoundingBox](https://scenery.app/docs/scripting/api/boundingbox) | null

### replaceParts()

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

```javascript
replaceParts(parts: Array<{ indexCount: number, indexOffset?: number, topology?: string, materialIndex?: number, bounds: BoundingBox | { min: number[3], max: number[3] } }>): void
```

Replace the entire parts list. Use for dynamic-part-count meshes where each frame's GPU dispatch produces a variable triangle count (marching cubes, fluid surface, voxel terrain). Pair with an atomic counter in `outputBuffers` to size the part:

`updatePart(...)` mutates one part in-place; `replaceParts(...)` swaps the entire list. The latter is the right choice when the part count itself changes between frames.

**Example:**

```javascript
const [emitted] = triCounter.readSync();
mesh.replaceParts([{
    indexCount: emitted * 3,
    topology: 'triangle',
    bounds: { min: [-1, -1, -1], max: [1, 1, 1] }
}]);
```

**Parameters:**

* `parts` (Array<{ indexCount: number, indexOffset?: number, topology?: string, materialIndex?: number, bounds: BoundingBox | { min: number\[3], max: number\[3] } }>)

**Returns:** void

### runCompute()

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

```javascript
runCompute(kernel: Kernel, options: { uniforms?: Float32Array, outputs?: string[], outputIndices?: boolean, inputBuffers?: object, outputBuffers?: object, inputTextures?: object, outputTextures?: object, threadGroups: number[3], threadsPerThreadgroup?: number[3] }): void
```

Dispatch a compute kernel against this mesh's `storage: compute` attribute buffers, optionally the index buffer, plus arbitrary input / output buffers and textures. The renderer waits on the dispatch's command buffer before sampling the mesh.

Check `environment.features.has('compute')` before calling – returns `false` on devices without GPU compute support.

**MSL slot order is deterministic:** `buffer(0)` uniforms → `buffer(1..)` outputs (mesh attributes) → outputIndices → inputBuffers → outputBuffers. Textures live in the separate `texture(0..)` slot space: inputTextures then outputTextures. Match your MSL signature to this order.

– `outputs` lists attribute names whose buffers the kernel writes   (must be declared `storage: "compute"`); `outputIndices: true`   exposes the mesh's index buffer for GPU writes;   `inputBuffers` / `outputBuffers` bind `Buffer` handles to kernel   slots; textures bind via `.read` / `.write` tokens.   `threadsPerThreadgroup` defaults to a SIMD-aligned shape per   dispatch dimensionality (1D → `[threadExecutionWidth, 1, 1]`;   2D → `[16, 16, 1]`; 3D → `[8, 8, 4]`). Authors who know their   kernel's register / shared-memory budget can override.

**Example:**

```javascript
const kernel = await Kernel.fromSource({
    source: kernelSource,
    functionName: 'marchCubes'
});
const triCounter = Buffer.atomic(0);

scene.on('render', function () {
    mesh.runCompute(kernel, {
        uniforms: new Float32Array([scene.time, 0.016]),
        outputs: ['position', 'normal'],
        outputIndices: true,
        outputBuffers: { triCount: triCounter },
        threadGroups: [8, 8, 4]
    });

    const [emitted] = triCounter.readSync();
    mesh.drawCount = emitted * 3;
});
```

**Parameters:**

* `kernel` ([Kernel](https://scenery.app/docs/scripting/api/kernel)) - handle from `Kernel.fromSource(...)` / `Kernel.fromAsset(...)`.
* `options` ({ uniforms?: Float32Array, outputs?: string\[], outputIndices?: boolean, inputBuffers?: object, outputBuffers?: object, inputTextures?: object, outputTextures?: object, threadGroups: number\[3], threadsPerThreadgroup?: number\[3] })

**Returns:** void

### setBounds()

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

```javascript
setBounds(bounds: BoundingBox | { min: number[3], max: number[3] }): void
```

Update the bounds of part 0.

Shorthand for `updatePart(0, { bounds })` on single-part meshes. Accepts either a `BoundingBox` instance or a plain object `{ min: [x, y, z], max: [x, y, z] }`.

**Example:**

```javascript
mesh.setBounds(BoundingBox(Vector3(-1, 0, -1), Vector3(1, 2, 1)));
mesh.setBounds({ min: [-1, 0, -1], max: [1, 2, 1] });  // also valid
```

**Parameters:**

* `bounds` ([BoundingBox](https://scenery.app/docs/scripting/api/boundingbox) | { min: number\[3], max: number\[3] }) - New bounds for part 0.

**Returns:** void

### updatePart()

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

```javascript
updatePart(partIndex: number, options: { indexCount?: number, indexOffset?: number, topology?: string, materialIndex?: number, bounds?: BoundingBox | { min: number[3], max: number[3] } }): void
```

Update a part's metadata.

Only the keys present in `options` are applied; everything else is left untouched. The typical per-frame call for a growing mesh sends new `bounds` and/or `indexCount` for part 0.

For single-part meshes, the shorthands `mesh.drawCount = N` and `mesh.setBounds(b)` are equivalent to passing `{ indexCount: N }` and `{ bounds: b }` here.

**Example:**

```javascript
mesh.updatePart(0, {
    indexCount: 1234,
    bounds: { min: [-1, 0, -1], max: [1, 2, 1] }
});
```

**Parameters:**

* `partIndex` (number) - Zero-based index into `parts`.
* `options` ({ indexCount?: number, indexOffset?: number, topology?: string, materialIndex?: number, bounds?: BoundingBox | { min: number\[3], max: number\[3] } }) - Only present keys are applied.

**Returns:** void

### writeIndices()

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

```javascript
writeIndices(indexOffset: number, data: Uint32Array | Uint16Array): void
```

Write indices starting at slot `indexOffset`.

The index count is derived from the TypedArray's length. `data` must be `Uint32Array` (the default index type) or `Uint16Array` if the mesh was created with `indexType: "uint16"`.

**Example:**

```javascript
mesh.writeIndices(0, new Uint32Array([0, 1, 2, 2, 1, 3]));
```

**Parameters:**

* `indexOffset` (number) - First index slot to write into.
* `data` (Uint32Array | Uint16Array) - Index data matching the mesh's `indexType`.

**Returns:** void

### writeVertices()

Documentation source: [Mesh beta](https://scenery.app/docs/scripting/api/mesh.md).

```javascript
writeVertices(name: string, vertexOffset: number, data: Float32Array | Uint8Array): void
```

Write packed elements of a single named attribute.

Starts at vertex index `vertexOffset`. The vertex count is derived from the TypedArray's length (`array.length / componentsPerVertex`).

`data` must be a JS TypedArray whose element type matches the attribute's format: `Float32Array` for `float` / `float2` / `float3` / `float4`, `Uint8Array` for `uchar4Normalized`. Bytes flow straight from the JS engine's buffer into the mesh via a single `memcpy` – no intermediate copy, no per-element trips.

**Example:**

```javascript
mesh.writeVertices("position", 0, new Float32Array([
    -0.25, 0.0, 0.0,
     0.25, 0.0, 0.0,
     0.0,  0.4, 0.0
]));
```

**Parameters:**

* `name` (string) - Attribute name as declared in `createMesh`.
* `vertexOffset` (number) - First vertex slot to write into (0 for a full overwrite).
* `data` (Float32Array | Uint8Array) - Packed attribute data. The TypedArray must match the attribute's declared format.

**Returns:** void

---

Source page: Instances beta

Source URL: https://scenery.app/docs/scripting/api/instances.md

# Instances beta

Documentation source: [Instances beta](https://scenery.app/docs/scripting/api/instances.md).

Instance-data handles for `rep.setInstances(...)` / `entity.setInstances(...)` – GPU mesh instancing draws one copy of a mesh per transform, far cheaper than real entities. Instances are rendering-only (no physics, collision, or per-instance identity); use `clone()` for objects the user interacts with. Gate with `environment.features.has('instancing')`.

## Static Methods

Documentation source: [Instances beta](https://scenery.app/docs/scripting/api/instances.md).

### transforms()

Documentation source: [Instances beta](https://scenery.app/docs/scripting/api/instances.md).

```javascript
Instances.transforms(list: Array<Transform | Vector3>): Object
```

Build an instance-data handle from a list of transforms. Each entry is a `Transform` (full pose) or a `Vector3` (a copy placed at that position). A bare array is also accepted – `setInstances([...])` is sugar for `setInstances(Instances.transforms([...]))`.

**Parameters:**

* `list` (Array\<Transform | Vector3>) - Per-instance transforms.

**Returns:** Object

---

Source page: Global Functions

Source URL: https://scenery.app/docs/scripting/api/functions.md

# Global Functions

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

## wait()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
wait(seconds: number): Promise<void>
```

Wait for specified seconds

**Parameters:**

* `seconds` (number) - Seconds to wait

**Returns:** Promise\<void>

## animateValue()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
animateValue(options: Object): ValueAnimation
```

Create and start a value animation

Automatically interpolates between from/to values based on their type. Supports numbers, Vector2, Vector3, Vector4, Color, and Rotation. Rotations use spherical interpolation (slerp) automatically.

Animations clean up automatically when complete. For infinite animations, call destroy() to stop, or they clean up when the scene ends.

**Example:**

```javascript
// Fade in
animateValue({
    from: 0,
    to: 1,
    duration: 0.3,
    onUpdate: function(opacity) {
        entity.opacity = opacity;
    }
});
```

**Parameters:**

* `options` (Object) - Animation configuration
* `options.from` (number | [Vector2](https://scenery.app/docs/scripting/api/vector2) | [Vector3](https://scenery.app/docs/scripting/api/vector3) | [Vector4](https://scenery.app/docs/scripting/api/vector4) | [Color](https://scenery.app/docs/scripting/api/color) | [Rotation](https://scenery.app/docs/scripting/api/rotation)) - Start value
* `options.to` (number | [Vector2](https://scenery.app/docs/scripting/api/vector2) | [Vector3](https://scenery.app/docs/scripting/api/vector3) | [Vector4](https://scenery.app/docs/scripting/api/vector4) | [Color](https://scenery.app/docs/scripting/api/color) | [Rotation](https://scenery.app/docs/scripting/api/rotation)) - End value (must match from type)
* `options.duration` (number) *(optional)* - Duration in seconds (for curve timing)
* `options.curve` (string) *(optional)* - Easing curve: "linear", "easeIn", "easeOut", "easeInOut"
* `options.spring` (Object) *(optional)* - Spring timing (overrides duration/curve)
* `options.spring.duration` (number) *(optional)* - Spring settle duration
* `options.spring.bounce` (number) *(optional)* - Bounce amount (0 = no bounce, 1 = full bounce)
* `options.bezier` (Array\<number>) *(optional)* - Custom bezier curve \[p1x, p1y, p2x, p2y]
* `options.delay` (number) *(optional)* - Delay before starting (seconds)
* `options.repeatCount` (number) *(optional)* - Number of repeats (0 = play once, -1 = infinite)
* `options.reverseOnRepeat` (boolean) *(optional)* - Reverse direction on each repeat (yoyo)
* `options.autoStart` (boolean) *(optional)* - Start immediately
* `options.onUpdate` (function) - Called each frame with the interpolated value
* `options.onComplete` (function) *(optional)* - Called when animation finishes (not called for infinite)

**Returns:** [ValueAnimation](https://scenery.app/docs/scripting/api/valueanimation)

## createBox()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createBox(width?: number, height?: number, depth?: number, cornerRadius?: number, options?: Object): ObjectDescriptor
```

Create a box primitive descriptor

**Example:**

```javascript
// Declarative: reads like data, serializes cleanly.
createBox(0.3, 0.3, 0.3, 0, { name: 'crate', physics: { mode: 'dynamic' } });
```

**Parameters:**

* `width` (number) *(optional)* - Width in meters
* `height` (number) *(optional)* - Height in meters
* `depth` (number) *(optional)* - Depth in meters
* `cornerRadius` (number) *(optional)* - Corner radius for rounded edges
* `options` (Object) *(optional)* - Declarative object config, the same keys as the builder methods:
  `{ name, anchor, physics, gestures, material, shadow, transform, opacity, fittingBox,
  pivot, revealAnimation, removalAnimation, hideByDefault, flatten }`.
  `createBox(w, h, d, r, { physics, material })` equals `createBox(w, h, d, r).physics(…).material(…)`.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createSphere()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createSphere(radius?: number, options?: Object): ObjectDescriptor
```

Create a sphere primitive

**Parameters:**

* `radius` (number) *(optional)*
* `options` (Object) *(optional)* - Declarative object config (same keys as the builder methods) – see createBox.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createPlane()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createPlane(orientation: string | number, width?: number, height?: number, cornerRadius?: number): ObjectDescriptor
```

Create a plane primitive

**Example:**

```javascript
// A 2m x 2m horizontal floor plane ('xz'); use 'xy' for a vertical wall.
var floor = await scene.createEntity(
    createPlane('xz', 2, 2).anchor(Anchor.position(0, 0, -2))
);
```

**Parameters:**

* `orientation` (string | number) - "xz" (horizontal) or "xy" (vertical), or width if orientation omitted
* `width` (number) *(optional)*
* `height` (number) *(optional)*
* `cornerRadius` (number) *(optional)*

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createModel()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createModel(urlOrId: string, options?: Object): ObjectDescriptor
```

Create a 3D model object descriptor

**Example:**

```javascript
var model = await scene.createEntity(
    createModel('https://example.com/chair.usdz').anchor(Anchor.horizontalPlane('floor'))
);
```

**Parameters:**

* `urlOrId` (string) - HTTPS URL to .usdz/.reality file or asset ID from project
* `options` (Object) *(optional)* - Declarative object config (same keys as the builder methods) – see createBox.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createSplat() beta

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createSplat(urlOrId: string, options?: Object): ObjectDescriptor
```

Create a Gaussian splat capture object descriptor

**Example:**

```javascript
var capture = await scene.createEntity(
    createSplat(assetId, { opacityThreshold: 0.02 }).anchor(Anchor.position(0, 0.4, -0.8))
);
var splat = capture.representation.splat;
```

**Parameters:**

* `urlOrId` (string) - HTTPS URL to an .spz file, or asset ID from project
* `options` (Object) *(optional)* - Declarative object config. Beyond the shared keys (see createBox):
  `projection` ("perspective" | "tangential"), `sorting` ("depth" | "distance"),
  `opacityThreshold` (0–1, drops the faintest splats at load), and `coordinateSystem`
  ("rub" | "rdf", the axes the file stores its splats in; pass "rdf" for a PLY-based export
  that appears upside down).

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createMedia()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createMedia(kind: string, urlOrId: string, width?: number, aspectRatio?: number, options?: Object): ObjectDescriptor
```

Create a visual media object (image, video, or animated GIF)

**Parameters:**

* `kind` (string) - "image", "video", or "animatedGif"
* `urlOrId` (string) - HTTPS URL or asset ID
* `width` (number) *(optional)* - Width in meters
* `aspectRatio` (number) *(optional)* - Aspect ratio (width/height)
* `options` (Object) *(optional)* - Additional options
* `options.cornerRadius` (number) *(optional)* - Relative corner radius (0-1)
* `options.doubleSided` (boolean) *(optional)* - Render both sides
* `options.showLoading` (boolean) *(optional)* - Show loading placeholder
* `options.immersive` (boolean) *(optional)* - Enable immersive rendering
* `options.video` (Object) *(optional)* - Video playback options
* `options.video.volume` (number) *(optional)* - Volume (0-1)
* `options.video.loops` (boolean) *(optional)* - Loop playback
* `options.video.stream` (boolean) *(optional)* - Stream content

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createImage()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createImage(urlOrId: string, width?: number, aspectRatio?: number, options?: Object): ObjectDescriptor
```

Create an image

**Example:**

```javascript
// 0.5m wide, 3:2 aspect ratio (width / height).
var photo = await scene.createEntity(
    createImage('https://picsum.photos/900/600', 0.5, 1.5).anchor(Anchor.currentPOV(0, 0, -1.5))
);
```

**Parameters:**

* `urlOrId` (string) - HTTPS URL or asset ID
* `width` (number) *(optional)* - Width in meters
* `aspectRatio` (number) *(optional)* - Aspect ratio (width/height)
* `options` (Object) *(optional)* - Additional options (cornerRadius, doubleSided, showLoading, immersive)

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createVideo()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createVideo(urlOrId: string, width?: number, aspectRatio?: number, options?: Object): ObjectDescriptor
```

Create a video

**Parameters:**

* `urlOrId` (string) - HTTPS URL or asset ID
* `width` (number) *(optional)* - Width in meters
* `aspectRatio` (number) *(optional)* - Aspect ratio (width/height)
* `options` (Object) *(optional)* - Additional options (cornerRadius, doubleSided, showLoading, immersive, video)

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createAnimatedGif()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createAnimatedGif(urlOrId: string, width?: number, aspectRatio?: number, options?: Object): ObjectDescriptor
```

Create an animated GIF

**Parameters:**

* `urlOrId` (string) - HTTPS URL or asset ID
* `width` (number) *(optional)* - Width in meters
* `aspectRatio` (number) *(optional)* - Aspect ratio (width/height)
* `options` (Object) *(optional)* - Additional options (cornerRadius, doubleSided, showLoading, immersive)

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createContainer()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createContainer(children: Array<ObjectDescriptor>): ObjectDescriptor
```

Create a container/composition

**Example:**

```javascript
// Group objects so the container anchors and moves them as one.
var group = await scene.createEntity(
    createContainer([ createBox(0.1, 0.1, 0.1), createSphere(0.05) ]).anchor(Anchor.position(0, 0, -1.5))
);
```

**Parameters:**

* `children` (Array<[ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)>) - Child object descriptors

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createPanel() beta

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createPanel(content: Object, options?: Object): ObjectDescriptor
```

Build a UI panel descriptor wrapping the given root view. Pass to `scene.createEntity(panel)` to instantiate.

**Example:**

```javascript
var panel = createPanel(
    UI.vStack({ spacing: 12, children: [UI.label('Hi'), UI.slider({ name: 'vol' })] }),
    { panelSize: [400, 240] }
).name('debug-hud');
var entity = await scene.createEntity(panel);
```

**Parameters:**

* `content` (Object) - Root View descriptor (typically a UI.vStack/hStack/zStack).
* `options` (Object) *(optional)*
* `options.panelSize` (any | any | Array\<number> | any) *(optional)* - Panel dimensions. Use `'auto'` (default – sized to content), `'fill'`
  (fill parent), or an explicit size in **points** (≈ 1360 pt/m): either
  `[width, height]` or `{ width, height }`. E.g. `[400, 240]` ≈ 0.29m × 0.18m.
* `options.material` (any) - Surface material. `'system'` (default – platform-appropriate translucent
  surface), `'transparent'`, a `ColorSource` (hex string / Color) for a
  solid fill, or `{ prominence: 'standard'|'expressive' }` for system with
  a prominence override.
* `options.cornerRadius` (number) *(optional)*
* `options.isScrollable` (boolean) *(optional)*

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createMesh() beta

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createMesh(opts: Object): ObjectDescriptor
```

Create a scriptable dynamic mesh with CPU-driven vertex/index updates.

Returns an ObjectDescriptor – pass to `scene.createEntity(...)`. After the entity loads, reach the mesh via `entity.representation.mesh` and write buffer data with `mesh.writeVertices(...)` / `mesh.writeIndices(...)`. Bytes flow straight from `Float32Array` / `Uint32Array` into the GPU-side buffer – single memcpy per call, no per-element overhead.

**Example:**

```javascript
// Triangle, single static buffer, no material override (using shorthand).
const entity = await scene.createEntity(createMesh({
    vertexCapacity: 3,
    indexCapacity: 3,
    attributes: {
        position: "float3"
    },
    parts: [{
        indexCount: 3,
        bounds: { min: [-0.5, -0.1, -0.1], max: [0.5, 0.5, 0.1] }
    }]
}));

const mesh = entity.representation.mesh;
mesh.writeVertices("position", 0, new Float32Array([
    -0.25, 0.0, 0.0,
     0.25, 0.0, 0.0,
     0.0,  0.4, 0.0
]));
mesh.writeIndices(0, new Uint32Array([0, 1, 2]));
```

**Parameters:**

* `opts` (Object)
* `opts.vertexCapacity` (number) - Max vertices the mesh allocates space for. Required.
* `opts.indexCapacity` (number) - Max indices the mesh allocates space for. Required (must be > 0). For draw orders that would otherwise be non-indexed, set this to `vertexCapacity` and write sequential indices `[0, 1, 2, …]` once.
* `opts.indexType` (string) *(optional)* - "uint32" or "uint16".
* `opts.attributes` (Object\<string, string | Object>) - Named attributes. Either a string shorthand or an explicit object.
  \- **Shorthand** (static, semantic auto-derived from name):
  `position: "float3"`, `color: "uchar4Normalized"`.
  \- **Explicit form**: `{ semantic, format, storage }`.
  `semantic` ∈ "position" | "normal" | "tangent" | "bitangent" |
  "color" | "uv0" … "uv7" | "unspecified" (defaults to the attribute
  name when omitted).
  `format` ∈ "float" | "float2" | "float3" | "float4" | "uchar4Normalized".
  `storage` ∈ "static" (default – write once at setup) | "dynamic"
  (CPU-writable via `writeVertices`, per-frame) | "compute" (reserved
  for a future runtime version; rejected today).
* `opts.parts` (Array\<Object>) - Draw ranges.
  Each part: `{ indexOffset?, indexCount, topology?, materialIndex?, bounds }`.
  `topology` ∈ "triangle" (default) | "triangleStrip" | "line" | "lineStrip" | "point".
  `bounds`: `{ min: [x,y,z], max: [x,y,z] }`. Must contain every vertex the part draws.
* `opts.materials` (Array\<string>) *(optional)* - Material reference ids from the experience's material library.
  Each part's `materialIndex` indexes into this array. If empty, a default material is used.
* `opts.interleavedGroups` (Array\<Array\<string>>) *(optional)* - Opt-in attribute grouping. Each inner array is a set of attribute
  names that share one underlying buffer (interleaved layout). Default
  is one buffer per attribute. Use case: spatial-drawing-style stroke
  extension where every vertex carries position+normal+color together —
  interleaved gives better GPU cache locality. All attributes in a
  group must share `storage` state (all "static", all "dynamic", etc.).
  Per-attribute write API (`mesh.writeVertices(name, ...)`) stays the
  same; the bridge uses a strided memcpy under the hood.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createSpotLight()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createSpotLight(options?: Object): ObjectDescriptor
```

Create a spot light – a cone of light aimed along the object's forward axis.

Rotation aims it; position places it. Intensity is in lumens.

**Example:**

```javascript
// A warm spot pointing straight down at the floor, with a soft-edged shadow.
var lamp = await scene.createEntity(
    createSpotLight({
        color: '#FFD9A0',
        intensity: 4000,
        outerAngle: 45,
        attenuationRadius: 3,
        shadow: { edges: 'soft', lightSize: 0.2 },
        anchor: Anchor.position(0, 2, -1),
        transform: { rotation: Rotation(-Math.PI / 2, 0, 0) }
    })
);
```

**Parameters:**

* `options` (Object) *(optional)* - Light configuration:
  `color` (`'#RRGGBB'` or `{ r, g, b }`), `intensity` (lumens, default 6740.94),
  `innerAngle` / `outerAngle` in degrees (full cone aperture, defaults 45 / 60),
  `attenuationRadius` in metres (default 10), `falloffExponent` (2 is physically
  correct), `shadow` (see below), `projectedTexture` (asset id, HTTPS URL, or a
  handle from `Texture.image/video/cameraFeed/compute(...)`),
  `projectedTextureOffset` / `projectedTextureScale` (`{ x, y }`, a pair, or one
  number for both axes) and `projectedTextureRotation` in radians, which lay the
  projected texture out within the cone, `lightsSurroundings` (spill onto real
  surfaces).
  Plus every shared descriptor key – `name`, `anchor`, `transform`, …

  `shadow` is `true` for defaults, or `{ edges, lightSize, depthBias }`:
  `edges` is `'hard'` (default, cheapest), `'soft'` or `'softer'`; `lightSize` is
  the emitter's size in metres, which widens the blurred edge and does nothing at
  `'hard'`; `depthBias` offsets the shadow off its own surface.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createPointLight()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createPointLight(options?: Object): ObjectDescriptor
```

Create a point light – light radiating equally in every direction.

Only its position matters; rotation does nothing. Intensity is in lumens, and a point light cannot cast shadows.

**Example:**

```javascript
// A candle flame that breathes.
var flame = await scene.createEntity(
    createPointLight({ color: '#FF9A3C', intensity: 800, attenuationRadius: 1.5 })
);
animateValue({
    from: 650, to: 900, duration: 1.4, curve: 'easeInOut',
    repeatCount: -1, reverseOnRepeat: true,
    onUpdate: function(value) { flame.representation.light.intensity = value; }
});
```

**Parameters:**

* `options` (Object) *(optional)* - `color`, `intensity` (lumens, default 26963.76),
  `attenuationRadius` (metres, default 10), `falloffExponent`,
  `lightsSurroundings`, plus the shared descriptor keys.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

## createDirectionalLight()

Documentation source: [Global Functions](https://scenery.app/docs/scripting/api/functions.md).

```javascript
createDirectionalLight(options?: Object): ObjectDescriptor
```

Create a directional light – a sun, shining from infinitely far away.

Only its rotation matters; position moves nothing but the editor's marker. Intensity is in lux rather than lumens, so the numbers are not comparable with the other two types.

**Example:**

```javascript
// A low afternoon sun that casts shadows across a wide scene.
await scene.createEntity(
    createDirectionalLight({
        intensity: 2500,
        shadow: { maximumDistance: 20, cascades: 3 },
        transform: { rotation: Rotation(-0.6, 0.7, 0) }
    })
);
```

**Parameters:**

* `options` (Object) *(optional)* - `color`, `intensity` (lux, default 2145.71),
  `shadow`, plus the shared descriptor keys. `shadow` is `true` for defaults or
  `{ maximumDistance, depthBias, cascades }`: `maximumDistance` is how far from
  the camera shadows are computed at all, and `cascades` is `'automatic'` or a
  count of 1...4, where more sharpens distant shadows and costs the same factor
  in memory.

**Returns:** [ObjectDescriptor](https://scenery.app/docs/scripting/api/objectdescriptor)

